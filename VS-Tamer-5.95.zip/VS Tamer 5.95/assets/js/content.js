(() => {
  if (!location.hostname.includes("vivastreet.co.uk")) return;

  const NUMBERS_KEY = "numbers";
  const AD_META_KEY = "vsAdMeta";
  const ADVERTISER_CACHE_KEY = "vsAdvertiserCache";
const FILTERS_KEY = "vsFilters";
const IMAGE_CHECK_KEY = "vsReverseImageChecks";
const CONTACTED_KEY = "vsContactedAdvertisers";
const FAKE_KEY = "vsFakeAdverts";
const ROTATING_KEY = "vsRotatingPhotos";
const NOT_WA_KEY = "vsNotOnWhatsapp";
const REAL_PHOTO_KEY = "vsRealPhoto";
const gallerySessionCache = new Map();
window.addEventListener("blur", () => document.querySelectorAll(".vs-fast-tooltip").forEach(el => el.remove()));

  const FAV_STORAGE_KEY = "vsFavouriteCustomOrder";
  const FAV_STORAGE_SYNC_KEY = "vsFavouriteCustomOrderSync";
  const FAV_GROUPS_KEY = "vsFavouriteGroups";
  const FAV_GROUPS_DEFAULT = ["Live", "Watchlist", "Carousel"];
  let FAV_GROUPS = [...FAV_GROUPS_DEFAULT];

function isAdvertPage() {
  return /\/(escort|massage|escorts)\//i.test(location.pathname) && /\/\d{6,}/.test(location.pathname);
}

let favObserverStarted = false;
let favApplying = false;
let favUiInteracting = false;
let favObserver = null;
let favObserverPausedUntil = 0;
let favTimer = null;
let favNetworkTimer = null;
let favCacheTimer = null;
let favCardNodeIds = new WeakMap();
let favNextCardNodeId = 1;
let favLastCardSignature = "";
let favPendingCardSignature = "";
const favCombinedCards = new Map();
const favCombinedPages = new Set();
const favPendingRemovals = new Set();
const favPageQueue = [];
let favPageLoads = 0;
let favPageFailure = false;
let favCombiningStarted = false;
const favPageAttempts = new Map();

function favouritePageLinks(doc) {
  const links = new Set();
  doc.querySelectorAll('nav[aria-label="Pagination"] a[href], [data-testid="favourites-pagination"] a[href]').forEach(a => {
    try {
      const url = new URL(a.getAttribute("href"), location.href);
      if (url.origin !== location.origin || url.pathname !== location.pathname) return;
      const page = Number(url.searchParams.get("page") || 1);
      if (!Number.isInteger(page) || page < 1) return;
      url.hash = "";
      if (page === 1) url.searchParams.delete("page");
      links.add(url.href);
    } catch (e) {}
  });
  return Array.from(links);
}

function favouritePageStatus(text) {
  let status = document.getElementById("vs-all-favourites-status");
  if (!status) {
    const parent = getCardsParent(getFavouriteCards());
    if (!parent) return;
    status = document.createElement("div");
    status.id = "vs-all-favourites-status";
    status.style.cssText = "font:12px Arial,sans-serif;color:#555;margin:6px 0";
    status.setAttribute("role", "status");
    parent.before(status);
  }
  if (status.textContent !== text) status.textContent = text;
}

function restoreCombinedFavouriteCards() {
  if (!isFavouritesPage() || !favCombinedCards.size) return false;
  if (Array.from(favCombinedCards.values()).every(card => card.isConnected)) return false;
  const cards = getFavouriteCards();
  const parent = getCardsParent(cards);
  if (!parent) return false;
  const present = new Set(cards.map(item => item.key));
  let changed = false;
  favCombinedCards.forEach((card, key) => {
    if (favPendingRemovals.has(key)) {
      if (!card.isConnected) { favCombinedCards.delete(key); favPendingRemovals.delete(key); }
      return;
    }
    if (!present.has(key)) { parent.appendChild(card); changed = true; }
  });
  return changed;
}

function importFavouritePage(doc) {
  const parent = getCardsParent(getFavouriteCards());
  if (!parent) throw new Error("Favourites list is not available");
  const present = new Set(getFavouriteCards().map(item => item.key));
  let added = 0;
  doc.querySelectorAll('li[id^="classified-"]').forEach(card => {
    const link = Array.from(card.querySelectorAll("a[href]")).find(a => /\/(escort|massage|escorts)\/.*\/\d{6,}/i.test(a.href));
    if (!link) return;
    const key = cleanLink(link.href);
    if (present.has(key)) return;
    present.add(key);
    // Adopt live nodes, not parsed HTML/clones: the site's own favourite-removal
    // handlers remain attached. Their hidden source frame stays alive.
    parent.appendChild(document.adoptNode(card));
    favCombinedCards.set(key, card);
    added++;
  });
  return added;
}

document.addEventListener("click", e => {
  const button = e.target.closest?.('button[aria-label^="Remove "][aria-label$=" from favourites"]');
  if (!button) return;
  const card = button.closest('li[id^="classified-"]');
  const item = getFavouriteCards().find(item => item.card === card);
  if (!item || !favCombinedCards.has(item.key)) return;
  favPendingRemovals.add(item.key);
  setTimeout(() => {
    if (!card.isConnected) favCombinedCards.delete(item.key);
    favPendingRemovals.delete(item.key);
  }, 30000);
}, true);

function combineFavouritePages() {
  if (!isFavouritesPage()) return;
  function enqueue(doc) {
    favouritePageLinks(doc).forEach(url => {
      if (favCombinedPages.has(url)) return;
      favCombinedPages.add(url);
      favPageQueue.push(url);
    });
  }
  if (!favCombiningStarted) {
    const current = new URL(location.href);
    current.hash = "";
    if (Number(current.searchParams.get("page") || 1) === 1) current.searchParams.delete("page");
    favCombinedPages.add(current.href);
    favCombiningStarted = true;
  }
  enqueue(document);
  function pump() {
    while (favPageLoads < 2 && favPageQueue.length) {
      const url = favPageQueue.shift();
      favPageAttempts.set(url, (favPageAttempts.get(url) || 0) + 1);
      favPageLoads++;
      favouritePageStatus("Loading all favourites…");
      const frame = document.createElement("iframe");
      frame.dataset.vsFavouriteSource = "1";
      frame.style.cssText = "position:absolute;width:1px;height:1px;left:-10000px;visibility:hidden;border:0";
      frame.tabIndex = -1;
      frame.setAttribute("aria-hidden", "true");
      let finished = false;
      const timeout = setTimeout(() => finish(new Error("Page load timed out")), 20000);
      function finish(error) {
        if (finished) return;
        finished = true;
        clearTimeout(timeout);
        favPageLoads--;
        if (error) {
          frame.remove();
          if (favPageAttempts.get(url) < 2) favPageQueue.push(url);
          else favPageFailure = true;
        }
        else { scheduleFavouriteCacheRender(0); scheduleFavouriteRefresh(40); }
        pump();
      }
      frame.onload = () => {
        // The frame load event can precede the site's asynchronous favourites
        // fetch. Wait for real cards and a stable card set, not a fixed delay.
        let previousSignature = "";
        let stableSince = 0;
        function waitForCards() {
          if (finished) return;
          try {
            const doc = frame.contentDocument;
            if (!doc) throw new Error("Could not read favourites page");
            const signature = Array.from(doc.querySelectorAll('li[id^="classified-"]')).map(card => card.id).join("|");
            if (!signature || signature !== previousSignature) {
              previousSignature = signature;
              stableSince = Date.now();
              setTimeout(waitForCards, 250);
              return;
            }
            if (Date.now() - stableSince < 500 || !getCardsParent(getFavouriteCards())) {
              setTimeout(waitForCards, 250);
              return;
            }
            enqueue(doc);
            const sourceIds = new Set(Array.from(doc.querySelectorAll('li[id^="classified-"]')).map(card => cleanLink(Array.from(card.querySelectorAll("a[href]")).find(a => /\/\d{6,}/.test(a.href))?.href || "")));
            importFavouritePage(doc);
            // A native Remove click may remove an adopted node. Forget it so
            // a later redraw never brings a deleted favourite back.
            const removalObserver = new MutationObserver(() => {
              sourceIds.forEach(key => {
                const card = favCombinedCards.get(key);
                if (card && !card.isConnected) favCombinedCards.delete(key);
              });
            });
            removalObserver.observe(document.body, { childList:true, subtree:true });
            finish();
          } catch (error) { finish(error); }
        }
        setTimeout(waitForCards, 250);
      };
      frame.onerror = () => finish(new Error("Could not load favourites page"));
      frame.src = url;
      document.body.appendChild(frame);
    }
    if (!favPageLoads && !favPageQueue.length) {
      if (favPageFailure) {
        favouritePageStatus("Some favourites could not load after retrying; page navigation remains available.");
      } else {
        document.querySelectorAll('nav[aria-label="Pagination"], [data-testid="favourites-pagination"]').forEach(nav => nav.style.display = "none");
        if (favCombinedPages.size > 1) favouritePageStatus(`All ${getFavouriteCards().length} favourites on one page`);
      }
    }
  }
  pump();
}

let listingsPassRunning = false;
let listingsPassRequested = false;
const listingsPassCallbacks = [];
const listingsNextPassCallbacks = [];
const cachedRepairInFlight = new Set();
const cachedRepairAttempted = new Set();
const galleryRetryCounts = new Map();
const cachedRepairQueue = [];
let cachedRepairActive = 0;
const CACHED_REPAIR_MAX_ACTIVE = 3;

const VS_WA_DEFAULT_MESSAGE = "Hi...";
const VS_WA_LAST_MESSAGE_KEY = "vsWaLastMessage";
let vsWaLastMessage = VS_WA_DEFAULT_MESSAGE;
let vsWaMessageRevision = 0;
const initialWaMessageRevision = vsWaMessageRevision;
chrome.storage.local.get([VS_WA_LAST_MESSAGE_KEY], res => {
  if (vsWaMessageRevision === initialWaMessageRevision) vsWaLastMessage = res[VS_WA_LAST_MESSAGE_KEY] || VS_WA_DEFAULT_MESSAGE;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[VS_WA_LAST_MESSAGE_KEY]) {
    vsWaMessageRevision++;
    vsWaLastMessage = changes[VS_WA_LAST_MESSAGE_KEY].newValue || VS_WA_DEFAULT_MESSAGE;
  }
});

  function cleanLink(url) {
    return (url || "").split("?")[0];
  }

  function getListingCardFromLink(link) {
    if (!link || link.closest("#vs-pagination-killer-overlay, #vs-preview-popup")) return null;
    return (
      link.closest('li[id^="classified-"]') ||
      link.closest(".clad__ad") ||
      link.closest("article") ||
      link.closest(".vs-search-shadow") ||
      link.closest("li") ||
      null
    );
  }

function getAdvertPhoto(card) {
  return Array.from(card.querySelectorAll("img")).find(img =>
    !img.closest(".vs-listing-thumb-strip, .newData, .vs-contacted-card-wrap") &&
    /\/clad\/\d+\//.test(img.currentSrc || img.getAttribute("data-src") || img.getAttribute("src") || "")
  );
}

// Keep extension controls outside native click-through anchors and above their overlays.
function protectControls(node) {
  node.style.position = "relative";
  node.style.zIndex = "30";
  node.style.pointerEvents = "auto";
  ["click", "pointerdown", "mousedown", "touchstart"].forEach(type =>
    node.addEventListener(type, e => e.stopPropagation())
  );
}

function getInfoAnchor(card, fallback) {
  const title = card.querySelector(".clad__title,h2,h3");
  const anchor = title || fallback;
  return anchor?.closest("a") || anchor;
}

const detailRequests = new Map();
function fetchDetailOnce(url, callback) {
  const key = cleanLink(url);
  const existing = detailRequests.get(key);
  if (existing) { existing.then(callback); return; }
  const request = new Promise(resolve => {
    const timeout = setTimeout(() => { detailRequests.delete(key); resolve(null); }, 20000);
    chrome.runtime.sendMessage({ action: "fetchHTML", url: key }, response => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError || !response?.html) {
        detailRequests.delete(key);
        resolve(null);
      } else resolve(response);
    });
  });
  detailRequests.set(key, request);
  request.then(callback);
}

function attachFastTooltip(el, text) {
  let tooltip;

  function removeTooltip() {
    document.querySelectorAll(".vs-fast-tooltip").forEach((t) => t.remove());
    tooltip = null;
  }

  function move(e) {
    if (!tooltip) return;
    tooltip.style.left = e.clientX + 10 + "px";
    tooltip.style.top = e.clientY + 10 + "px";
  }

  el.addEventListener("mouseenter", (e) => {
    removeTooltip();

    const tooltipText = typeof text === "function" ? text() : text;
    if (!tooltipText) return;

    tooltip = document.createElement("div");
    tooltip.className = "vs-fast-tooltip";
    tooltip.textContent = tooltipText;

    tooltip.style.position = "fixed";
    tooltip.style.zIndex = "999999";
    tooltip.style.background = "#111";
    tooltip.style.color = "#fff";
    tooltip.style.fontSize = "11px";
    tooltip.style.padding = "4px 6px";
    tooltip.style.borderRadius = "6px";
    tooltip.style.whiteSpace = "nowrap";
    tooltip.style.pointerEvents = "none";
    tooltip.style.boxShadow = "0 2px 6px rgba(0,0,0,0.25)";

    document.body.appendChild(tooltip);
    move(e);
  });

  el.addEventListener("mousemove", move);
  el.addEventListener("mouseleave", removeTooltip);
  el.addEventListener("mousedown", removeTooltip);
  el.addEventListener("click", removeTooltip);
}

function insertAfter(newNode, referenceNode) {
  try {
    if (!newNode || !referenceNode || !referenceNode.parentNode) return;

    const parent = referenceNode.parentNode;

    if (referenceNode.nextSibling) {
      parent.insertBefore(newNode, referenceNode.nextSibling);
    } else {
      parent.appendChild(newNode);
    }
  } catch (e) {
    console.log("VS insertAfter skipped:", e);
  }
}

  function saveFavourites(data, callback) {
    chrome.storage.local.set({ [FAV_STORAGE_KEY]: data }, function () {
      const error = chrome.runtime.lastError;
      if (callback) callback(error ? error.message : null);
    });
  }

  function getRawWhatsappDigits(number) {
    if (!number) return "";
    let digits = String(number).replace(/\D/g, "");
    if (digits.startsWith("0")) digits = "44" + digits.substring(1);
    return digits;
  }

  function formatDisplayPhone(number) {
    const digits = getRawWhatsappDigits(number);
    if (!digits) return "-";
    if (digits.startsWith("44") && digits.length >= 12) {
      return `44 (0) ${digits.substring(2, 6)} ${digits.substring(6)}`;
    }
    return digits;
  }

  function normalizeNationality(value) {
    return (value || "").trim().toLowerCase();
  }

function parseMoneyNumber(text) {
  if (!text) return null;

  const clean = String(text)
    .replace(/,/g, "")
    .replace(/£/g, "")
    .trim();

  if (!clean || clean === "-") return null;

  const match = clean.match(/\d+(\.\d+)?/);
  return match ? Number(match[0]) : null;
}

  function titleCase(text) {
    return String(text || "")
      .replace(/[-_]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function extractAreaFromUrl(url) {
    try {
      const u = new URL(url);
      const parts = u.pathname.split("/").filter(Boolean);
      const typeIndex = parts.findIndex((p) =>
        ["escort", "massage", "escorts"].includes(p)
      );
      if (typeIndex !== -1 && parts[typeIndex + 1]) {
        return titleCase(decodeURIComponent(parts[typeIndex + 1]));
      }
    } catch (e) {}
    return "-";
  }

  function formatDateTime(ts) {
    if (!ts) return "-";
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${String(d.getFullYear()).slice(-2)} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function getNationalityFlag(nationality) {
    if (!nationality) return "";
    const n = nationality.toLowerCase().trim();

    const map = {
      romanian: "🇷🇴",
      romania: "🇷🇴",
      moldovan: "🇲🇩",
      moldova: "🇲🇩",
      colombian: "🇨🇴",
      brazilian: "🇧🇷",
      spanish: "🇪🇸",
      spain: "🇪🇸",
  french: "🇫🇷",
      italian: "🇮🇹",
      british: "🇬🇧",
      english: "🇬🇧",
      ukrainian: "🇺🇦",
      polish: "🇵🇱",
      hungarian: "🇭🇺",
      bulgarian: "🇧🇬",
      portuguese: "🇵🇹",
      german: "🇩🇪",
      belgian: "🇧🇪",
      dutch: "🇳🇱"
    };

    return map[n] || "";
  }

function getGroupColours(group) {
  const idx = FAV_GROUPS.indexOf(group);

const palette = [
  { header: "#FFF4CC", border: "#D8C27A" }, // soft yellow
  { header: "#DCEBFF", border: "#8EB5E8" }, // soft blue
  { header: "#E7D6FF", border: "#B08BE0" }, // soft purple
  { header: "#DDF5E2", border: "#8BC49A" }, // soft green
  { header: "#FFDCDC", border: "#D89A9A" }, // soft red
  { header: "#FFE6CC", border: "#D8A877" }, // soft orange
  { header: "#DDF8F5", border: "#82C9C1" }, // soft teal
  { header: "#FFE0F0", border: "#D694BA" }, // soft pink
  { header: "#EEF7C9", border: "#B6CD67" }, // soft lime
  { header: "#E4E4FF", border: "#9D9DE0" }  // soft lavender
];

  // 🔥 repeat colours after 10th group
  const selected = palette[idx % palette.length];

  return {
    header: selected.header,
    card: selected.header,
    border: selected.border
  };
}

function getFilters(callback) {

  chrome.storage.local.get([FILTERS_KEY], function (res) {

    const f = res[FILTERS_KEY] || {};

    callback({
      includeBlankPrices: f.includeBlankPrices !== false,

      inc15m40: !!f.inc15m40,

      exc15m40: !!f.exc15m40,

      price15m: Number(f.price15m || 40),

      op15m: f.op15m || "eq",

      inc30m60: !!f.inc30m60,

      exc30m60: !!f.exc30m60,

      price30m: Number(f.price30m || 60),

      op30m: f.op30m || "eq",

      inc1hr120: !!f.inc1hr120,

      exc1hr120: !!f.exc1hr120,

      price1hr: Number(f.price1hr || 120),

      op1hr: f.op1hr || "eq",

      nat1: f.nat1 || "",

      nat2: f.nat2 || "",

      nat3: f.nat3 || "",

      incNat1: !!f.incNat1,

      excNat1: !!f.excNat1,

      incNat2: !!f.incNat2,

      excNat2: !!f.excNat2,

      incNat3: !!f.incNat3,

      excNat3: !!f.excNat3

    });

  });

}

function pricePasses(value, operator, target, isInclude) {
  const n = parseMoneyNumber(value);
  const isBlank = n === null;

  // Include = match OR blank
  if (isInclude) {
    if (isBlank) return true;
    if (operator === "lt") return n < target;
    if (operator === "eq") return n === target;
    if (operator === "gt") return n > target;
    return true;
  }

  // Exclude = exclude only actual matching values, not blanks
  if (isBlank) return true;
  if (operator === "lt") return !(n < target);
  if (operator === "eq") return n !== target;
  if (operator === "gt") return !(n > target);

  return true;
}

function passesFilters(ad, filters) {

  const n15 = parseMoneyNumber(ad.fmin);

  const n30 = parseMoneyNumber(ad.tmin);

  const n1hr = parseMoneyNumber(ad.hr);

  if (filters.includeBlankPrices === false) {
    if ((filters.inc15m40 || filters.exc15m40) && n15 === null) return false;
    if ((filters.inc30m60 || filters.exc30m60) && n30 === null) return false;
    if ((filters.inc1hr120 || filters.exc1hr120) && n1hr === null) return false;
  }

  const nat = normalizeNationality(ad.nationality);

  const isNatBlank = !nat || nat === "-";

  function priceIncludeMatch(value, target, op) {

    if (value === null) return true;

    if (op === "lt") return value < target;

    if (op === "gt") return value > target;

    return value === target;

  }

  function priceExcludeMatch(value, target, op) {

    if (value === null) return false;

    if (op === "lt") return value < target;

    if (op === "gt") return value > target;

    return value === target;

  }

  if (filters.inc15m40 && !priceIncludeMatch(n15, filters.price15m, filters.op15m)) return false;

  if (filters.exc15m40 && priceExcludeMatch(n15, filters.price15m, filters.op15m)) return false;

  if (filters.inc30m60 && !priceIncludeMatch(n30, filters.price30m, filters.op30m)) return false;

  if (filters.exc30m60 && priceExcludeMatch(n30, filters.price30m, filters.op30m)) return false;

  if (filters.inc1hr120 && !priceIncludeMatch(n1hr, filters.price1hr, filters.op1hr)) return false;

  if (filters.exc1hr120 && priceExcludeMatch(n1hr, filters.price1hr, filters.op1hr)) return false;

  const includeNats = [];

  const excludeNats = [];

  if (filters.incNat1 && filters.nat1) includeNats.push(normalizeNationality(filters.nat1));

  if (filters.incNat2 && filters.nat2) includeNats.push(normalizeNationality(filters.nat2));

  if (filters.incNat3 && filters.nat3) includeNats.push(normalizeNationality(filters.nat3));

  if (filters.excNat1 && filters.nat1) excludeNats.push(normalizeNationality(filters.nat1));

  if (filters.excNat2 && filters.nat2) excludeNats.push(normalizeNationality(filters.nat2));

  if (filters.excNat3 && filters.nat3) excludeNats.push(normalizeNationality(filters.nat3));

  // INCLUDE nationality = match any selected include nationality OR blank

  if (includeNats.length > 0 && !includeNats.includes(nat) && !isNatBlank) return false;

  // EXCLUDE nationality = exclude only actual matching values, not blanks

  if (excludeNats.includes(nat)) return false;

  return true;

}
  function getDescriptionTextFromHtml(html) {
    if (!html) return "";

    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/\s+/g, " ")
      .trim();

    const lower = text.toLowerCase();
    const start = lower.indexOf("description");
    if (start === -1) return "";

    const adIdIndex = lower.indexOf("ad id", start);
    const contactIndex = lower.indexOf("contact the advertiser", start);

    let end = -1;
    if (adIdIndex !== -1 && contactIndex !== -1) end = Math.min(adIdIndex, contactIndex);
    else if (adIdIndex !== -1) end = adIdIndex;
    else if (contactIndex !== -1) end = contactIndex;

    if (end === -1 || end <= start) return "";

    return text.substring(start + "description".length, end).trim().toLowerCase();
  }

  function hasVideoKeyword(text) {
    if (!text) return false;
    return (
      text.includes("facetime") ||
      text.includes("whatsapp") ||
      text.includes("video call") ||
      text.includes("videocall") ||
      /\bvideo\w*/i.test(text) ||
      /\bconfirm\w*/i.test(text)
    );
  }

  function getBestImage(tempElement) {
    const selectors = [
      'meta[property="og:image"]',
      ".kiwii-carousel img",
      ".gallery img",
      ".swiper img",
      ".slick-slide img",
      ".vs-image img",
      "img"
    ];

    for (const selector of selectors) {
      const el = tempElement.querySelector(selector);
      if (!el) continue;

      let src = "";
      if (el.tagName && el.tagName.toLowerCase() === "meta") {
        src = el.getAttribute("content") || "";
      } else {
        src =
          el.getAttribute("src") ||
          el.getAttribute("data-src") ||
          el.getAttribute("data-lazy-src") ||
          "";
      }

      if (src && !src.startsWith("data:")) return src;
    }

    return "";
  }

const storageJobs = new Map();
function serialStorage(key, job) {
  const previous = storageJobs.get(key) || Promise.resolve();
  const next = previous.then(() => new Promise(resolve => job(resolve)));
  storageJobs.set(key, next.catch(console.error));
}

function upsertAdMeta(url, patch, callback) {
  serialStorage(AD_META_KEY, done => writeAdMeta(url, patch, value => {
    done();
    if (callback) callback(value);
  }));
}

  function writeAdMeta(url, patch, callback) {
    chrome.storage.local.get([AD_META_KEY], function (res) {
      const data = res[AD_META_KEY] || {};
      const key = cleanLink(url);
      const now = Date.now();

      if (!data[key]) {
        data[key] = { firstSeen: now, lastSeen: now };
      } else {
        if (!data[key].firstSeen) data[key].firstSeen = now;
        data[key].lastSeen = now;
      }

      const existingPreferredImage = data[key].preferredImage || "";

      Object.assign(data[key], patch || {});

      if (existingPreferredImage && (!patch || !patch.preferredImage)) {
        data[key].preferredImage = existingPreferredImage;
        data[key].image = existingPreferredImage;
      }
      chrome.storage.local.set({ [AD_META_KEY]: data }, function () {
        if (callback) callback(data[key]);
      });
    });
  }

function storeNumber(rawDigits, link, advertData, callback) {
  serialStorage(NUMBERS_KEY, done => writeNumber(rawDigits, link, advertData, links => {
    done();
    if (callback) callback(links);
    document.querySelectorAll(".vs-phone-line[data-vs-phone]").forEach(line => {
      if (line.dataset.vsPhone === rawDigits) renderPhoneMatches(line, [...links].sort((a,b) => b.ts-a.ts), line.dataset.vsUrl);
    });
  }));
}

  function writeNumber(rawDigits, link, advertData, callback) {
    chrome.storage.local.get([NUMBERS_KEY, AD_META_KEY], function (res) {      const numbers = res[NUMBERS_KEY] || {};
      const clean = cleanLink(link);
      const metaCache = res[AD_META_KEY] || {};
      const savedMeta = metaCache[clean] || {};

      if (savedMeta.preferredImage) {
        advertData.image = savedMeta.preferredImage;
      } else if (savedMeta.image) {
        advertData.image = savedMeta.image;
      }

      if (!numbers[rawDigits]) numbers[rawDigits] = { links: [] };

      const exists = numbers[rawDigits].links.find((item) => item.url === clean);

      if (!exists) {
        numbers[rawDigits].links.push({
          url: clean,
          title: advertData.title || clean,
          price: advertData.price || "-",
      preferredImage: advertData.preferredImage || "",
image: advertData.image || "",
fmin: advertData.fmin || "-",
tmin: advertData.tmin || "-",
hr: advertData.hr || "-",
nationality: advertData.nationality || "-",
age: advertData.age || "-",
area: advertData.area || "-",
displayPhone: advertData.displayPhone || "-",
ts: Date.now()
        });
      } else {
        Object.assign(exists, {
          title: advertData.title || exists.title,
          price: advertData.price || exists.price,
      preferredImage: advertData.preferredImage || exists.preferredImage,
image: advertData.image || exists.image,
fmin: advertData.fmin || exists.fmin,
tmin: advertData.tmin || exists.tmin,
hr: advertData.hr || exists.hr,
nationality: advertData.nationality || exists.nationality,
age: advertData.age || exists.age,
area: advertData.area || exists.area,
displayPhone: advertData.displayPhone || exists.displayPhone,
ts: Date.now()
        });
      }

      chrome.storage.local.set({ [NUMBERS_KEY]: numbers }, function () {
        if (callback) callback(numbers[rawDigits].links);
      });
    });
  }

  function extractAdvertiserInfo(tempElement) {
    const anchors = Array.from(tempElement.querySelectorAll("a[href]"));
    const found = anchors.find((a) => {
      const href = a.getAttribute("href") || "";
      const txt = (a.textContent || "").trim().toLowerCase();
      return href.includes("/profile/ind/") || txt.includes("posted by #");
    });

    if (!found) return null;

    const href = found.getAttribute("href") || "";
    let absoluteUrl = href.startsWith("http") ? href : new URL(href, location.origin).href;

    if (!absoluteUrl.includes("show_personal_ads=1")) {
      absoluteUrl += (absoluteUrl.includes("?") ? "&" : "?") + "show_personal_ads=1";
    }

    const m = absoluteUrl.match(/\/profile\/ind\/(\d+)/i);
    const id = m ? m[1] : null;

    return { id, url: absoluteUrl, label: (found.textContent || "").trim() };
  }

  function extractPreviewFromAdvertiserCard(anchor, adMetaCache) {
    const href = cleanLink(anchor.href || anchor.getAttribute("href") || "");
    const container = getListingCardFromLink(anchor) || anchor.parentElement;

    const cached = adMetaCache && adMetaCache[href] ? adMetaCache[href] : null;

    let title = "";
    if (cached && cached.title) {
      title = cached.title;
    } else {
      title = (anchor.textContent || "").trim();
      if ((!title || title.length < 4) && container) {
        const h = container.querySelector("h1,h2,h3,.clad__title,a");
        if (h) title = (h.textContent || "").trim();
      }
    }

    let image = "";
    if (cached && (cached.preferredImage || cached.image)) {
      image = cached.preferredImage || cached.image;
    } else if (container) {
      const img = getAdvertPhoto(container);
      if (img) {
        image =
          img.getAttribute("src") ||
          img.getAttribute("data-src") ||
          img.getAttribute("data-lazy-src") ||
          "";
      }
    }

    let price = "-";
    if (cached && cached.price) {
      price = cached.price;
    } else if (container) {
      const txt = container.innerText || "";
      const incall = txt.match(/incall\s*£\s*\d+\/h/i);
      const pound = txt.match(/£\s*\d+\/h/i) || txt.match(/£\s*\d+/i);
      price = (incall && incall[0]) || (pound && pound[0]) || "-";
    }

return {
      url: href,
      title: title || href,
      preferredImage: (cached && cached.preferredImage) || "",
      image: image || "",
      price: price || "-",
      fmin: (cached && cached.fmin) || "-",
      tmin: (cached && cached.tmin) || "-",
      hr: (cached && cached.hr) || "-",
      nationality: (cached && cached.nationality) || "-",
      age: (cached && cached.age) || "-",
      area: (cached && cached.area) || extractAreaFromUrl(href) || "-",
      displayPhone: (cached && cached.displayPhone) || "-"
    };
  }

  function parseAdvertiserAds(html, currentUrl, callback) {
    const temp = document.createElement("div");
    temp.innerHTML = html;

    chrome.storage.local.get([AD_META_KEY], function (res) {
      const adMetaCache = res[AD_META_KEY] || {};

      const anchors = Array.from(temp.querySelectorAll("a[href]")).filter((a) => {
        const href = cleanLink(a.href || a.getAttribute("href") || "");
        const text = (a.textContent || "").trim().toLowerCase();

        if (!href) return false;
        if (text === "log out" || text === "logout") return false;
        if (href.includes("/profile/")) return false;
        if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(href)) return false;

        return /\/\d{6,}$/.test(href);
      });

      const seen = new Set();
      const ads = [];

      anchors.forEach((a) => {
        const href = cleanLink(a.href || a.getAttribute("href") || "");
        if (!href) return;
        if (cleanLink(href) === cleanLink(currentUrl)) return;
        if (seen.has(href)) return;

        seen.add(href);

        const item = extractPreviewFromAdvertiserCard(a, adMetaCache);
        if (!item || !item.url) return;

        ads.push(item);
      });

      callback(ads);
    });
  }

function preferRealValue(primary, fallback) {
  if (primary === undefined || primary === null) return fallback || "-";
  const value = String(primary).trim();
  if (!value || value === "-") return fallback || "-";
  return primary;
}

function enrichAdvertiserAds(ads, callback) {
  if (!ads || !ads.length) {
    callback([]);
    return;
  }

  let index = 0;
  let active = 0;
  const maxActive = 3;
  const enriched = [];

  function pump() {
    while (active < maxActive && index < ads.length) {
      const item = ads[index++];
      active++;

      fetchDetailOnce(item.url, function (response) {
        active--;

        if (response && response.html) {
          const data = extractAdvertDataForPagination(item.url, response.html);

          enriched.push({
            ...item,
            title: data.title || item.title,
            image: item.preferredImage || item.image || data.image || "",
            preferredImage: item.preferredImage || "",
          fmin: preferRealValue(data.fmin, item.fmin),
tmin: preferRealValue(data.tmin, item.tmin),
hr: preferRealValue(data.hr, item.hr),
nationality: preferRealValue(data.nationality, item.nationality),
age: preferRealValue(data.age, item.age),
area: preferRealValue(data.area, item.area),
displayPhone: preferRealValue(data.displayPhone, item.displayPhone)
          });

          upsertAdMeta(item.url, {
            title: data.title,
            image: item.preferredImage || item.image || data.image,
            fmin: data.fmin,
            tmin: data.tmin,
            hr: data.hr,
            nationality: data.nationality,
            age: data.age,
            area: data.area,
            displayPhone: data.displayPhone,
            rawWhatsappDigits: data.rawWhatsappDigits
          });
        } else {
          enriched.push(item);
        }

        if (index >= ads.length && active === 0) {
          callback(enriched);
          return;
        }

        pump();
      });
    }
  }

  pump();
}

const advertiserRequests = new Map();
function fetchAdvertiserAds(advertiserId, advertiserUrl, currentUrl, callback) {
  let request = advertiserRequests.get(advertiserId);
  if (!request) {
    request = new Promise(resolve => loadAdvertiserAds(advertiserId, advertiserUrl, "", resolve));
    advertiserRequests.set(advertiserId, request);
    request.then(ads => { if (ads === null) advertiserRequests.delete(advertiserId); });
  }
  request.then(ads => callback(ads && ads.filter(item => cleanLink(item.url) !== cleanLink(currentUrl))));
}

  function loadAdvertiserAds(advertiserId, advertiserUrl, currentUrl, callback) {
    if (!advertiserId || !advertiserUrl) {
      callback([]);
      return;
    }

    chrome.storage.local.get([ADVERTISER_CACHE_KEY], function (res) {
      const cache = res[ADVERTISER_CACHE_KEY] || {};
      const cached = cache[advertiserId];

      if (cached && cached.cacheVersion === 4 && cached.fetchedAt && Date.now() - cached.fetchedAt < 10 * 60 * 1000) {
        const filtered = (cached.ads || []).filter(
          (x) => cleanLink(x.url) !== cleanLink(currentUrl)
        );
        callback(filtered);
        return;
      }

      chrome.runtime.sendMessage({ action: "fetchHTML", url: advertiserUrl }, function (response) {
        if (!response || !response.html) {
          callback(null);
          return;
        }

parseAdvertiserAds(response.html, "", function (ads) {
  enrichAdvertiserAds(ads, function (fullAds) {
    cache[advertiserId] = { fetchedAt: Date.now(), cacheVersion: 4, ads: fullAds };

    serialStorage(ADVERTISER_CACHE_KEY, done => chrome.storage.local.get([ADVERTISER_CACHE_KEY], latest => {
    chrome.storage.local.set({ [ADVERTISER_CACHE_KEY]: { ...(latest[ADVERTISER_CACHE_KEY] || {}), [advertiserId]: cache[advertiserId] } }, function () {
      done();
      callback(fullAds.filter(item => cleanLink(item.url) !== cleanLink(currentUrl)));
    });
    }));
  });
});
      });
    });
  }

function createWhatsAppButton(rawDigits) {
  const btn = document.createElement("span");
  btn.className = "vs-whatsapp-button";
  btn.style.flex = "0 0 28px";
  btn.style.width = "28px";
  btn.style.minWidth = "28px";
  btn.style.height = "28px";
attachFastTooltip(btn, "WhatsApp");

  btn.style.cursor = "pointer";
  btn.style.marginLeft = "6px";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.verticalAlign = "middle";

  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 32 32">
      <path fill="#25D366" d="M16 .4C7.3.4.4 7.3.4 16c0 2.8.7 5.4 2 7.7L0 32l8.5-2.2c2.2 1.2 4.7 1.9 7.5 1.9 8.7 0 15.6-6.9 15.6-15.6S24.7.4 16 .4z"/>
      <path fill="#fff" d="M24.1 19.3c-.4-.2-2.3-1.1-2.6-1.3-.4-.1-.6-.2-.9.2-.2.4-1 1.3-1.2 1.6-.2.2-.4.3-.8.1-.4-.2-1.6-.6-3-1.9-1.1-1-1.9-2.3-2.1-2.7-.2-.4 0-.6.2-.8.2-.2.4-.4.6-.7.2-.2.2-.4.4-.6.1-.2.1-.5 0-.7-.1-.2-.9-2.2-1.2-3-.3-.8-.6-.7-.9-.7h-.8c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.7 0 1.6 1.2 3.2 1.3 3.4.2.2 2.3 3.6 5.6 5 .8.3 1.4.5 1.9.7.8.2 1.6.2 2.2.1.7-.1 2.3-.9 2.6-1.8.3-.9.3-1.6.2-1.8-.1-.2-.3-.3-.7-.5z"/>
    </svg>
  `;

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

  const message = prompt("Type WhatsApp message:", vsWaLastMessage);

  if (!message || !message.trim()) return;

  const cleanMessage = message.trim();

  vsWaMessageRevision++;
  vsWaLastMessage = cleanMessage;
  chrome.storage.local.set({ [VS_WA_LAST_MESSAGE_KEY]: cleanMessage }, () => {
    const error = chrome.runtime.lastError;
    if (error) alert("WhatsApp message could not be saved: " + error.message);
  });
  // Open directly in the user's click, not an asynchronous storage callback.
  window.open(`https://wa.me/${rawDigits}?text=${encodeURIComponent(cleanMessage)}`, "_blank", "noopener");
  };

  return btn;
}


function createReverseImageButtons(imageUrl) {
  if (!imageUrl) return document.createTextNode("");

  const wrap = document.createElement("span");
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.gap = "5px";
  wrap.style.marginLeft = "8px";
  wrap.style.verticalAlign = "middle";

  const encoded = encodeURIComponent(imageUrl);

  const engines = [
    {
      title: "Google Lens",
      url: `https://lens.google.com/uploadbyurl?url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
          <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
          <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
          <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
          <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
          <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
          <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
          <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
          <circle cx="24" cy="24" r="8" fill="#4285F4"/>
          <circle cx="24" cy="24" r="4" fill="#fff"/>
        </svg>
      `
    },
    {
      title: "Yandex Image Search",
      url: `https://yandex.com/images/search?rpt=imageview&url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
          <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial, sans-serif" font-weight="700" fill="#fff">Y</text>
        </svg>
      `
    },
    {
      title: "TinEye",
      url: `https://tineye.com/search?url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#111827"/>
          <circle cx="24" cy="24" r="11" fill="#fff"/>
          <circle cx="24" cy="24" r="6" fill="#2563EB"/>
          <circle cx="28" cy="20" r="2" fill="#fff"/>
        </svg>
      `
    }
  ];

  engines.forEach((engine) => {
    const btn = document.createElement("span");
    btn.innerHTML = engine.svg;
    btn.style.cursor = "pointer";
    btn.style.display = "inline-flex";
    btn.style.alignItems = "center";
    btn.style.justifyContent = "center";
    btn.style.width = "20px";
    btn.style.height = "20px";
    btn.style.verticalAlign = "middle";

    btn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      window.open(engine.url, "_blank");
    };

    wrap.appendChild(btn);
  });

  return wrap;
}

function getCurrentAdvertImageUrl() {
  // 1. Find the main visible gallery/image area
  const gallery =
    document.querySelector(".kiwii-carousel") ||
    document.querySelector(".gallery") ||
    document.querySelector(".swiper") ||
    document.querySelector(".slick-slider") ||
    document.querySelector("main");

  if (!gallery) return "";

  const rect = gallery.getBoundingClientRect();

  // 2. Look at the centre of the gallery currently on screen
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;

  const elements = document.elementsFromPoint(x, y);

  // 3. Find the actual image currently visible at that point
  let img =
    elements.find((el) => el.tagName && el.tagName.toLowerCase() === "img") ||
    elements.map((el) => el.querySelector && el.querySelector("img")).find(Boolean);

  // 4. Fallback: largest visible image
  if (!img) {
    img = Array.from(document.querySelectorAll("img"))
      .filter((image) => {
        const r = image.getBoundingClientRect();
        return (
          r.width > 250 &&
          r.height > 250 &&
          r.left < window.innerWidth &&
          r.right > 0 &&
          r.top < window.innerHeight &&
          r.bottom > 0
        );
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return br.width * br.height - ar.width * ar.height;
      })[0];
  }

  if (!img) return "";

  let src =
    img.currentSrc ||
    img.getAttribute("src") ||
    img.getAttribute("data-src") ||
    img.getAttribute("data-lazy-src") ||
    "";

  if (!src || src.startsWith("data:")) return "";

  if (src.startsWith("/")) {
    src = new URL(src, location.origin).href;
  }

  return src;
}
function getAllAdvertImageUrls() {
  const root =
    document.querySelector(".kiwii-carousel") ||
    document.querySelector(".gallery") ||
    document.querySelector(".swiper") ||
    document.querySelector(".slick-slider") ||
    document.querySelector("[class*='carousel']") ||
    document.querySelector("[class*='gallery']") ||
    document.querySelector("main");

  if (!root) return [];

  const urls = [];

  root.querySelectorAll("img").forEach((img) => {
    let src =
      img.currentSrc ||
      img.getAttribute("src") ||
      img.getAttribute("data-src") ||
      img.getAttribute("data-lazy-src") ||
      "";

    if (!src || src.startsWith("data:")) return;

    if (src.startsWith("/")) {
      src = new URL(src, location.origin).href;
    }

    if (/logo|icon|avatar|placeholder|sprite/i.test(src)) return;

    urls.push(src);
  });

  return Array.from(new Set(urls));
}

function createSmsButton(rawDigits) {
  const btn = document.createElement("a");
  btn.className = "vs-sms-button";
  btn.textContent = "💬";
  btn.href = `sms:+${getRawWhatsappDigits(rawDigits)}`;
  btn.setAttribute("aria-label", "Send SMS");
  btn.style.cssText = "display:inline-flex;align-items:center;vertical-align:middle;margin-left:6px;font-size:26px;line-height:28px;text-decoration:none;cursor:pointer";
  btn.style.flex = "0 0 28px";
  btn.style.width = "28px";
  btn.style.minWidth = "28px";
  btn.style.height = "28px";
  attachFastTooltip(btn, "SMS / Message");
  btn.addEventListener("click", e => e.stopPropagation());
  return btn;
}

function injectAdvertMessageButtons() {
  if (!isAdvertPage()) return;
  const phone = document.querySelector(".phone_link");
  const digits = getRawWhatsappDigits(phone?.getAttribute("data-phone-number") || phone?.textContent || "");
  if (!phone || !digits || !phone.parentElement) return;
  let wrap = document.getElementById("vs-advert-message-buttons");
  if (wrap && wrap.dataset.vsPhone === digits && wrap.isConnected) return;
  if (wrap) wrap.remove();
  wrap = document.createElement("span");
  wrap.id = "vs-advert-message-buttons";
  wrap.dataset.vsPhone = digits;
  protectControls(wrap);
  wrap.append(createWhatsAppButton(digits), createSmsButton(digits));
  (phone.closest("a") || phone).after(wrap);
}

function getAllAdvertImageUrlsFromHtml(tempElement) {
  if (!tempElement) return [];

  const urls = [];

  const gallery =
    tempElement.querySelector("#vs_photo_viewer_container") ||
    tempElement.querySelector("[data-automation='divDetailCarouselContainer'] .kiwii-carousel") ||
    tempElement.querySelector(".kiwii-carousel") ||
    tempElement.querySelector(".gallery") ||
    tempElement.querySelector(".swiper") ||
    tempElement.querySelector(".slick-slider") ||
    tempElement.querySelector("[data-testid*='gallery']") ||
    tempElement.querySelector("[data-automation*='gallery']") ||
    tempElement.querySelector("[class*='gallery']") ||
    tempElement.querySelector("[class*='carousel']") ||
    tempElement.querySelector("[class*='slider']");

  if (!gallery) return [];

  gallery.querySelectorAll("img").forEach((img) => {
    let src = ["data-src", "data-lazy-src", "src", "data-srcset", "srcset"]
      .map((attr) => img.getAttribute(attr) || "")
      .map((value) => value.trim().split(/\s+/)[0].replace(/,$/, ""))
      .find((value) => value && !value.startsWith("data:") && !/placeholder|sprite/i.test(value)) || "";

    if (!src || src.startsWith("data:")) return;

    if (src.includes(",")) {
      src = src.split(",")[0].trim().split(" ")[0];
    }

    if (src.startsWith("/")) {
      src = new URL(src, location.origin).href;
    }

    const lower = src.toLowerCase();

    if (
      lower.includes("logo") ||
      lower.includes("icon") ||
      lower.includes("avatar") ||
      lower.includes("placeholder") ||
      lower.includes("sprite") ||
      lower.includes("profile")
    ) {
      return;
    }

    if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(src)) return;

    const cleanSrc = normaliseImageIdentity(src);

    urls.push({
      original: src,
      clean: cleanSrc
    });
  });

  const unique = [];
  const seen = new Set();

  urls.forEach((item) => {
    if (seen.has(item.clean)) return;
    seen.add(item.clean);
    unique.push(item.original);
  });

  return unique.slice(0, 12);
}

function showListingImagePreview(e, imageUrl) {
  document.querySelectorAll(".vs-image-hover-preview").forEach((x) => x.remove());

  const popup = document.createElement("div");
  popup.className = "vs-image-hover-preview";

  popup.style.position = "fixed";
  popup.style.zIndex = "999999";
  popup.style.background = "#fff";
  popup.style.border = "1px solid #d9d9d9";
  popup.style.borderRadius = "10px";
  popup.style.boxShadow = "0 8px 24px rgba(0,0,0,0.22)";
  popup.style.padding = "6px";
  popup.style.pointerEvents = "none";

  const img = document.createElement("img");
  img.src = imageUrl;
  img.style.width = "260px";
  img.style.height = "320px";
  img.style.objectFit = "cover";
  img.style.borderRadius = "8px";
  img.style.display = "block";

  popup.appendChild(img);
  document.body.appendChild(popup);

  let left = e.clientX + 12;
  let top = e.clientY + 12;

  const rect = popup.getBoundingClientRect();

  if (left + rect.width > window.innerWidth - 10) {
    left = window.innerWidth - rect.width - 10;
  }

  if (top + rect.height > window.innerHeight - 10) {
    top = window.innerHeight - rect.height - 10;
  }

  popup.style.left = `${left}px`;
  popup.style.top = `${top}px`;
}

function addListingThumbnailStrip(card, imageUrls) {
  if (!card || !imageUrls || !imageUrls.length) return;
  card.dataset.vsGalleryExpected = String(imageUrls.length);

  const old = card.querySelector(".vs-listing-thumb-strip");
  const imageSignature = imageUrls.join("|");
  if (old && old.dataset.vsImageSignature === imageSignature) return;
  const mainImg = getAdvertPhoto(card);
  const independentStrip = card.matches('li[id^="classified-"], .vs-search-shadow');
  if (!mainImg && !independentStrip) return;
  const insertTarget =
    mainImg && (mainImg.closest("picture") ||
    mainImg.closest("a") ||
    mainImg.parentElement);

  if (!independentStrip && (!insertTarget || !insertTarget.parentElement)) return;
  if (old) old.remove();

  const strip = document.createElement("div");
  strip.className = "vs-listing-thumb-strip";
  protectControls(strip);
  strip.dataset.vsImageSignature = imageSignature;

  strip.style.display = "flex";
  strip.style.gap = "5px";
  strip.style.margin = "6px 0 8px 0";
  strip.style.padding = "3px 0";
  strip.style.overflowX = "auto";
  strip.style.maxWidth = "100%";

  imageUrls.forEach((url) => {
    const thumb = document.createElement("img");
    thumb.src = url;

    thumb.style.width = "44px";
    thumb.style.height = "52px";
    thumb.style.objectFit = "cover";
    thumb.style.borderRadius = "6px";
    thumb.style.cursor = "pointer";
    thumb.style.border = "1px solid rgba(0,0,0,0.18)";
    thumb.style.flex = "0 0 auto";

    thumb.onmouseenter = function (e) {
      showListingImagePreview(e, url);
    };

    thumb.onmousemove = function (e) {
      showListingImagePreview(e, url);
    };

    thumb.onmouseleave = function () {
      document.querySelectorAll(".vs-image-hover-preview").forEach((x) => x.remove());
    };

thumb.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  const advertLink =
    card.querySelector("a.clad__ad_link") ||
    card.querySelector("a[href*='/escort/']") ||
    card.querySelector("a[href*='/massage/']") ||
    card.querySelector("a[href*='/escorts/']");

  if (advertLink && advertLink.href) {
    window.open(advertLink.href, "_blank");
  }
};

    strip.appendChild(thumb);
  });

  if (independentStrip) {
    // A sibling of the native card avoids its fixed-aspect slider and clipping.
    card.appendChild(strip);
  } else insertTarget.parentElement.insertBefore(strip, insertTarget.nextSibling);
}

function savePreferredMainImage(imageUrl) {
  if (!imageUrl) return;

  upsertAdMeta(cleanLink(location.href), {
    preferredImage: imageUrl,
    image: imageUrl
  }, function () {
    chrome.storage.local.get([AD_META_KEY], function (res) {
      const meta = (res[AD_META_KEY] || {})[cleanLink(location.href)] || {};

      if (meta.preferredImage === imageUrl) {
        alert("Main picture saved.");
      } else {
        alert("Save failed.");
      }
    });
  });
}

function injectPreferredMainImageButton() {
  if (!isAdvertPage()) return;

  if (document.getElementById("vs-main-image-picker")) return;

  const wrap = document.createElement("div");
  wrap.id = "vs-main-image-picker";

  wrap.style.background = "rgba(255,255,255,0.96)";
  wrap.style.border = "1px solid rgba(0,0,0,0.15)";
  wrap.style.borderRadius = "10px";
  wrap.style.padding = "8px";
  wrap.style.boxShadow = "0 4px 14px rgba(0,0,0,0.18)";
  wrap.style.fontFamily = "Arial, sans-serif";
  wrap.style.display = "block";
  wrap.style.width = "fit-content";
  wrap.style.margin = "8px 0 10px 0";

  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Set Filter Pic";
attachFastTooltip(btn, "Choose image used in Filtered Matches");

  btn.style.border = "0";
  btn.style.borderRadius = "8px";
  btn.style.padding = "7px 10px";
  btn.style.cursor = "pointer";
  btn.style.fontWeight = "800";
  btn.style.background = "#25D366";
  btn.style.color = "#fff";
  btn.style.fontSize = "12px";

  const panel = document.createElement("div");
  panel.style.display = "none";
  panel.style.marginTop = "8px";
  panel.style.width = "260px";
  panel.style.maxHeight = "360px";
  panel.style.overflow = "auto";
  panel.style.display = "none";
  panel.style.gridTemplateColumns = "repeat(3, 1fr)";
  panel.style.gap = "6px";

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    panel.innerHTML = "";

    const imgs = getAllAdvertImageUrls();

    if (!imgs.length) {
      alert("No advert images found.");
      return;
    }

    chrome.storage.local.get([AD_META_KEY], function (res) {
      const meta = (res[AD_META_KEY] || {})[cleanLink(location.href)] || {};
      const savedImage = meta.preferredImage || meta.image || "";

      imgs.forEach((url) => {
        const img = document.createElement("img");
        img.src = url;

        img.style.width = "78px";
        img.style.height = "86px";
        img.style.objectFit = "cover";
        img.style.borderRadius = "7px";
        img.style.cursor = "pointer";
        img.style.border = savedImage === url ? "2px solid #25D366" : "2px solid transparent";
        img.style.boxSizing = "border-box";

        img.onclick = function (ev) {
          ev.preventDefault();
          ev.stopPropagation();

          savePreferredMainImage(url);

          panel.querySelectorAll("img").forEach((x) => {
            x.style.border = "2px solid transparent";
          });

          img.style.border = "2px solid #25D366";
        };

        panel.appendChild(img);
      });

      panel.style.display = panel.style.display === "none" ? "grid" : "none";
    });
  };

  wrap.appendChild(btn);
  wrap.appendChild(panel);

  const gallery =
    document.querySelector(".kiwii-carousel") ||
    document.querySelector(".gallery") ||
    document.querySelector(".swiper") ||
    document.querySelector(".slick-slider") ||
    document.querySelector("[class*='carousel']") ||
    document.querySelector("[class*='gallery']");

  if (gallery && gallery.parentElement) {
    gallery.parentElement.insertBefore(wrap, gallery.nextSibling);
  } else {
    document.body.appendChild(wrap);
  }
}
function createReverseImageAdvertButtons() {
  const old = document.getElementById("vs-reverse-image-buttons");
  if (old) old.remove();

  const wrap = document.createElement("div");
  wrap.id = "vs-reverse-image-buttons";
  wrap.style.position = "fixed";
  wrap.style.top = "90px";
  wrap.style.right = "18px";
  wrap.style.zIndex = "999999";
  wrap.style.display = "flex";
  wrap.style.gap = "8px";
  wrap.style.alignItems = "center";
  wrap.style.padding = "8px";
  wrap.style.borderRadius = "10px";
  wrap.style.background = "rgba(255,255,255,0.96)";
  wrap.style.border = "1px solid rgba(0,0,0,0.15)";
  wrap.style.boxShadow = "0 4px 14px rgba(0,0,0,0.18)";

  const engines = [
    {
      title: "Google Lens",
      getUrl: (img) => `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
          <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
          <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
          <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
          <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
          <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
          <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
          <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
          <circle cx="24" cy="24" r="8" fill="#4285F4"/>
          <circle cx="24" cy="24" r="4" fill="#fff"/>
        </svg>
      `
    },
    {
      title: "Yandex Image Search",
      getUrl: (img) => `https://yandex.com/images/search?rpt=imageview&url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
          <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial" font-weight="700" fill="#fff">Y</text>
        </svg>
      `
    },
    {
      title: "TinEye",
      getUrl: (img) => `https://tineye.com/search?url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#111827"/>
          <circle cx="24" cy="24" r="11" fill="#fff"/>
          <circle cx="24" cy="24" r="6" fill="#2563EB"/>
          <circle cx="28" cy="20" r="2" fill="#fff"/>
        </svg>
      `
    }
  ];

  engines.forEach((engine) => {
    const btn = document.createElement("span");
 attachFastTooltip(btn, engine.title);
    btn.innerHTML = engine.svg;
    btn.style.cursor = "pointer";
    btn.style.display = "inline-flex";
    btn.style.alignItems = "center";
    btn.style.justifyContent = "center";
    btn.style.width = "22px";
    btn.style.height = "22px";

    btn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      const currentImage = getCurrentAdvertImageUrl();

      if (!currentImage) {
        alert("No advert image found.");
        return;
      }

      window.open(engine.getUrl(currentImage), "_blank");
    };

    wrap.appendChild(btn);
  });

  document.body.appendChild(wrap);
}

  function createPhoneMatchElement() {
    const el = document.createElement("span");
    el.textContent = "☎️";
    el.style.cursor = "pointer";
    el.style.marginLeft = "2px";
    el.style.fontSize = "20px";
    el.style.lineHeight = "20px";
    el.style.verticalAlign = "middle";
    return el;
  }

  function createAdvertiserMatchElement() {
    const el = document.createElement("span");
    el.textContent = "🚺";
    el.style.cursor = "pointer";
    el.style.marginLeft = "2px";
    el.style.fontSize = "20px";
    el.style.lineHeight = "20px";
    el.style.verticalAlign = "middle";
    return el;
  }

  function removeExistingPreview() {
    const existing = document.getElementById("vs-preview-popup");
    if (existing) existing.remove();
  }

  function showPreviewPopup(e, item, accentEmoji) {
    removeExistingPreview();

    const popup = document.createElement("div");
    popup.id = "vs-preview-popup";
    popup.style.position = "fixed";
    popup.style.zIndex = "999999";
    popup.style.background = "#fff";
    popup.style.border = "1px solid #d9d9d9";
    popup.style.borderRadius = "10px";
    popup.style.boxShadow = "0 8px 24px rgba(0,0,0,0.22)";
    popup.style.padding = "10px";
    popup.style.width = "280px";
    popup.style.fontSize = "12px";
    popup.style.lineHeight = "1.35";
    popup.style.color = "#111";

       const popupImage = item.preferredImage || item.image || "";

    if (popupImage) {
      const img = document.createElement("img");
      img.src = popupImage;
      img.style.width = "100%";
      img.style.height = "160px";
      img.style.objectFit = "cover";
      img.style.borderRadius = "8px";
      img.style.display = "block";
      img.style.marginBottom = "8px";
      popup.appendChild(img);
    }

    const title = document.createElement("div");
    title.style.fontWeight = "700";
    title.style.fontSize = "13px";
    title.style.marginBottom = "6px";
    title.textContent = `${accentEmoji || ""} ${
      item.title && item.title !== item.url ? item.title : "Advert"
    }`.trim();

    const rates = document.createElement("div");
    rates.style.color = "#1f4ed8";
    rates.style.fontWeight = "700";
    rates.style.marginBottom = "4px";
    rates.textContent = `15m-${item.fmin || "-"} | 30m-${item.tmin || "-"} | 1hr-${item.hr || "-"}`;

    const meta = document.createElement("div");
    meta.style.color = "#444";
    meta.style.marginBottom = "4px";
meta.textContent = `${getNationalityFlag(item.nationality)} ${item.nationality || "-"} • ${item.age || "-"}`;
    const area = document.createElement("div");
    area.style.color = "#555";
    area.style.marginBottom = "4px";
    area.style.fontWeight = "600";
area.textContent = item.area || "-";

    const phone = document.createElement("div");
    phone.style.color = "#0a7a0a";
    phone.style.fontWeight = "700";
    phone.style.marginBottom = "6px";
phone.textContent = item.displayPhone || "-";
    popup.appendChild(title);
    popup.appendChild(rates);
    popup.appendChild(meta);
    popup.appendChild(area);
    popup.appendChild(phone);

    document.body.appendChild(popup);

    let left = e.clientX + 12;
    let top = e.clientY + 12;

    const rect = popup.getBoundingClientRect();

    if (left + rect.width > window.innerWidth - 10) {
      left = window.innerWidth - rect.width - 10;
    }
    if (top + rect.height > window.innerHeight - 10) {
      top = window.innerHeight - rect.height - 10;
    }

    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;
  }

  function renderPhoneMatches(container, links, currentUrl) {
    if (!container) return;
    container.innerHTML = "Same phone number: ";

    const currentClean = cleanLink(currentUrl);
    const otherLinks = (links || []).filter((item) => cleanLink(item.url) !== currentClean);

    if (otherLinks.length === 0) {
      container.appendChild(document.createTextNode("0"));
      return;
    }

    otherLinks.forEach((item) => {
      const el = createPhoneMatchElement();
      el.title = item.title || item.url;

      el.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.open(item.url, "_blank");
      };

      el.onmouseenter = function (e) {
        showPreviewPopup(e, item, "☎️");
      };

      el.onmousemove = function (e) {
        showPreviewPopup(e, item, "☎️");
      };

      el.onmouseleave = function () {
        removeExistingPreview();
      };

      container.appendChild(el);
    });
  }

  function renderAdvertiserMatches(container, ads) {
    if (!container) return;
    if (ads === null) {
      if (!container.querySelector("span")) container.textContent = "Other Adverts: unavailable";
      return;
    }
    container.innerHTML = "Other Adverts: ";

    if (!ads || ads.length === 0) {
      container.appendChild(document.createTextNode("0"));
      return;
    }

    ads.forEach((item) => {
      const el = createAdvertiserMatchElement();
      el.title = item.title || item.url;

      el.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.open(item.url, "_blank");
      };

      el.onmouseenter = function (e) {
        showPreviewPopup(e, item, "🚺");
      };

      el.onmousemove = function (e) {
        showPreviewPopup(e, item, "🚺");
      };

      el.onmouseleave = function () {
        removeExistingPreview();
      };

      container.appendChild(el);
    });
  }

  function ensureBadgeColumnLayout(card) {
    const side = card.querySelector('[class~="lg:w-50"]');
    const row = side?.parentElement;
    if (!row || !row.classList.contains("lg:flex-row") || row.children.length !== 3) return;
    if (!document.getElementById("vs-card-column-layout")) {
      const style = document.createElement("style");
      style.id = "vs-card-column-layout";
      style.textContent = `@media (min-width:1024px) {
        .vs-card-badge-column { flex:0 0 200px !important; width:200px !important; min-width:200px !important; }
        .vs-card-info-column { min-width:0 !important; flex:1 1 0% !important; overflow-wrap:anywhere; }
      }`;
      (document.head || document.documentElement).appendChild(style);
    }
    side.classList.add("vs-card-badge-column");
    row.children[1].classList.add("vs-card-info-column");
  }

  function addSeenBox(card, metaEntry) {
    ensureBadgeColumnLayout(card);
    card.style.position = "relative";

    let box = card.querySelector(".vs-seen-box");
    if (!box) {
      box = document.createElement("div");
      box.className = "vs-seen-box";
      card.appendChild(box);
    }
    box.style.position = "relative";
    box.style.top = "";
    box.style.right = "";
    box.style.width = "fit-content";
    box.style.margin = "20px 0 6px auto";
    box.style.display = "block";
    box.style.clear = "both";
    box.style.flexShrink = "0";
    box.style.gridColumn = "1 / -1";
    const label = Array.from(card.querySelectorAll("span,p,div")).find(el =>
      !el.querySelector("span,p,div") &&
      !el.closest(".newData,.vs-fav-controls,.vs-seen-box") &&
      /^(Independent|Agency)$/i.test((el.textContent || "").trim())
    );
    let labelAnchor = label?.closest("a") || label;
    // Leave the native badge row before inserting the box: a sibling inside
    // a horizontal flex/inline row can otherwise sit over Independent.
    while (labelAnchor?.parentElement && labelAnchor.parentElement !== card) {
      const parentStyle = getComputedStyle(labelAnchor.parentElement);
      if (!/^(inline|inline-flex|inline-grid)$/.test(parentStyle.display) &&
          !(parentStyle.display === "flex" && !parentStyle.flexDirection.startsWith("column")) &&
          parentStyle.position !== "absolute") break;
      labelAnchor = labelAnchor.parentElement;
    }
    if (label) {
      const labelStyle = getComputedStyle(label);
      const lineHeight = parseFloat(labelStyle.lineHeight) || (parseFloat(labelStyle.fontSize) || 14) * 1.4;
      box.style.marginTop = `${Math.ceil(Math.max(20, lineHeight))}px`;
    }
    if (labelAnchor?.parentElement && card.contains(labelAnchor)) {
      if (labelAnchor.nextElementSibling !== box) labelAnchor.after(box);
    } else if (box.parentElement !== card) card.appendChild(box);
    box.style.zIndex = "20";
    box.style.background = "rgba(255,255,255,0.96)";
    box.style.border = "1px solid rgba(0,0,0,0.15)";
    box.style.borderRadius = "8px";
    box.style.padding = "5px 7px";
    box.style.fontSize = "10px";
    box.style.lineHeight = "1.35";
    box.style.textAlign = "right";
    box.style.boxShadow = "0 2px 6px rgba(0,0,0,0.10)";
    box.style.maxWidth = "145px";

    const firstSeen = metaEntry && metaEntry.firstSeen ? formatDateTime(metaEntry.firstSeen) : "-";
    const lastSeen = metaEntry && metaEntry.lastSeen ? formatDateTime(metaEntry.lastSeen) : "-";

    const seenHtml = `
      <div><strong>First:</strong> ${firstSeen}</div>
      <div><strong>Last:</strong> ${lastSeen}</div>
    `;
    if (box.innerHTML !== seenHtml) box.innerHTML = seenHtml;

  }

  function applyAdvertiserClusterStyle(card, advertiserId, advertiserAds) {
    const oldTag = card.querySelector(".vs-cluster-tag");
    if (oldTag) oldTag.remove();

    card.style.borderLeft = "";
    if (!isFavouritesPage()) card.style.backgroundColor = "";
  }

function formatContactedDateTime(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${String(d.getFullYear()).slice(-2)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function getContactedIdentity(advertiserId, rawDigits, advertUrl) {
  if (advertiserId) return `advertiser:${advertiserId}`;

  const phone = getRawWhatsappDigits(rawDigits);
  if (phone) return `phone:${phone}`;

  return `advert:${cleanLink(advertUrl)}`;
}

function setContactedButtonState(btn, entry) {
  const contactedAt = entry && entry.contactedAt ? entry.contactedAt : 0;
  btn.dataset.vsContactedAt = String(contactedAt || "");
  btn.style.filter = contactedAt ? "none" : "grayscale(1)";
  btn.style.opacity = contactedAt ? "1" : "0.32";
}

function refreshContactedButtons(identity, entry) {
  document.querySelectorAll(".vs-contacted-toggle").forEach((btn) => {
    if (btn.dataset.vsContactedIdentity === identity) {
      setContactedButtonState(btn, entry);
    }
  });
}

const toggleStateReads = new Map();
function readToggleStates(key, callback) {
  const pending = toggleStateReads.get(key);
  if (pending) { pending.push(callback); return; }
  const callbacks = [callback];
  toggleStateReads.set(key, callbacks);
  chrome.storage.local.get([key], res => {
    toggleStateReads.delete(key);
    callbacks.forEach(cb => cb(res));
  });
}

function createContactedButton(identity) {
  const btn = document.createElement("span");
  btn.className = "vs-contacted-toggle";
  btn.dataset.vsContactedIdentity = identity;
  btn.textContent = "📳";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.justifyContent = "center";
  btn.style.width = "30px";
  btn.style.height = "30px";
  btn.style.fontSize = "30px";
  btn.style.lineHeight = "30px";
  btn.style.cursor = "pointer";
  btn.style.transition = "filter 0.12s ease, opacity 0.12s ease";

  attachFastTooltip(btn, function () {
    const stamp = formatContactedDateTime(Number(btn.dataset.vsContactedAt || 0));
    return `Last contact: 📳${stamp ? " • " + stamp : " • —"}`;
  });

  readToggleStates(CONTACTED_KEY, function (res) {
    const data = res[CONTACTED_KEY] || {};
    setContactedButtonState(btn, data[identity]);
  });

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    serialStorage(CONTACTED_KEY, done => chrome.storage.local.get([CONTACTED_KEY], function (res) {
      const data = res[CONTACTED_KEY] || {};

      if (data[identity]) {
        delete data[identity];
      } else {
        data[identity] = { contactedAt: Date.now() };
      }

      chrome.storage.local.set({ [CONTACTED_KEY]: data }, function () {
        const error = chrome.runtime.lastError;
        done();
        if (error) { alert("Last contact save failed: " + error.message); return; }
        refreshContactedButtons(identity, data[identity]);
      });
    }));
  };

  return btn;
}

function getFakeIdentity(advertUrl) {
  return `advert:${cleanLink(advertUrl)}`;
}

function setFakeButtonState(btn, entry) {
  const flaggedAt = entry && entry.flaggedAt ? entry.flaggedAt : 0;
  btn.dataset.vsFakeAt = String(flaggedAt || "");
  btn.style.filter = flaggedAt ? "none" : "grayscale(1)";
  btn.style.opacity = flaggedAt ? "1" : "0.32";
}

function refreshFakeButtons(identity, entry) {
  document.querySelectorAll(".vs-fake-toggle").forEach((btn) => {
    if (btn.dataset.vsFakeIdentity === identity) {
      setFakeButtonState(btn, entry);
    }
  });
}

function createFakeButton(identity) {
  const btn = document.createElement("span");
  btn.className = "vs-fake-toggle";
  btn.dataset.vsFakeIdentity = identity;
  btn.textContent = "⛔";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.justifyContent = "center";
  btn.style.width = "30px";
  btn.style.height = "30px";
  btn.style.fontSize = "30px";
  btn.style.lineHeight = "30px";
  btn.style.cursor = "pointer";
  btn.style.transition = "filter 0.12s ease, opacity 0.12s ease";

  attachFastTooltip(btn, function () {
    const flaggedAt = Number(btn.dataset.vsFakeAt || 0);
    return flaggedAt
      ? `Fake/ Scam: ⛔ • ${formatContactedDateTime(flaggedAt)}`
      : "Fake/ Scam: ⛔ • —";
  });

  readToggleStates(FAKE_KEY, function (res) {
    const data = res[FAKE_KEY] || {};
    setFakeButtonState(btn, data[identity]);
  });

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    serialStorage(FAKE_KEY, done => chrome.storage.local.get([FAKE_KEY], function (res) {
      const data = res[FAKE_KEY] || {};

      if (data[identity]) {
        delete data[identity];
      } else {
        data[identity] = { flaggedAt: Date.now() };
      }

      chrome.storage.local.set({ [FAKE_KEY]: data }, function () {
        const error = chrome.runtime.lastError;
        done();
        if (error) { alert("Fake/ Scam save failed: " + error.message); return; }
        refreshFakeButtons(identity, data[identity]);
      });
    }));
  };

  return btn;
}

function createRotatingButton(identity, notWhatsapp = false, realPhoto = false) {
  const storageKey = realPhoto ? REAL_PHOTO_KEY : notWhatsapp ? NOT_WA_KEY : ROTATING_KEY;
  const selector = realPhoto ? ".vs-real-photo-toggle" : notWhatsapp ? ".vs-not-wa-toggle" : ".vs-rotating-toggle";
  const identityField = realPhoto ? "vsRealPhotoIdentity" : notWhatsapp ? "vsNotWaIdentity" : "vsRotatingIdentity";
  const timeField = realPhoto ? "vsRealPhotoAt" : notWhatsapp ? "vsNotWaAt" : "vsRotatingAt";
  const label = realPhoto ? "Real Photo: ✅" : notWhatsapp ? "Not on WhatsApp: 📵" : "Rotating: ♻️";
  const btn = document.createElement("span");
  btn.className = selector.slice(1);
  btn.dataset[identityField] = identity;
  btn.textContent = realPhoto ? "✅" : notWhatsapp ? "📵" : "♻️";
  btn.setAttribute("role", "button");
  btn.setAttribute("aria-label", realPhoto ? "Real Photo" : notWhatsapp ? "Not on WhatsApp" : "Rotating photos");
  btn.tabIndex = 0;
  Object.assign(btn.style, {
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    width: "30px", height: "30px", fontSize: "30px", lineHeight: "30px",
    cursor: "pointer", transition: "filter 0.12s ease, opacity 0.12s ease"
  });
  function setState(button, entry) {
    const ts = Number(entry?.flaggedAt || 0);
    button.dataset[timeField] = String(ts || "");
    button.style.filter = ts ? "none" : "grayscale(1)";
    button.style.opacity = ts ? "1" : "0.32";
    button.setAttribute("aria-pressed", ts ? "true" : "false");
  }
  setState(btn, null);
  attachFastTooltip(btn, () => {
    const ts = Number(btn.dataset[timeField] || 0);
    return label + " • " + (formatContactedDateTime(ts) || "—");
  });
  readToggleStates(storageKey, res => setState(btn, (res[storageKey] || {})[identity]));
  btn.onclick = e => {
    e.preventDefault();
    e.stopPropagation();
    serialStorage(storageKey, done => chrome.storage.local.get([storageKey], res => {
      const data = res[storageKey] || {};
      if (data[identity]) delete data[identity];
      else data[identity] = { flaggedAt: Date.now() };
      chrome.storage.local.set({ [storageKey]: data }, () => {
        const error = chrome.runtime.lastError;
        if (error) { done(); alert(label + " save failed: " + error.message); return; }
        document.querySelectorAll(selector).forEach(button => {
          if (button.dataset[identityField] === identity) setState(button, data[identity]);
        });
        done();
      });
    }));
  };
  btn.onkeydown = e => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); btn.click(); }
  };
  return btn;
}

// Native redraws can copy enhanced DOM without copying click handlers.
document.addEventListener("keydown", e => {
  const toggle = e.target.closest?.(".vs-real-photo-toggle");
  if (toggle && !toggle.onkeydown && (e.key === "Enter" || e.key === " ")) {
    e.preventDefault(); e.stopImmediatePropagation(); toggle.click();
  }
}, true);
const copiedToggleTooltips = new WeakSet();
document.addEventListener("mouseover", e => {
  const toggle = e.target.closest?.(".vs-contacted-toggle,.vs-fake-toggle,.vs-rotating-toggle,.vs-not-wa-toggle,.vs-real-photo-toggle");
  if (!toggle || toggle.onclick || copiedToggleTooltips.has(toggle)) return;
  copiedToggleTooltips.add(toggle);
  attachFastTooltip(toggle, () => {
    const contacted = toggle.matches(".vs-contacted-toggle");
    const fake = toggle.matches(".vs-fake-toggle");
    const notWa = toggle.matches(".vs-not-wa-toggle");
    const realPhoto = toggle.matches(".vs-real-photo-toggle");
    const label = contacted ? "Last contact: 📳" : fake ? "Fake/ Scam: ⛔" : realPhoto ? "Real Photo: ✅" : notWa ? "Not on WhatsApp: 📵" : "Rotating: ♻️";
    const ts = Number(contacted ? toggle.dataset.vsContactedAt : fake ? toggle.dataset.vsFakeAt : realPhoto ? toggle.dataset.vsRealPhotoAt : notWa ? toggle.dataset.vsNotWaAt : toggle.dataset.vsRotatingAt);
    return label + " • " + (formatContactedDateTime(ts) || "—");
  });
});
document.addEventListener("click", e => {
  const toggle = e.target.closest?.(".vs-contacted-toggle,.vs-fake-toggle,.vs-rotating-toggle,.vs-not-wa-toggle,.vs-real-photo-toggle");
  if (!toggle) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  const button = typeof toggle.onclick === "function" ? toggle
    : toggle.matches(".vs-contacted-toggle") ? createContactedButton(toggle.dataset.vsContactedIdentity)
    : toggle.matches(".vs-fake-toggle") ? createFakeButton(toggle.dataset.vsFakeIdentity)
    : toggle.matches(".vs-not-wa-toggle") ? createRotatingButton(toggle.dataset.vsNotWaIdentity, true)
    : toggle.matches(".vs-real-photo-toggle") ? createRotatingButton(toggle.dataset.vsRealPhotoIdentity, false, true)
    : createRotatingButton(toggle.dataset.vsRotatingIdentity);
  button.onclick(e);
}, true);

function addContactedButtonToCard(card, identity, fakeIdentity, rawDigits) {
  if (!card || !identity || !fakeIdentity) return;

  const old = card.querySelector(".vs-contacted-card-wrap");
  if (
    old &&
    old.dataset.vsContactedIdentity === identity &&
    old.dataset.vsFakeIdentity === fakeIdentity &&
    old.querySelector(".vs-fake-toggle") && old.querySelector(".vs-rotating-toggle") && old.querySelector(".vs-not-wa-toggle") && old.querySelector(".vs-real-photo-toggle")
  ) return;
  if (old) old.remove();

  const wrap = document.createElement("div");
  wrap.className = "vs-contacted-card-wrap";
  protectControls(wrap);
  wrap.dataset.vsContactedIdentity = identity;
  wrap.dataset.vsFakeIdentity = fakeIdentity;
  wrap.style.display = "flex";
  wrap.style.alignItems = "center";
  wrap.style.gap = "6px";
  wrap.style.width = "fit-content";
  wrap.style.margin = "4px 0";
  wrap.appendChild(createContactedButton(identity));
  wrap.appendChild(createFakeButton(fakeIdentity));
  wrap.appendChild(createRotatingButton(fakeIdentity));
  wrap.appendChild(createRotatingButton(rawDigits ? `phone:${getRawWhatsappDigits(rawDigits)}` : fakeIdentity, true));
  wrap.appendChild(createRotatingButton(fakeIdentity, false, true));

  const info = card.querySelector(".newData");
  if (info) {
    info.appendChild(wrap);
    return;
  }

  const locationLine =
    card.querySelector(".clad__location") ||
    card.querySelector("[class*='location']");

  if (locationLine && locationLine.parentElement) {
    locationLine.parentElement.insertBefore(wrap, locationLine);
    return;
  }

  const anchor =
    card.querySelector(".clad__title") ||
    card.querySelector("h2") ||
    card.querySelector("h3") ||
    card.querySelector("a.clad__ad_link");

  if (anchor && anchor.parentElement) {
    anchor.parentElement.appendChild(wrap);
  } else {
    card.insertBefore(wrap, card.firstChild);
  }
}

function extractRealAdvertTitleFromHtml(html, url) {
  const doc = new DOMParser().parseFromString(html, "text/html");

  let title =
    doc.querySelector('[data-automation="hdrAdTitle"]')?.textContent ||
    doc.querySelector('[data-automation="adTitle"]')?.textContent ||
    doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
    doc.querySelector("h1")?.textContent ||
    doc.querySelector(".kiwii-font-xlarge")?.textContent ||
    doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ||
    doc.querySelector("title")?.textContent ||
    "";

  title = title
    .replace(/18\+\s*id\s*verified/gi, "")
    .replace(/verified/gi, "")
    .replace(/\|\s*vivastreet.*$/i, "")
    .replace(/-\s*vivastreet.*$/i, "")
    .replace(/\s+/g, " ")
    .trim();

  if (title) return title;

  try {
    const parts = new URL(url).pathname.split("/").filter(Boolean);
    const slug = parts[parts.length - 2] || "";

    const fromSlug = slug
      .replace(/[-_]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    return fromSlug ? titleCase(fromSlug) : "Advert";
  } catch (e) {
    return "Advert";
  }
}

  function processAd(link, response, filters, options) {
    try {
      options = options || {};
      if (!response || !response.html) return;

      const card = getListingCardFromLink(link);
      if (!card) return;

      const tempElement = document.createElement("div");
      tempElement.innerHTML = response.html;

      if (!options.cachedMeta && !tempElement.querySelector('[data-automation="hdrAdTitle"], .phone_link, #vs_photo_viewer_container')) return;

let title = extractRealAdvertTitleFromHtml(response.html, link.href);

      let nationality = "-";
      let age = "-";

      const rows = tempElement.querySelectorAll("tr");
      rows.forEach((row) => {
        const cells = row.querySelectorAll("td");
        if (cells.length < 2) return;

        const label = cells[0].textContent.trim();
        const value = cells[1].textContent.trim();

        if (label === "Nationality") nationality = value;
        if (label === "Age") age = value.replace(/\s*years old/i, "").trim();
      });

      const phoneNumberElement = tempElement.querySelector(".phone_link");
      const rawPhoneNumber = phoneNumberElement
        ? phoneNumberElement.getAttribute("data-phone-number")
        : "-";

      const rawWhatsappDigits = getRawWhatsappDigits(rawPhoneNumber);
      const displayPhone = formatDisplayPhone(rawPhoneNumber);
      const area = extractAreaFromUrl(link.href);

      const fmin = tempElement.querySelector('[data-automation="tdRate15minutesIncall"]')?.textContent.trim() || "-";
      const tmin = tempElement.querySelector('[data-automation="tdRate30minutesIncall"]')?.textContent.trim() || "-";
      const hr = tempElement.querySelector('[data-automation="tdRate1hourIncall"]')?.textContent.trim() || "-";

      let price = "-";
      const priceElement =
        tempElement.querySelector(".price") ||
        tempElement.querySelector('[data-automation="price"]') ||
        tempElement.querySelector(".ad-price") ||
        tempElement.querySelector(".kiwii-price");

      if (priceElement) price = priceElement.textContent.trim();

      const advertDescriptionText = getDescriptionTextFromHtml(response.html);
      const showAngel = hasVideoKeyword(advertDescriptionText);
let image = getBestImage(tempElement);
const allImages = getAllAdvertImageUrlsFromHtml(tempElement);

const advertiserInfo = extractAdvertiserInfo(tempElement);

const adData = {
        title,
        area,
        rawWhatsappDigits,
        displayPhone,
        price,
        preferredImage: "",
        image,
        allImages,
        galleryCheckedAt: Date.now(),
        galleryCacheVersion: 4,
        detailCacheVersion: 4,
        detailCheckedAt: Date.now(),
        showAngel,
        galleryListingImage: normaliseImageIdentity(getCardMainImageUrl(card)),
        fmin,
        tmin,
        hr,
        nationality,
        age,
        advertiserId: advertiserInfo ? advertiserInfo.id : "",
        advertiserUrl: advertiserInfo ? advertiserInfo.url : ""
      };

      if (options.cachedMeta) {
        addSeenBox(card, options.cachedMeta);
      } else {
        upsertAdMeta(link.href, adData, function (metaEntry) {
          addSeenBox(card, metaEntry);
        });
      }

      const filterAd = { fmin, tmin, hr, nationality };

      if (!passesFilters(filterAd, filters)) {
        card.dataset.vsTamerFiltered = "1";
        card.style.display = "none";
        return;
      } else {
        delete card.dataset.vsTamerFiltered;
        card.style.display = "";
      }

addListingThumbnailStrip(card, allImages);
if (!options.cachedMeta && !allImages.length) repairCachedGallery(link, card, { ...adData, galleryCheckedAt: 0 });

      const anchor = getInfoAnchor(card, link);

      let newDiv = card.querySelector(".newData");
      if (!newDiv) {
        newDiv = document.createElement("div");
        newDiv.className = "newData";
        protectControls(newDiv);
        insertAfter(newDiv, anchor);
      }

      const nationalityFlag = getNationalityFlag(nationality);
      const nationalityDisplay = nationalityFlag ? `${nationalityFlag} ${nationality}` : nationality;

      newDiv.innerHTML = `
        <p class="vs-price-line" style="display:flex;align-items:center;min-width:0;max-width:100%;color:blue;font-size:12px;line-height:1.35;margin:4px 0;font-weight:600;">
          <span class="vs-price-text" style="flex:1 1 auto;min-width:0;white-space:nowrap;overflow-x:auto;">15m-${fmin} || 30m-${tmin} || 1hr-${hr}</span>
        </p>

        <p class="vs-number-line" style="display:flex;align-items:center;min-width:0;max-width:100%;color:green;font-size:11px;line-height:1.35;font-weight:600;margin:4px 0;">
          <span class="vs-number-text" style="flex:1 1 auto;min-width:0;white-space:nowrap;overflow-x:auto;">Nationality: ${escapeCachedHtml(nationalityDisplay)} || Age: ${escapeCachedHtml(age)} || Number: ${escapeCachedHtml(displayPhone)}</span>
        </p>

        <p class="vs-advertiser-line" style="margin:4px 0 0 0;font-weight:600;">
          Other Adverts: …
        </p>

        <p class="vs-phone-line" style="margin:2px 0 0 0;font-weight:600;">
          Same phone number: …
        </p>
      `;

const priceLine = newDiv.querySelector(".vs-price-line");



      const advertiserLine = newDiv.querySelector(".vs-advertiser-line");
      const phoneLine = newDiv.querySelector(".vs-phone-line");
      phoneLine.dataset.vsPhone = rawWhatsappDigits;
      phoneLine.dataset.vsUrl = cleanLink(link.href);
      const numberLine = newDiv.querySelector(".vs-number-line");

      const contactedIdentity = getContactedIdentity(
        advertiserInfo ? advertiserInfo.id : "",
        rawWhatsappDigits,
        link.href
      );
      addContactedButtonToCard(card, contactedIdentity, getFakeIdentity(link.href), rawWhatsappDigits);

if (rawWhatsappDigits) {
  priceLine.appendChild(createWhatsAppButton(rawWhatsappDigits));
  priceLine.appendChild(createSmsButton(rawWhatsappDigits));

      if (options.cachedNumbers) {
        const cachedPhoneMatches = options.cachedNumbers[rawWhatsappDigits]?.links || [];
        const sorted = [...cachedPhoneMatches].sort((a, b) => b.ts - a.ts);
        renderPhoneMatches(phoneLine, sorted, link.href);
      } else {
        storeNumber(rawWhatsappDigits, link.href, adData, function (phoneMatches) {
          const sorted = [...phoneMatches].sort((a, b) => b.ts - a.ts);
          renderPhoneMatches(phoneLine, sorted, link.href);
        });
      }
      } else {
        phoneLine.textContent = "Same phone number: 0";
      }

      if (advertiserInfo && advertiserInfo.id && advertiserInfo.url) {
        if (options.cachedAdvertisers) {
          const cachedAdvertiser = options.cachedAdvertisers[advertiserInfo.id];
          const cachedAds = (cachedAdvertiser?.ads || []).filter(
            (item) => cleanLink(item.url) !== cleanLink(link.href)
          );
          applyAdvertiserClusterStyle(card, advertiserInfo.id, cachedAds);
          if (cachedAdvertiser) renderAdvertiserMatches(advertiserLine, cachedAds);
          repairCachedAdvertiserMatches(
            advertiserInfo.id,
            advertiserInfo.url,
            link.href,
            card,
            advertiserLine,
            cachedAdvertiser
          );
        } else {
        fetchAdvertiserAds(advertiserInfo.id, advertiserInfo.url, link.href, function (ads) {
          applyAdvertiserClusterStyle(card, advertiserInfo.id, ads);
          renderAdvertiserMatches(advertiserLine, ads);
        });
        }
      } else {
        advertiserLine.textContent = "Other Adverts: 0";
        applyAdvertiserClusterStyle(card, null, []);
      }
    } catch (e) {
      console.log("VS Tamer error:", e);
    }
  }

function pumpCachedRepairQueue() {
  while (cachedRepairActive < CACHED_REPAIR_MAX_ACTIVE && cachedRepairQueue.length) {
    const job = cachedRepairQueue.shift();
    cachedRepairActive += 1;

    let finished = false;
    job.run(function () {
      if (finished) return;
      finished = true;
      cachedRepairActive -= 1;
      cachedRepairInFlight.delete(job.key);
      pumpCachedRepairQueue();
    });
  }
}

function queueCachedRepair(key, run) {
  if (!key || cachedRepairInFlight.has(key) || cachedRepairAttempted.has(key)) return;

  cachedRepairInFlight.add(key);
  cachedRepairAttempted.add(key);
  cachedRepairQueue.push({ key, run });
  pumpCachedRepairQueue();
}

function repairCachedGallery(link, card, meta) {
  const advertUrl = cleanLink(link.href);
  const sessionGallery = gallerySessionCache.get(advertUrl);
  if (sessionGallery) {
    addListingThumbnailStrip(card, sessionGallery.allImages);
    return;
  }
  const savedImages = Array.isArray(meta.allImages) ? meta.allImages : [];
  const recentlyChecked = Date.now() - Number(meta.galleryCheckedAt || 0) < 30 * 60 * 1000;
  const hasCurrentGalleryCache = Number(meta.galleryCacheVersion || 0) >= 4;
  if (hasCurrentGalleryCache && recentlyChecked && savedImages.length) return;

  queueCachedRepair(`gallery:${advertUrl}`, function (done) {
    fetchDetailOnce(advertUrl, function (response) {
      if (response && response.html) {
        const tempElement = document.createElement("div");
        tempElement.innerHTML = response.html;
        const allImages = getAllAdvertImageUrlsFromHtml(tempElement);
        if (!allImages.length) {
          retryGallery();
          return;
        }
        const imagesChanged =
          allImages.length > 0 &&
          allImages.join("|") !== savedImages.join("|");
        const patch = {
          galleryCheckedAt: Date.now(),
          galleryCacheVersion: 4,
          galleryListingImage: normaliseImageIdentity(getCardMainImageUrl(card))
        };

        if (allImages.length) {
          patch.allImages = allImages;
          patch.image = allImages[0];
        }

        gallerySessionCache.set(advertUrl, patch);
        // Resolve current cards: VS may have replaced the original node while
        // this request was in flight. Only update the thumbnail strip.
        const updatedCards = new Set();
        document.querySelectorAll("a[href]").forEach((anchor) => {
          if (cleanLink(anchor.href) !== advertUrl) return;
          const currentCard = getListingCardFromLink(anchor);
          if (!currentCard || updatedCards.has(currentCard)) return;
          updatedCards.add(currentCard);
          addListingThumbnailStrip(currentCard, allImages);
        });

        upsertAdMeta(advertUrl, patch, function () {
          if (card.isConnected && imagesChanged) {
            addListingThumbnailStrip(card, allImages);
          }
          done();
        });
        return;
      }

      retryGallery();
    });
    function retryGallery() {
      done();
      const attempts = galleryRetryCounts.get(advertUrl) || 0;
      if (attempts >= 2) return;
      galleryRetryCounts.set(advertUrl, attempts + 1);
      detailRequests.delete(advertUrl);
      setTimeout(() => {
        cachedRepairAttempted.delete(`gallery:${advertUrl}`);
        if (card.isConnected) repairCachedGallery(link, card, meta);
        else {
          const current = Array.from(document.querySelectorAll("a[href]")).find(a => cleanLink(a.href) === advertUrl && getListingCardFromLink(a));
          if (current) repairCachedGallery(current, getListingCardFromLink(current), meta);
        }
      }, 1000 * (attempts + 1));
    }
  });
}

function repairCachedAdvertiserMatches(advertiserId, advertiserUrl, currentUrl, card, advertiserLine, cachedAdvertiser) {
  const recent = cachedAdvertiser?.cacheVersion === 4 && cachedAdvertiser?.fetchedAt &&
    Date.now() - cachedAdvertiser.fetchedAt < 10 * 60 * 1000;
  if (recent) return;
  fetchAdvertiserAds(advertiserId, advertiserUrl, currentUrl, ads => {
    if (card.isConnected && advertiserLine.isConnected) {
      renderAdvertiserMatches(advertiserLine, ads);
    }
  });
}

function escapeCachedHtml(value) {
  return String(value === undefined || value === null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function normaliseImageIdentity(url) {
  // VS uses different hosts and named size directories for the same photo.
  // Keep the advert ID, filename and blur state; ignore only rendition size.
  try {
    const parsed = new URL(url, location.origin);
    const match = parsed.pathname.match(/\/clad\/(\d+)\/(?:[^/]+\/)?([^/]+)$/i);
    if (match) return `${match[1]}/${match[2]}|${parsed.searchParams.get("isblurred") || ""}`;
  } catch (e) {}
  return String(url || "")
    .split("?")[0]
    .replace(/\/\d+x\d+\//g, "/")
    .replace(/_\d+x\d+/g, "");
}

function getCardMainImageUrl(card) {
  const img = getAdvertPhoto(card);

  if (!img) return "";
  return (
    img.currentSrc ||
    img.getAttribute("src") ||
    img.getAttribute("data-src") ||
    img.getAttribute("data-lazy-src") ||
    ""
  );
}

function getSafeCachedMetaForCard(card, meta) {
  const nativeMainImage = getCardMainImageUrl(card);
  const savedImages = Array.isArray(meta.allImages) ? meta.allImages : [];
  if (!nativeMainImage || !savedImages.length) return meta;

  const nativeIdentity = normaliseImageIdentity(nativeMainImage);
  const containsCurrentMain = savedImages.some(
    (url) => normaliseImageIdentity(url) === nativeIdentity
  );

  if (containsCurrentMain || (Number(meta.galleryCacheVersion || 0) >= 4 &&
      meta.galleryListingImage === nativeIdentity)) return meta;

  // VS is showing a different lead image, so the saved gallery belongs to an
  // older version of this advert. Show only the current native image until the
  // lightweight background gallery check supplies the new complete set.
  return {
    ...meta,
    image: nativeMainImage,
    allImages: [nativeMainImage],
    galleryCheckedAt: 0
  };
}

function createCachedAdvertHtml(meta) {
  const advertiserLink = meta.advertiserId
    ? `<a href="/profile/ind/${escapeCachedHtml(meta.advertiserId)}">Posted by #${escapeCachedHtml(meta.advertiserId)}</a>`
    : "";
  const image = meta.preferredImage || meta.image || "";
  const cachedImages = Array.isArray(meta.allImages) && meta.allImages.length
    ? meta.allImages
    : (image ? [image] : []);
  const galleryImages = cachedImages
    .map((url) => `<img src="${escapeCachedHtml(url)}">`)
    .join("");

  return `
    <h1>${escapeCachedHtml(meta.title || "Advert")}</h1>
    <table>
      <tr><td>Nationality</td><td>${escapeCachedHtml(meta.nationality || "-")}</td></tr>
      <tr><td>Age</td><td>${escapeCachedHtml(meta.age || "-")}</td></tr>
    </table>
    <span class="phone_link" data-phone-number="${escapeCachedHtml(meta.rawWhatsappDigits || meta.displayPhone || "")}"></span>
    <span data-automation="tdRate15minutesIncall">${escapeCachedHtml(meta.fmin || "-")}</span>
    <span data-automation="tdRate30minutesIncall">${escapeCachedHtml(meta.tmin || "-")}</span>
    <span data-automation="tdRate1hourIncall">${escapeCachedHtml(meta.hr || "-")}</span>
    <div class="gallery">${galleryImages}</div>
    <div>Description ${meta.showAngel ? "video call" : ""} Ad ID</div>
    ${advertiserLink}
  `;
}

function renderCachedListingsPage(callback) {
  getFilters(function (filters) {
    chrome.storage.local.get(
      [AD_META_KEY, NUMBERS_KEY, ADVERTISER_CACHE_KEY],
      function (res) {
        const metaCache = res[AD_META_KEY] || {};
        const numbersCache = res[NUMBERS_KEY] || {};
        const advertiserCache = res[ADVERTISER_CACHE_KEY] || {};
        const seenCards = new Set();

        document.querySelectorAll(
          "a.clad__ad_link, a[href*='/escort/'], a[href*='/massage/'], a[href*='/escorts/']"
        ).forEach((link) => {
          if (!link.href || !/\/\d{6,}/.test(link.href)) return;

          const card = getListingCardFromLink(link);
          if (!card || seenCards.has(card)) return;
          seenCards.add(card);

          const meta = metaCache[cleanLink(link.href)];
          if (!meta) return;
          const sessionGallery = gallerySessionCache.get(cleanLink(link.href));
          const renderMeta = sessionGallery
            ? { ...meta, ...sessionGallery }
            : getSafeCachedMetaForCard(card, meta);

          if (card.querySelector(".newData") && card.dataset.vsTamerProcessed === "1") {
            addSeenBox(card, renderMeta);
            addListingThumbnailStrip(card, renderMeta.allImages || []);
            repairCachedGallery(link, card, renderMeta);
            return;
          }

          processAd(
            link,
            { html: createCachedAdvertHtml(renderMeta) },
            filters,
            {
              cachedMeta: renderMeta,
              cachedNumbers: numbersCache,
              cachedAdvertisers: advertiserCache
            }
          );

          repairCachedGallery(link, card, renderMeta);

          if (meta.detailCacheVersion !== 4 || Date.now() - Number(meta.detailCheckedAt || 0) > 30 * 60 * 1000) {
            queueCachedRepair(`detail:${cleanLink(link.href)}`, done => {
              fetchDetailOnce(link.href, response => {
                const seen = new Set();
                if (response?.html) document.querySelectorAll("a[href]").forEach(current => {
                  if (cleanLink(current.href) !== cleanLink(link.href)) return;
                  const target = getListingCardFromLink(current);
                  if (!target || seen.has(target)) return;
                  seen.add(target);
                  processAd(current, response, filters);
                });
                done();
              });
            });
          }

          // A cached advert must never be included in the later network phase.
          // Its saved data is already rendered; only wholly uncached adverts
          // need fetching on the favourites page.
          card.dataset.vsTamerProcessed = "1";
          card.dataset.vsTamerFromCache = "1";
        });

        if (callback) callback();
      }
    );
  });
}

function processListingsPage(callback) {
  if (listingsPassRunning) {
    if (isFavouritesPage()) {
      // Vivastreet can replace the favourites DOM while this pass is active.
      // Do not turn that replacement into another complete network scan.
      if (callback) listingsPassCallbacks.push(callback);
    } else {
      if (callback) listingsNextPassCallbacks.push(callback);
      listingsPassRequested = true;
    }
    return;
  }

  if (callback) listingsPassCallbacks.push(callback);
  listingsPassRunning = true;
  console.log("VS Tamer: processListingsPage running");

  getFilters(function (filters) {
    const allLinks = Array.from(
      document.querySelectorAll(
        "a.clad__ad_link, a[href*='/escort/'], a[href*='/massage/'], a[href*='/escorts/']"
      )
    ).filter((link) => {
      if (!link || !link.href) return false;
      if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(link.href)) return false;
      if (!/\/\d{6,}/.test(link.href)) return false;
      return true;
    });

    const seenCards = new Set();
    const links = allLinks.filter((link) => {
      const card = getListingCardFromLink(link);
      if (!card || seenCards.has(card)) return false;
      seenCards.add(card);

      if (card.dataset.vsTamerProcessing === "1") return false;
      if (card.dataset.vsTamerProcessed === "1" && card.querySelector(".newData")) return false;

      card.dataset.vsTamerProcessing = "1";
      return true;
    });

    console.log("VS Tamer: listing links found:", links.length);

    if (!links.length) {
      finishListingsPass();
      return;
    }

    let nextIndex = 0;
    let active = 0;
    let completed = 0;
    const maxConcurrent = 6;

    function pumpListingsQueue() {
      while (active < maxConcurrent && nextIndex < links.length) {
        const link = links[nextIndex++];
        active += 1;

      fetchDetailOnce(
        link.href,
        function (response) {
          active -= 1;

          if (chrome.runtime.lastError) {
            console.log("VS Tamer fetchHTML error:", chrome.runtime.lastError.message);
          } else {
            processAd(link, response, filters);
          }

          const card = getListingCardFromLink(link);
          if (card) {
            delete card.dataset.vsTamerProcessing;
            if (card.querySelector(".newData") || card.dataset.vsTamerFiltered === "1") card.dataset.vsTamerProcessed = "1";
          }

          completed += 1;
          if (completed === links.length) {
            finishListingsPass();
            return;
          }

          pumpListingsQueue();
        }
      );
      }
    }

    pumpListingsQueue();
  });
}

function finishListingsPass() {
  listingsPassRunning = false;

  if (isFavouritesPage()) {
    listingsPassRequested = false;
    listingsNextPassCallbacks.length = 0;

    // Any late VS DOM replacement receives the data gathered by the completed
    // pass from local storage. This is cache-only and does not start a rerender.
    setTimeout(function () {
      if (isFavouritesPage()) renderCachedListingsPage();
    }, 200);
  }

  if (listingsPassRequested) {
    listingsPassRequested = false;
    listingsPassCallbacks.push(...listingsNextPassCallbacks.splice(0));
    processListingsPage();
    return;
  }

  const callbacks = listingsPassCallbacks.splice(0);
  callbacks.forEach((callback) => {
    try {
      callback();
    } catch (e) {
      console.log("VS listings completion callback error:", e);
    }
  });
}

function isFavouritesPage() {
  const path = window.location.pathname.toLowerCase();

  return (
    path === "/favourites" ||
    path === "/favorites" ||
    path.includes("/favourites") ||
    path.includes("/favorites")
  );
}

  function getFavouriteCards() {
    const hasNativeCards = !!document.querySelector('li[id^="classified-"]');
    const links = Array.from(document.querySelectorAll("a[href]"))
      .filter(link => /\/(escort|massage|escorts)\/.*\/\d{6,}(?:[?#]|$)/i.test(link.href) &&
        (!hasNativeCards || link.closest('li[id^="classified-"]')));
    const cards = [];

    links.forEach((link, idx) => {
      const card = getListingCardFromLink(link);
      if (!card) return;

      if (!cards.find((x) => x.card === card)) {
        cards.push({
          card,
          link,
          key: cleanLink(link.href),
          originalIndex: idx
        });
      }
    });

    return cards;
  }

  function getCardsParent(cards) {
    if (!cards.length) return null;
    return cards[0].card.parentElement;
  }

  function mapLegacyGroup(groupName) {
    if (!groupName) return FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist";

    if (FAV_GROUPS.includes(groupName)) return groupName;

    if (groupName === "Targets") return FAV_GROUPS[0] || "Live";
    if (groupName === "Live") return FAV_GROUPS[0] || "Live";

    if (groupName === "Shortlist") return FAV_GROUPS[1] || "Watchlist";
    if (groupName === "Try Later") return FAV_GROUPS[1] || "Watchlist";
    if (groupName === "Watchlist") return FAV_GROUPS[1] || "Watchlist";

    if (groupName === "Monitor") return FAV_GROUPS[2] || "Carousel";
    if (groupName === "Carousel") return FAV_GROUPS[2] || "Carousel";

    return FAV_GROUPS.includes(groupName)
      ? groupName
      : (FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist");
  }

  function loadFavouriteGroups(callback) {
    chrome.storage.local.get([FAV_GROUPS_KEY], function (res) {
      const groups = Array.isArray(res[FAV_GROUPS_KEY])
        ? res[FAV_GROUPS_KEY]
            .map((x) => String(x || "").trim())
            .filter(Boolean)
        : [];

      FAV_GROUPS = groups.length ? groups : [...FAV_GROUPS_DEFAULT];

      if (!groups.length) {
        chrome.storage.local.set({ [FAV_GROUPS_KEY]: FAV_GROUPS }, function () {
          if (callback) callback();
        });
      } else {
        if (callback) callback();
      }
    });
  }

  function ensureFavouriteDefaults(callback) {
    const cards = getFavouriteCards();

    chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
      let data = res[FAV_STORAGE_KEY];

      if (!data || Object.keys(data).length === 0) {
        chrome.storage.sync.get([FAV_STORAGE_SYNC_KEY], function (syncRes) {
          const backup = syncRes[FAV_STORAGE_SYNC_KEY];

          if (backup && Object.keys(backup).length > 0) {
            chrome.storage.local.set({ [FAV_STORAGE_KEY]: backup }, function () {
              ensureFavouriteDefaults(callback);
            });
            return;
          }

          continueInit({});
        });
        return;
      }

      continueInit(data);

      function continueInit(data) {
        let changed = false;

        cards.forEach((item, index) => {
          if (!data[item.key]) {
data[item.key] = {
              group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist",
              order: index + 1
            };
            changed = true;
          } else {
            data[item.key].group = mapLegacyGroup(data[item.key].group);

            if (!data[item.key].group || !FAV_GROUPS.includes(data[item.key].group)) {
data[item.key].group = FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist";              changed = true;
            }

            if (typeof data[item.key].order !== "number") {
              data[item.key].order = index + 1;
              changed = true;
            }
          }
        });

        if (changed) {
          saveFavourites(data, function () {
            callback(data);
          });
        } else {
          callback(data);
        }
      }
    });
  }

  function normaliseGroupOrders(data) {
    FAV_GROUPS.forEach((groupName) => {
      const entries = Object.entries(data)
        .filter(([_, meta]) => mapLegacyGroup(meta.group) === groupName)
        .sort((a, b) => (a[1].order || 999999) - (b[1].order || 999999));

      entries.forEach(([key, meta], idx) => {
        meta.group = mapLegacyGroup(meta.group);
        meta.order = idx + 1;
        data[key] = meta;
      });
    });

    return data;
  }

  function reorderFavouritesDom(data) {
    const cards = getFavouriteCards();
    const parent = getCardsParent(cards);
    if (!parent) return;

    const grouped = cards.map((item) => {
      const meta = data[item.key] || { group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist", order: 999999 };
      const groupName = mapLegacyGroup(meta.group);
      const groupRank = FAV_GROUPS.indexOf(groupName);

      return {
        ...item,
        group: groupName || "Watchlist",
        order: typeof meta.order === "number" ? meta.order : 999999,
        groupRank: groupRank === -1 ? 999 : groupRank
      };
    });

    grouped.sort((a, b) => {
      if (a.groupRank !== b.groupRank) return a.groupRank - b.groupRank;
      if (a.order !== b.order) return a.order - b.order;
      return a.originalIndex - b.originalIndex;
    });

    grouped.forEach((item) => parent.appendChild(item.card));
  }

  function applyGroupCardColours(data) {
    const cards = getFavouriteCards();

    cards.forEach((item) => {
const meta = data[item.key] || { group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist" };
const group = mapLegacyGroup(meta.group) || FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist";
      const colours = getGroupColours(group);

      item.card.style.backgroundColor = colours.card;
      item.card.style.borderRadius = "8px";
      item.card.style.outline = `1px solid ${colours.border}`;
      item.card.style.outlineOffset = "-1px";
    });
  }

  function insertGroupHeaders(data) {
  document.querySelectorAll(".vs-fav-group-header, .vs-fav-group-anchor").forEach((el) => el.remove());

    const cards = getFavouriteCards();
    const seen = {};

    cards.forEach((item) => {
const meta = data[item.key] || { group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist" };
const group = mapLegacyGroup(meta.group) || FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist";

      if (seen[group]) return;
      seen[group] = true;

      const header = document.createElement("div");
      const colours = getGroupColours(group);

      header.className = "vs-fav-group-header";
      header.textContent = group;
      header.style.fontSize = "18px";
      header.style.fontWeight = "700";
      header.style.margin = "16px 0 8px 0";
      header.style.padding = "8px 10px";
      header.style.borderRadius = "8px";
   header.style.setProperty("background-color", colours.header, "important");
header.style.setProperty("border", `2px solid ${colours.border}`, "important");
header.style.color = "#111";

header.style.boxShadow = `
  0 4px 10px rgba(0,0,0,0.10),
  inset 0 1px 0 rgba(255,255,255,0.55)
`;

header.style.position = "sticky";
header.style.top = "42px";
header.style.zIndex = "15";

header.style.backdropFilter = "blur(6px)";

const anchor = document.createElement("div");
anchor.className = "vs-fav-group-anchor";
anchor.setAttribute("data-vs-group", group);
anchor.style.position = "relative";
anchor.style.top = "-115px";
anchor.style.height = "1px";
anchor.style.pointerEvents = "none";

item.card.parentElement.insertBefore(anchor, item.card);
      item.card.parentElement.insertBefore(header, item.card);
    });
  }
function formatPhoneForWhatsAppCopy(meta, cardText) {
  let raw = meta.rawWhatsappDigits || "";

  if (!raw) {
    const match = cardText.match(/Number:\s*([^\n\r]+)/i);
    raw = match ? match[1].replace(/\D/g, "") : "";
  }

  if (!raw) return "-";

  if (raw.startsWith("0")) {
    raw = "44" + raw.substring(1);
  }

  if (raw.startsWith("44") && raw.length >= 12) {
    return `+44 ${raw.substring(2, 6)} ${raw.substring(6)}`;
  }

  return `+${raw}`;
}

function renderSavedNote(card, note) {
  let preview = card.querySelector(".vs-saved-note");
  if (!preview) {
    preview = document.createElement("div");
    preview.className = "vs-saved-note";
    preview.style.cssText = "width:100%;box-sizing:border-box;white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;line-height:1.4;padding:6px 8px;background:#fff8d6;border:1px solid #e3d49a;border-radius:6px;margin:6px 0";
    const controls = card.querySelector(".vs-fav-controls");
    if (controls) controls.appendChild(preview);
    else card.appendChild(preview);
  }
  preview.textContent = String(note || "");
  preview.hidden = !String(note || "").trim();
}

function saveFavouriteNote(itemKey, note, callback) {
  serialStorage(FAV_STORAGE_KEY, done => chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
    let data = res[FAV_STORAGE_KEY] || {};
    data = normaliseGroupOrders(data);

    if (!data[itemKey]) {
      data[itemKey] = {
        group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist",
        order: 999999
      };
    }

    data[itemKey].note = note || "";

    saveFavourites(data, function (error) {
      done();
      if (!error) getFavouriteCards().filter(item => item.key === itemKey).forEach(item => renderSavedNote(item.card, note));
      if (callback) callback(error);
    });
  }));
}

function getLiveListItemText(item, metaCache, favData) {
  const meta = metaCache[item.key] || {};
  const favMeta = favData[item.key] || {};
  const cardText = item.card.innerText || "";

  const titleFromCard =
    item.card.querySelector(".clad__title")?.innerText?.trim() ||
    item.card.querySelector("h2")?.innerText?.trim() ||
    item.card.querySelector("h3")?.innerText?.trim() ||
    "";

  let rawTitle = meta.title || titleFromCard || "Advert";

  rawTitle = rawTitle
    .replace(/18\+\s*id\s*verified/gi, "")
    .replace(/verified/gi, "")
    .replace(/\s+/g, " ")
    .trim();

  const title = rawTitle || "Advert";

  const nationality = meta.nationality || "";
  const flag = getNationalityFlag(nationality);

  const area = meta.area || extractAreaFromUrl(item.link.href);
  const price15 = meta.fmin || "-";
  const phone = formatPhoneForWhatsAppCopy(meta, cardText);
  const note = (favMeta.note || "").trim();

  let line = `${title}`;

  if (flag) {
    line += ` — ${flag}`;
  }

  line += ` - ${area} - ${price15} — ${phone}`;

  if (note) {
    line += ` - ${note}`;
  }

  return line;
}
function createCopyLiveListButton(data) {
  const old = document.querySelector("#vs-copy-live-list-wrap");
  if (old) old.remove();

  const oldJump = document.querySelector("#vs-group-jump-wrap");
  if (oldJump) oldJump.remove();

  const cards = getFavouriteCards();
  if (!cards.length) return;

  const parent = getCardsParent(cards);
  if (!parent) return;

  const wrap = document.createElement("div");
  wrap.id = "vs-copy-live-list-wrap";
  wrap.style.display = "flex";
  wrap.style.alignItems = "center";
  wrap.style.gap = "8px";
  wrap.style.margin = "10px 0 6px 0";

  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = `Copy ${FAV_GROUPS[0] || "Live"} List`;
  btn.style.padding = "8px 12px";
  btn.style.borderRadius = "8px";
  btn.style.border = "0";
  btn.style.cursor = "pointer";
  btn.style.fontWeight = "700";
  btn.style.background = "#25D366";
  btn.style.color = "#fff";

  const status = document.createElement("span");
  status.textContent = "";
  status.style.fontSize = "12px";
  status.style.color = "#555";

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    chrome.storage.local.get([AD_META_KEY, FAV_STORAGE_KEY], function (res) {
      const metaCache = res[AD_META_KEY] || {};
      const favData = normaliseGroupOrders(res[FAV_STORAGE_KEY] || {});

      const liveCards = getFavouriteCards()
        .filter((item) => {
          const meta = favData[item.key] || {};
          return mapLegacyGroup(meta.group) === (FAV_GROUPS[0] || "Live");
        })
        .sort((a, b) => {
          const am = favData[a.key] || {};
          const bm = favData[b.key] || {};
          return (am.order || 999999) - (bm.order || 999999);
        });

      if (!liveCards.length) {
        status.textContent = `No ${FAV_GROUPS[0] || "Live"} adverts found`;
        return;
      }

      status.textContent = "Fetching headlines...";

      let pending = liveCards.length;

      liveCards.forEach((item) => {
        chrome.runtime.sendMessage(
          { action: "fetchHTML", url: item.link.href },
          function (response) {
            if (chrome.runtime.lastError) {
              console.log("VS Copy Live title fetch error:", chrome.runtime.lastError.message);
              pendingDone();
              return;
            }

            if (response && response.html) {
              const title = extractRealAdvertTitleFromHtml(response.html, item.link.href);

              if (title && title !== "Advert") {
                metaCache[item.key] = metaCache[item.key] || {};
                metaCache[item.key].title = title;

                upsertAdMeta(item.link.href, { title });
              }
            }

            pendingDone();
          }
        );
      });

      function pendingDone() {
        pending -= 1;
        if (pending > 0) return;

        const lines = liveCards.map((item, idx) => {
          return `${idx + 1}. ${getLiveListItemText(item, metaCache, favData)}`;
        });

        const message = `${FAV_GROUPS[0] || "Live"} List\n\n${lines.join("\n")}`;

        function markCopied() {
          status.textContent = `Copied ${liveCards.length} advert${liveCards.length === 1 ? "" : "s"}`;
          setTimeout(() => {
            status.textContent = "";
          }, 2500);
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(message).then(markCopied).catch(() => {
            fallbackCopyText(message);
            markCopied();
          });
        } else {
          fallbackCopyText(message);
          markCopied();
        }
      }
    });
  };

  wrap.appendChild(btn);
  wrap.appendChild(status);

  const jumpWrap = document.createElement("div");
  jumpWrap.id = "vs-group-jump-wrap";
  jumpWrap.style.position = "sticky";
  jumpWrap.style.top = "0";
  jumpWrap.style.zIndex = "99999";
  jumpWrap.style.display = "flex";
  jumpWrap.style.flexDirection = "row";
jumpWrap.style.flexWrap = "nowrap";
jumpWrap.style.overflowX = "auto";
jumpWrap.style.maxWidth = "100%";  jumpWrap.style.alignItems = "center";
  jumpWrap.style.gap = "6px";
  jumpWrap.style.margin = "0 0 14px 0";
  jumpWrap.style.padding = "6px 0";
  jumpWrap.style.background = "rgba(255,255,255,0.96)";

  const firstHeaderOrCard = parent.querySelector(".vs-fav-group-header") || cards[0].card;

  parent.insertBefore(wrap, firstHeaderOrCard);
  parent.insertBefore(jumpWrap, firstHeaderOrCard);

  setTimeout(function () {
    jumpWrap.innerHTML = "";

    const headers = Array.from(document.querySelectorAll(".vs-fav-group-header"));

    headers.forEach((header) => {
      const groupName = (header.textContent || "").trim();
      if (!groupName) return;

      const jumpBtn = document.createElement("button");
      jumpBtn.type = "button";
      jumpBtn.textContent = groupName;

jumpBtn.style.border = "1px solid rgba(0,0,0,0.18)";
jumpBtn.style.borderRadius = "10px";
jumpBtn.style.padding = "7px 12px";
jumpBtn.style.cursor = "pointer";
jumpBtn.style.fontWeight = "800";
jumpBtn.style.fontSize = "13px";
jumpBtn.style.whiteSpace = "nowrap";
jumpBtn.style.maxWidth = "none";
jumpBtn.style.overflow = "visible";
jumpBtn.style.textOverflow = "clip";

const colours = getGroupColours(groupName);

jumpBtn.style.setProperty("background-color", colours.header, "important");
jumpBtn.style.setProperty("border", `2px solid ${colours.border}`, "important");
jumpBtn.style.color = "#111";

jumpBtn.style.boxShadow = `
  0 3px 8px rgba(0,0,0,0.16),
  inset 0 1px 0 rgba(255,255,255,0.85)
`;

jumpBtn.style.transform = "translateY(0)";
jumpBtn.style.transition = "all 0.12s ease";

jumpBtn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  const anchor = Array.from(document.querySelectorAll(".vs-fav-group-anchor"))
    .find((el) => el.getAttribute("data-vs-group") === groupName);

  if (!anchor) return;

anchor.scrollIntoView({
  behavior: "smooth",
  block: "start"
});
};

jumpBtn.onmouseenter = function () {
  jumpBtn.style.transform = "translateY(-1px)";
  jumpBtn.style.boxShadow = `
    0 5px 12px rgba(0,0,0,0.22),
    inset 0 1px 0 rgba(255,255,255,0.9)
  `;
};

jumpBtn.onmouseleave = function () {
  jumpBtn.style.transform = "translateY(0)";
  jumpBtn.style.boxShadow = `
    0 3px 8px rgba(0,0,0,0.16),
    inset 0 1px 0 rgba(255,255,255,0.85)
  `;
};

jumpBtn.onmousedown = function () {
  jumpBtn.style.transform = "translateY(1px)";
  jumpBtn.style.boxShadow = `
    inset 0 2px 5px rgba(0,0,0,0.18)
  `;
};

jumpBtn.onmouseup = function () {
  jumpBtn.style.transform = "translateY(-1px)";
  jumpBtn.style.boxShadow = `
    0 5px 12px rgba(0,0,0,0.22),
    inset 0 1px 0 rgba(255,255,255,0.9)
  `;
};

jumpWrap.appendChild(jumpBtn);

    });
  }, 50);
}

  function fallbackCopyText(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    ta.style.top = "-9999px";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();

    try {
      document.execCommand("copy");
    } catch (e) {}

    ta.remove();
  }

  function moveItemWithinGroup(itemKey, direction) {
    chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
      let data = res[FAV_STORAGE_KEY] || {};
      data = normaliseGroupOrders(data);

      const current = data[itemKey];
      if (!current) return;

      const currentGroup = mapLegacyGroup(current.group);

      const sameGroup = Object.entries(data)
        .filter(([_, meta]) => mapLegacyGroup(meta.group) === currentGroup)
        .sort((a, b) => a[1].order - b[1].order);

      const idx = sameGroup.findIndex(([key]) => key === itemKey);
      if (idx === -1) return;

      const swapIdx = direction === "up" ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= sameGroup.length) return;

      const otherKey = sameGroup[swapIdx][0];
      const currentOrder = data[itemKey].order;
      data[itemKey].order = data[otherKey].order;
      data[otherKey].order = currentOrder;

      data = normaliseGroupOrders(data);

      saveFavourites(data, function () {
        favUiInteracting = false;
        applyFavouriteCustomisation();
      });
    });
  }

function forceFavouriteRedraw(data, scrollYToRestore) {
  favUiInteracting = false;
  favApplying = false;

  data = normaliseGroupOrders(data);

  reorderFavouritesDom(data);
  insertGroupHeaders(data);
  applyGroupCardColours(data);
  injectFavouriteControls(data);
  createCopyLiveListButton(data);

  if (typeof scrollYToRestore === "number") {
    window.scrollTo(0, scrollYToRestore);
  }
}

function changeItemGroup(itemKey, newGroup, scrollYToRestore) {
  serialStorage(FAV_STORAGE_KEY, done => chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
    let data = res[FAV_STORAGE_KEY] || {};
    data = normaliseGroupOrders(data);

    if (!data[itemKey]) {
      data[itemKey] = { group: newGroup, order: 999999 };
    }

    data[itemKey].group = newGroup;

    const maxOrderInGroup = Math.max(
      0,
      ...Object.values(data)
        .filter((meta) => mapLegacyGroup(meta.group) === newGroup)
        .map((meta) => meta.order || 0)
    );

    data[itemKey].order = maxOrderInGroup + 1;
    data = normaliseGroupOrders(data);

    saveFavourites(data, function () {
      forceFavouriteRedraw(data, scrollYToRestore);
      done();
    });
  }));
}

function getReverseImageCheckKey(engineName, imageUrl) {
  return `${cleanLink(location.href)}|${engineName}|${imageUrl}`;
}

function loadReverseImageCheck(engineName, imageUrl, marker) {
  const key = getReverseImageCheckKey(engineName, imageUrl);

  chrome.storage.local.get([IMAGE_CHECK_KEY], function (res) {
    const data = res[IMAGE_CHECK_KEY] || {};
    marker.textContent = data[key] ? "🚮" : "⬜";
  });
}

function toggleReverseImageCheck(engineName, imageUrl, marker) {
  const key = getReverseImageCheckKey(engineName, imageUrl);

  chrome.storage.local.get([IMAGE_CHECK_KEY], function (res) {
    const data = res[IMAGE_CHECK_KEY] || {};

    data[key] = !data[key];

    chrome.storage.local.set({ [IMAGE_CHECK_KEY]: data }, function () {
      marker.textContent = data[key] ? "🚮" : "⬜";
    });
  });
}

function getCurrentAdvertContactedIdentity() {
  const advertiserInfo = extractAdvertiserInfo(document);
  const phoneElement = document.querySelector(".phone_link");
  const rawPhone = phoneElement
    ? phoneElement.getAttribute("data-phone-number") || phoneElement.textContent || ""
    : "";

  return getContactedIdentity(
    advertiserInfo ? advertiserInfo.id : "",
    rawPhone,
    location.href
  );
}

function injectReverseImageTopRight() {
  if (!isAdvertPage()) return;

  const contactedIdentity = getCurrentAdvertContactedIdentity();
  const fakeIdentity = getFakeIdentity(location.href);
  const old = document.getElementById("vs-reverse-image-buttons-inline");
  if (
    old &&
    old.dataset.vsContactedIdentity === contactedIdentity &&
    old.dataset.vsFakeIdentity === fakeIdentity &&
    old.querySelector(".vs-fake-toggle") && old.querySelector(".vs-rotating-toggle") && old.querySelector(".vs-not-wa-toggle") && old.querySelector(".vs-real-photo-toggle")
  ) return;
  if (old) old.remove();

  const heart =
    document.querySelector('button[aria-label*="fav" i]') ||
    document.querySelector('button[title*="fav" i]') ||
    Array.from(document.querySelectorAll("button")).find((btn) =>
      /fav|save|heart|shortlist/i.test(btn.innerText || btn.getAttribute("aria-label") || btn.getAttribute("title") || "")
    ) ||
    document.querySelector("button svg")?.closest("button");

  if (!heart || !heart.parentElement) {
    console.log("VS: heart not found");
    return;
  }

  const wrap = document.createElement("span");
  wrap.id = "vs-reverse-image-buttons-inline";
  wrap.dataset.vsContactedIdentity = contactedIdentity;
  wrap.dataset.vsFakeIdentity = fakeIdentity;
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.justifyContent = "flex-end";
  wrap.style.flexWrap = "wrap";
  wrap.style.gap = "6px";
  wrap.style.marginRight = "8px";
  wrap.style.verticalAlign = "middle";

  const engines = [
    {
      title: "G-Lens",
      getUrl: (img) => `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
        <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
        <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
        <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
        <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
        <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
        <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
        <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
        <circle cx="24" cy="24" r="8" fill="#4285F4"/>
        <circle cx="24" cy="24" r="4" fill="#fff"/>
      </svg>`
    },
    {
      title: "Yandex",
      getUrl: (img) => `https://yandex.com/images/search?rpt=imageview&url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
        <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial" font-weight="700" fill="#fff">Y</text>
      </svg>`
    },
    {
      title: "TinEye",
      getUrl: (img) => `https://tineye.com/search?url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="22" fill="#111827"/>
        <circle cx="24" cy="24" r="11" fill="#fff"/>
        <circle cx="24" cy="24" r="6" fill="#2563EB"/>
        <circle cx="28" cy="20" r="2" fill="#fff"/>
      </svg>`
    }
  ];

engines.forEach((engine) => {
  const box = document.createElement("span");
  box.style.display = "inline-flex";
  box.style.flexDirection = "row";
  box.style.alignItems = "center";
  box.style.justifyContent = "center";
  box.style.gap = "4px";

  const btn = document.createElement("span");
btn.style.position = "relative";
attachFastTooltip(btn, engine.title);
  btn.innerHTML = engine.svg;
  btn.style.cursor = "pointer";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.justifyContent = "center";
  btn.style.width = "28px";
  btn.style.height = "28px";

  const marker = document.createElement("span");
attachFastTooltip(marker, `Click if match found for ${engine.title}`);
  marker.textContent = "⬜";
  marker.style.cursor = "pointer";
  marker.style.fontSize = "28px";
marker.style.lineHeight = "28px";
marker.style.height = "28px";
marker.style.display = "inline-flex";
marker.style.alignItems = "center";
marker.style.justifyContent = "center";
marker.style.marginLeft = "2px";

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    const img = getCurrentAdvertImageUrl();
    if (!img) return;

    window.open(engine.getUrl(img), "_blank");
  };

  marker.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    const img = getCurrentAdvertImageUrl();
    if (!img) return;

    toggleReverseImageCheck(engine.title, img, marker);
  };

  const currentImg = getCurrentAdvertImageUrl();
  if (currentImg) {
    loadReverseImageCheck(engine.title, currentImg, marker);
  }

  box.appendChild(btn);
  box.appendChild(marker);
  wrap.appendChild(box);
});

  const contactedRow = document.createElement("span");
  contactedRow.style.display = "flex";
  contactedRow.style.justifyContent = "flex-end";
  contactedRow.style.width = "100%";
  contactedRow.style.flexBasis = "100%";
  contactedRow.style.gap = "6px";
  contactedRow.appendChild(createContactedButton(contactedIdentity));
  contactedRow.appendChild(createFakeButton(fakeIdentity));
  contactedRow.appendChild(createRotatingButton(fakeIdentity));
  const waDigits = getRawWhatsappDigits(document.querySelector(".phone_link")?.getAttribute("data-phone-number") || document.querySelector(".phone_link")?.textContent || "");
  contactedRow.appendChild(createRotatingButton(waDigits ? `phone:${waDigits}` : fakeIdentity, true));
  contactedRow.appendChild(createRotatingButton(fakeIdentity, false, true));
  wrap.appendChild(contactedRow);

  const parent = heart.parentElement;
  parent.style.display = "flex";
  parent.style.alignItems = "center";
  parent.style.justifyContent = "flex-end";
  parent.insertBefore(wrap, heart);
}
document.addEventListener("click", e => {
  const button = e.target.closest?.(".vs-fav-controls button");
  if (!button || typeof button.onclick === "function") return;
  const controls = button.closest(".vs-fav-controls");
  const item = getFavouriteCards().find(x => x.card.contains(controls));
  if (!item) return;
  const action = button.textContent.trim();
  if (!/^(Notes(?: ✓)?|Save|Clear)$/.test(action)) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  const box = controls.querySelector(".vs-notes-box");
  const textarea = controls.querySelector("textarea");
  const notesButton = Array.from(controls.querySelectorAll("button")).find(b => /^Notes/.test(b.textContent));
  if (action.startsWith("Notes")) {
    const opening = box.style.display === "none";
    box.style.display = opening ? "block" : "none";
    favUiInteracting = opening;
    if (opening) chrome.storage.local.get([FAV_STORAGE_KEY], res => {
      textarea.value = (res[FAV_STORAGE_KEY] || {})[item.key]?.note || "";
      textarea.focus();
    });
    return;
  }
  const note = action === "Clear" ? "" : textarea.value.trim();
  saveFavouriteNote(item.key, note, error => {
    if (error) { alert("Note save failed: " + error); return; }
    textarea.value = note;
    notesButton.textContent = note ? "Notes ✓" : "Notes";
    if (action === "Save") box.style.display = "none";
    favUiInteracting = false;
  });
}, true);

function injectFavouriteControls(data) {
  const cards = getFavouriteCards();

  cards.forEach((item) => {
    const existing = item.card.querySelector(".vs-fav-controls");
    if (existing) existing.remove();

    const meta = data[item.key] || { group: FAV_GROUPS[1] || FAV_GROUPS[0] || "Watchlist", order: 999999 };
    const currentNote = meta.note || "";
    const currentGroup = mapLegacyGroup(meta.group) || "Watchlist";

    const controls = document.createElement("div");
    controls.className = "vs-fav-controls";
    controls.style.display = "flex";
    controls.style.alignItems = "center";
    controls.style.gap = "6px";
    controls.style.margin = "6px 0 8px 0";
    controls.style.flexWrap = "wrap";
controls.style.rowGap = "6px";
    controls.style.position = "relative";
    protectControls(controls);
    controls.style.background = "rgba(255,255,255,0.92)";
    controls.style.padding = "4px 0";

    ["click", "mousedown", "mouseup", "pointerdown"].forEach((evt) => {
      controls.addEventListener(evt, function (e) {
        e.stopPropagation();
      });
    });

    const groupButtonWrap = document.createElement("div");
    groupButtonWrap.style.display = "flex";
    groupButtonWrap.style.gap = "4px";
    groupButtonWrap.style.alignItems = "center";
    groupButtonWrap.style.flexWrap = "wrap";

    FAV_GROUPS.forEach((groupName) => {
      const groupBtn = document.createElement("button");
      groupBtn.type = "button";
      groupBtn.textContent = groupName;
      groupBtn.style.padding = "2px 7px";
      groupBtn.style.cursor = "pointer";
      groupBtn.style.borderRadius = "4px";
      groupBtn.style.border = "1px solid rgba(0,0,0,0.18)";
      groupBtn.style.fontSize = "12px";
      groupBtn.style.fontWeight = "600";

      if (currentGroup === groupName) {
        const colours = getGroupColours(groupName);
        groupBtn.style.background = colours.header;
        groupBtn.style.color = "#111";
      } else {
        groupBtn.style.background = "#fff";
        groupBtn.style.color = "#333";
      }

groupBtn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();
  if (currentGroup === groupName) return;
  const currentScrollY = window.scrollY;

  changeItemGroup(item.key, groupName, currentScrollY);

  return false;
};

      groupButtonWrap.appendChild(groupBtn);
    });

    const upBtn = document.createElement("button");
    upBtn.type = "button";
    upBtn.textContent = "↑";
    upBtn.style.padding = "2px 8px";
    upBtn.style.cursor = "pointer";
    upBtn.style.borderRadius = "4px";
    upBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      moveItemWithinGroup(item.key, "up");
    };

    const downBtn = document.createElement("button");
    downBtn.type = "button";
    downBtn.textContent = "↓";
    downBtn.style.padding = "2px 8px";
    downBtn.style.cursor = "pointer";
    downBtn.style.borderRadius = "4px";
    downBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      moveItemWithinGroup(item.key, "down");
    };

    const notesBtn = document.createElement("button");
    notesBtn.type = "button";
    notesBtn.textContent = currentNote ? "Notes ✓" : "Notes";
    notesBtn.style.padding = "2px 8px";
    notesBtn.style.cursor = "pointer";
    notesBtn.style.borderRadius = "4px";
    notesBtn.style.fontWeight = "600";

    const notesBox = document.createElement("div");
    notesBox.className = "vs-notes-box";
    notesBox.style.display = "none";
    notesBox.style.width = "100%";
    notesBox.style.marginTop = "6px";
    notesBox.style.padding = "8px";
    notesBox.style.border = "1px solid rgba(0,0,0,0.12)";
    notesBox.style.borderRadius = "8px";
    notesBox.style.background = "rgba(255,255,255,0.96)";

    const textarea = document.createElement("textarea");
    textarea.value = currentNote;
    textarea.placeholder = "Add notes e.g. postcode, timing, reminder...";
    textarea.style.width = "100%";
    textarea.style.minHeight = "52px";
    textarea.style.resize = "vertical";
    textarea.style.fontSize = "12px";
    textarea.style.padding = "6px";
    textarea.style.borderRadius = "6px";
    textarea.style.border = "1px solid rgba(0,0,0,0.18)";
    textarea.style.boxSizing = "border-box";

    ["click", "mousedown", "mouseup", "keydown", "focus"].forEach(function (evt) {
      textarea.addEventListener(evt, function (e) {
        favUiInteracting = true;
        e.stopPropagation();
      });
    });

    textarea.addEventListener("blur", function () {
      setTimeout(function () {
        favUiInteracting = false;
      }, 500);
    });

    const notesActions = document.createElement("div");
    notesActions.style.display = "flex";
    notesActions.style.gap = "8px";
    notesActions.style.marginTop = "8px";
notesActions.style.width = "100%";

    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.textContent = "Save";
    saveBtn.style.padding = "4px 10px";
    saveBtn.style.borderRadius = "6px";
    saveBtn.style.cursor = "pointer";
    saveBtn.style.fontWeight = "700";
saveBtn.style.flex = "1";
saveBtn.style.padding = "8px 0";
saveBtn.style.textAlign = "center";
saveBtn.style.background = "#111";
saveBtn.style.color = "#fff";
saveBtn.style.border = "0";

    const clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.textContent = "Clear";
    clearBtn.style.padding = "4px 10px";
    clearBtn.style.borderRadius = "6px";
    clearBtn.style.cursor = "pointer";
clearBtn.style.flex = "1";
clearBtn.style.padding = "8px 0";
clearBtn.style.textAlign = "center";
clearBtn.style.background = "#eee";
clearBtn.style.border = "0";

    const noteStatus = document.createElement("span");
    noteStatus.style.fontSize = "12px";
    noteStatus.style.color = "#555";
    noteStatus.style.alignSelf = "center";

    notesBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      favUiInteracting = true;

      const isOpening = notesBox.style.display === "none";
      notesBox.style.display = isOpening ? "block" : "none";

      if (isOpening) {
        chrome.storage.local.get([FAV_STORAGE_KEY], res => {
          if (!notesBox.isConnected || notesBox.style.display === "none") return;
          textarea.value = (res[FAV_STORAGE_KEY] || {})[item.key]?.note || "";
          textarea.focus();
        });
      } else {
        setTimeout(function () {
          favUiInteracting = false;
        }, 300);
      }
    };

saveBtn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  favUiInteracting = true;

  const savedText = textarea.value.trim();

  saveFavouriteNote(item.key, savedText, function (error) {
    if (error) {
      noteStatus.textContent = "Save failed: " + error;
      favUiInteracting = false;
      return;
    }
    textarea.value = savedText;
    notesBtn.textContent = savedText ? "Notes ✓" : "Notes";
    noteStatus.textContent = "Saved";

    textarea.blur();
    notesBox.style.display = "none";

    setTimeout(function () {
      noteStatus.textContent = "";
      favUiInteracting = false;
    }, 600);
  });
};

    clearBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      textarea.value = "";

      favUiInteracting = true;

      saveFavouriteNote(item.key, "", function (error) {
        if (error) { noteStatus.textContent = "Save failed: " + error; favUiInteracting = false; return; }
        notesBtn.textContent = "Notes";
        noteStatus.textContent = "Cleared";

        setTimeout(function () {
          noteStatus.textContent = "";
        }, 1400);

        setTimeout(function () {
          favUiInteracting = false;
        }, 1600);
      });
    };

  notesActions.appendChild(clearBtn);
notesActions.appendChild(saveBtn);
notesActions.appendChild(noteStatus);

    notesBox.appendChild(textarea);
    notesBox.appendChild(notesActions);

const actionWrap = document.createElement("div");
actionWrap.style.display = "flex";
actionWrap.style.alignItems = "center";
actionWrap.style.gap = "6px";
actionWrap.style.width = "100%";
actionWrap.style.marginTop = "2px";

actionWrap.appendChild(upBtn);
actionWrap.appendChild(downBtn);
actionWrap.appendChild(notesBtn);

controls.appendChild(groupButtonWrap);
controls.appendChild(actionWrap);
controls.appendChild(notesBox);

    item.card.insertBefore(controls, item.card.firstChild);
    renderSavedNote(item.card, currentNote);
  });
}

function applyFavouriteCustomisation(callback) {
  if (!isFavouritesPage()) return;
  if (favApplying || favUiInteracting) return;

  const cards = getFavouriteCards();
  if (!cards.length) return;

  favApplying = true;

  loadFavouriteGroups(function () {
    ensureFavouriteDefaults(function (data) {
      try {
        data = normaliseGroupOrders(data);
        reorderFavouritesDom(data);
        insertGroupHeaders(data);
        applyGroupCardColours(data);
        injectFavouriteControls(data);
        createCopyLiveListButton(data);
        favLastCardSignature = getFavouriteCardSignature();
      } finally {
        favApplying = false;
        if (callback) callback();
      }
    });
  });
}

function pauseFavouriteObserver(ms) {
  favUiInteracting = true;
  favObserverPausedUntil = Date.now() + ms;
}

function isFavouriteObserverPaused() {
  return favApplying || favUiInteracting || Date.now() < favObserverPausedUntil;
}

function getFavouriteCardSignature() {
  return getFavouriteCards()
    .map((item) => {
      if (!favCardNodeIds.has(item.card)) {
        favCardNodeIds.set(item.card, favNextCardNodeId++);
      }

      return `${item.key}#${favCardNodeIds.get(item.card)}`;
    })
    .sort()
    .join("|");
}

function scheduleFavouriteNetworkHydration(delay) {
  if (!isFavouritesPage()) return;

  clearTimeout(favNetworkTimer);
  const expectedSignature = getFavouriteCardSignature();

  favNetworkTimer = setTimeout(function () {
    if (!isFavouritesPage() || listingsPassRunning || isFavouriteObserverPaused()) {
      scheduleFavouriteNetworkHydration(500);
      return;
    }

    const currentSignature = getFavouriteCardSignature();
    if (!currentSignature || currentSignature !== expectedSignature) {
      scheduleFavouriteNetworkHydration(1400);
      return;
    }

    // Cached cards are already complete. This only fetches genuinely new
    // adverts or older entries that still need their gallery cached.
    processListingsPage();
  }, typeof delay === "number" ? delay : 1400);
}

function scheduleFavouriteCacheRender(delay) {
  if (!isFavouritesPage()) return;

  clearTimeout(favCacheTimer);
  favCacheTimer = setTimeout(function () {
    if (isFavouritesPage()) renderCachedListingsPage();
  }, typeof delay === "number" ? delay : 20);
}

function scheduleFavouriteRefresh(delay) {
  if (!isFavouritesPage()) return;

  clearTimeout(favTimer);
  favTimer = setTimeout(function () {
    if (!isFavouritesPage()) return;
    if (isFavouriteObserverPaused()) {
      scheduleFavouriteRefresh(300);
      return;
    }

    const signature = getFavouriteCardSignature();
    const groupsMissing = !document.querySelector(".vs-fav-group-header");

    if (!signature) return;
    if (signature === favLastCardSignature && !groupsMissing) {
      favPendingCardSignature = "";
      return;
    }

    applyFavouriteCustomisation(function () {
      renderCachedListingsPage(function () {
        favPendingCardSignature = "";
        scheduleFavouriteNetworkHydration(100);
      });
    });
  }, typeof delay === "number" ? delay : 500);
}

function initFavouritesMode() {
  if (!isFavouritesPage()) return;

  combineFavouritePages();
  scheduleFavouriteCacheRender(0);
  scheduleFavouriteRefresh(120);
  if (favObserverStarted) return;
  favObserverStarted = true;

  favObserver = new MutationObserver(function (records) {
    const owned = '.newData,.vs-fav-controls,.vs-listing-thumb-strip,.vs-fast-tooltip,.vs-image-hover-preview,#vs-preview-popup,#vs-all-favourites-status';
    if (records.every(record => record.target.nodeType === 1 && record.target.closest(owned) ||
        [...record.addedNodes, ...record.removedNodes].length > 0 &&
        [...record.addedNodes, ...record.removedNodes].every(node => node.nodeType === 1 && node.matches('.vs-fast-tooltip,.vs-image-hover-preview,#vs-preview-popup')))) return;
    if (favouritePageLinks(document).some(url => !favCombinedPages.has(url))) combineFavouritePages();
    restoreCombinedFavouriteCards();
    if (!favPageLoads && !favPageQueue.length && !favPageFailure && favCombinedPages.size > 1) {
      favouritePageStatus(`All ${getFavouriteCards().length} favourites on one page`);
    }
    if (getFavouriteCards().some(({card}) => card.dataset.vsTamerProcessed === "1" &&
        card.dataset.vsTamerFiltered !== "1" && (!card.querySelector(".newData") ||
        (Number(card.dataset.vsGalleryExpected) > 0 && !card.querySelector(".vs-listing-thumb-strip"))))) {
      scheduleFavouriteCacheRender(20);
    }
    if (isFavouriteObserverPaused()) {
      scheduleFavouriteRefresh(600);
      return;
    }

    const signature = getFavouriteCardSignature();
    const groupsMissing = !document.querySelector(".vs-fav-group-header");
    if (!signature || (signature === favLastCardSignature && !groupsMissing)) return;
    if (signature === favPendingCardSignature) return;

    favPendingCardSignature = signature;
    clearTimeout(favNetworkTimer);
    scheduleFavouriteCacheRender(20);
    scheduleFavouriteRefresh(180);
  });

  favObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
}

/* =========================
   PAGINATION KILLER
========================= */

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || message.action !== "vsRunPaginationKiller") return;

  runPaginationKiller(message.maxPages || 6);
  sendResponse({ ok: true });
});

function paginationFetchHtml(url, callback) {
  chrome.runtime.sendMessage(
    { action: "fetchHTML", url },
    function (response) {
      callback(response && response.html ? response.html : "");
    }
  );
}

function getPaginationBaseUrls(maxPages) {
  const urls = new Set();

  urls.add(cleanLink(location.href) + location.search);

  const pageLinks = Array.from(document.querySelectorAll("a[href]"))
    .map((a) => a.href)
    .filter((href) => {
      if (!href) return false;
      if (!href.includes("vivastreet.co.uk")) return false;
      if (!href.includes(location.pathname.split("/")[1] || "")) return false;
      return /([?&]page=\d+|\/page\/\d+|\/p\/\d+|\/t\+\d+)/i.test(href);
    });

  pageLinks.forEach((href) => urls.add(href));

  if (urls.size < maxPages) {
    for (let i = 2; i <= maxPages; i++) {
      try {
        const u = new URL(location.href);
        const nativeNext = pageLinks.find(href => /\/t\+\d+/.test(href));
        if (nativeNext) {
          const next = new URL(nativeNext);
          next.pathname = next.pathname.replace(/\/t\+\d+/, `/t+${i}`);
          urls.add(next.href);
          continue;
        }
        u.searchParams.set("page", String(i));
        urls.add(u.href);
      } catch (e) {}
    }
  }

  return Array.from(urls).slice(0, maxPages);
}

function extractListingLinksFromHtml(html) {
  const temp = document.createElement("div");
  temp.innerHTML = html;

  const links = Array.from(temp.querySelectorAll("a.clad__ad_link, a[href]"))
    .map((a) => a.href || a.getAttribute("href") || "")
    .filter((href) => {
      if (!href) return false;
      if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(href)) return false;
      if (!/\/\d{6,}/.test(href)) return false;
      return true;
    })
    .map((href) => {
      try {
        return href.startsWith("http") ? href : new URL(href, location.origin).href;
      } catch (e) {
        return "";
      }
    })
    .filter(Boolean)
    .map(cleanLink);

  return Array.from(new Set(links));
}

function extractAdvertDataForPagination(url, html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  const ogTitle =
    doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ||
    "";

  const h1Title =
    doc.querySelector("h1")?.innerText?.trim() ||
    doc.querySelector(".kiwii-font-xlarge")?.innerText?.trim() ||
    doc.querySelector('[data-automation="adTitle"]')?.innerText?.trim() ||
    "";

let title = h1Title || ogTitle || doc.title || "Advert";

// 🔥 CLEAN JUNK FROM TITLE
title = title
  .replace(/18\+\s*id\s*verified/gi, "")   // remove "18+ ID Verified"
  .replace(/verified/gi, "")              // fallback catch
  .replace(/\s+/g, " ")                  // normalize spaces
  .trim();

  let nationality = "-";
  let age = "-";

  doc.querySelectorAll("tr").forEach((row) => {
    const cells = row.querySelectorAll("td");
    if (cells.length < 2) return;

    const label = cells[0].textContent.trim();
    const value = cells[1].textContent.trim();

    if (label === "Nationality") nationality = value;
    if (label === "Age") age = value.replace(/\s*years old/i, "").trim();
  });

  const phoneNumberElement = doc.querySelector(".phone_link");
  const rawPhoneNumber = phoneNumberElement
    ? phoneNumberElement.getAttribute("data-phone-number")
    : "";

  const rawWhatsappDigits = getRawWhatsappDigits(rawPhoneNumber);
  const displayPhone = formatDisplayPhone(rawPhoneNumber);

  const fmin =
    doc.querySelector('[data-automation="tdRate15minutesIncall"]')?.textContent.trim() || "-";
  const tmin =
    doc.querySelector('[data-automation="tdRate30minutesIncall"]')?.textContent.trim() || "-";
  const hr =
    doc.querySelector('[data-automation="tdRate1hourIncall"]')?.textContent.trim() || "-";

  let image =
    doc.querySelector('meta[property="og:image"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:image"]')?.getAttribute("content") ||
    doc.querySelector(".kiwii-carousel img")?.getAttribute("src") ||
    doc.querySelector(".gallery img")?.getAttribute("src") ||
    doc.querySelector("img")?.getAttribute("src") ||
    "";

  if (image && image.startsWith("/")) {
    image = new URL(image, location.origin).href;
  }

  const area = extractAreaFromUrl(url);

  return {
    url,
    title,
    area,
    image,
    nationality,
    age,
    fmin,
    tmin,
    hr,
    rawWhatsappDigits,
    displayPhone
  };
}
function createPaginationOverlay() {
  const old = document.getElementById("vs-pagination-killer-overlay");
  if (old) old.remove();

  const overlay = document.createElement("div");
  overlay.id = "vs-pagination-killer-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "20px";
  overlay.style.right = "20px";
  overlay.style.width = "420px";
  overlay.style.maxHeight = "85vh";
  overlay.style.overflow = "auto";
  overlay.style.zIndex = "999999";
  overlay.style.background = "#fff";
  overlay.style.border = "1px solid rgba(0,0,0,0.18)";
  overlay.style.borderRadius = "12px";
  overlay.style.boxShadow = "0 12px 34px rgba(0,0,0,0.28)";
  overlay.style.padding = "12px";
  overlay.style.fontFamily = "Arial, sans-serif";
  overlay.style.color = "#111";

overlay.innerHTML = `
  <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
    
    <button id="vs-pk-screengrab" style="
      border:0;
      border-radius:8px;
      padding:8px 12px;
      cursor:pointer;
      font-weight:700;
      background:#25D366;
      color:#fff;
      font-size:12px;
    ">Screengrab</button>

    <div style="font-size:16px;font-weight:800;flex:1;text-align:center;">
      Filtered Matches
    </div>

    <button id="vs-pk-close" style="
      border:0;
      background:#eee;
      border-radius:7px;
      padding:5px 8px;
      cursor:pointer;
      font-weight:700;
    ">×</button>

  </div>

  <div id="vs-pk-status" style="font-size:12px;color:#555;margin-bottom:10px;">
    Starting scan...
  </div>

  <div id="vs-pk-results"></div>
`;

  document.body.appendChild(overlay);

  overlay.querySelector("#vs-pk-close").onclick = function () {
    overlay.remove();
  };

overlay.querySelector("#vs-pk-screengrab").onclick = function () {
  captureFullPaginationOverlay(overlay);
};

  return overlay;
}

function captureFullPaginationOverlay(overlay) {
  if (!overlay) return;

  const oldScrollTop = overlay.scrollTop;
  const oldOverflow = overlay.style.overflow;

  const dpr = window.devicePixelRatio || 1;
  const rect = overlay.getBoundingClientRect();

  const totalHeight = overlay.scrollHeight;
  const viewportHeight = Math.floor(rect.height);
  const totalWidth = Math.floor(rect.width);

  const segments = [];
  let y = 0;

  updatePaginationStatus("Capturing full overlay...");

  function captureNext() {
    if (y >= totalHeight) {
      overlay.scrollTop = oldScrollTop;
      overlay.style.overflow = oldOverflow;

      chrome.runtime.sendMessage({
        action: "vsStitchScreengrab",
        segments,
        width: totalWidth,
        height: totalHeight,
        dpr
      }, function () {
        updatePaginationStatus("Full screengrab saved");
      });

      return;
    }

    overlay.scrollTop = y;

    setTimeout(function () {
      const liveRect = overlay.getBoundingClientRect();
      const visibleHeight = Math.min(viewportHeight, totalHeight - y);

      chrome.runtime.sendMessage({
        action: "vsCaptureVisibleCrop",
        crop: {
          x: liveRect.left,
          y: liveRect.top,
          width: liveRect.width,
          height: visibleHeight,
          dpr
        },
        offsetY: y
      }, function (res) {
        if (res && res.ok && res.dataUrl) {
          segments.push({
            dataUrl: res.dataUrl,
            y
          });
        }

        y += viewportHeight;
        captureNext();
      });
    }, 180);
  }

  captureNext();
}

function updatePaginationStatus(text) {
  const el = document.querySelector("#vs-pk-status");
  if (el) el.textContent = text;
}

function addPaginationResultCard(item) {
  const results = document.querySelector("#vs-pk-results");
  if (!results) return;

  const card = document.createElement("a");
  card.href = item.url;
  card.target = "_blank";

  card.style.display = "flex";
  card.style.gap = "10px";
  card.style.border = "1px solid rgba(0,0,0,0.10)";
  card.style.borderRadius = "10px";
  card.style.padding = "8px";
  card.style.margin = "8px 0";
  card.style.background = "#f9fafb";
  card.style.textDecoration = "none";
  card.style.color = "#111";

  const imgHtml = item.image
    ? `<img src="${item.image}" style="width:82px;height:90px;object-fit:cover;border-radius:8px;flex-shrink:0;">`
    : `<div style="width:82px;height:90px;border-radius:8px;background:#eee;flex-shrink:0;"></div>`;

  card.innerHTML = `
    ${imgHtml}

    <div style="flex:1;min-width:0;">

      <div style="
        font-size:13px;
        font-weight:800;
        margin-bottom:4px;
        line-height:1.25;
        display:-webkit-box;
        -webkit-line-clamp:2;
        -webkit-box-orient:vertical;
        overflow:hidden;
        text-overflow:ellipsis;
      ">
        ${item.title || "Advert"}
      </div>

      <div style="font-size:12px;color:#1f4ed8;margin-bottom:4px;font-weight:600;">
        15m-${item.fmin || "-"} | 30m-${item.tmin || "-"} | 1hr-${item.hr || "-"}
      </div>

      <div style="font-size:12px;color:#0a7a0a;margin-bottom:4px;">
        ${getNationalityFlag(item.nationality)} ${item.nationality || "-"} | Age: ${item.age || "-"}
      </div>

      <div style="font-size:12px;color:#0a7a0a;margin-bottom:4px;font-weight:600;">
        ${item.displayPhone || "-"}
      </div>

      <div style="font-size:12px;color:#555;">
        ${item.area || "-"}
      </div>

    </div>
  `;

  results.appendChild(card);
}
function runPaginationKiller(maxPages) {
  createPaginationOverlay();

  getFilters(function (filters) {
    const pageUrls = getPaginationBaseUrls(maxPages);
    const allAdLinks = new Set();
    const matched = [];

    let pageIndex = 0;

    function fetchNextPage() {
      if (pageIndex >= pageUrls.length) {
        const adLinks = Array.from(allAdLinks);

        if (!adLinks.length) {
          updatePaginationStatus("No adverts found on scanned pages.");
          return;
        }

        updatePaginationStatus(`Found ${adLinks.length} adverts. Checking filters...`);
        scanAdLinks(adLinks, filters, matched);
        return;
      }

      const pageUrl = pageUrls[pageIndex];
      pageIndex += 1;

      updatePaginationStatus(`Scanning page ${pageIndex} of ${pageUrls.length}...`);

      paginationFetchHtml(pageUrl, function (html) {
        const links = extractListingLinksFromHtml(html);
        links.forEach((href) => allAdLinks.add(href));

        setTimeout(fetchNextPage, 250);
      });
    }

    fetchNextPage();
  });
}

function scanAdLinks(adLinks, filters, matched) {
  let index = 0;
  let active = 0;
  const maxConcurrent = 5;

  function finishIfDone() {
    if (index >= adLinks.length && active === 0) {
      updatePaginationStatus(
        `Done. ${matched.length} matching advert${matched.length === 1 ? "" : "s"} found.`
      );
      return true;
    }

    return false;
  }

  function pump() {
    while (active < maxConcurrent && index < adLinks.length) {
      const url = adLinks[index];
      index += 1;
      active += 1;

      updatePaginationStatus(
        `Checking adverts ${Math.min(index, adLinks.length)} / ${adLinks.length}. Matches: ${matched.length}`
      );

      paginationFetchHtml(url, function (html) {
        active -= 1;

        if (!html) {
          if (!finishIfDone()) {
            setTimeout(pump, 120);
          }
          return;
        }

        const data = extractAdvertDataForPagination(url, html);

        chrome.storage.local.get([AD_META_KEY], function (res) {
          const metaCache = res[AD_META_KEY] || {};
          const savedMeta = metaCache[cleanLink(url)] || {};

          if (savedMeta.preferredImage) {
            data.image = savedMeta.preferredImage;
          } else if (savedMeta.image) {
            data.image = savedMeta.image;
          }

          if (
            passesFilters(
              {
                fmin: data.fmin,
                tmin: data.tmin,
                hr: data.hr,
                nationality: data.nationality
              },
              filters
            )
          ) {
            matched.push(data);
            addPaginationResultCard(data);
          }

          if (!finishIfDone()) {
            setTimeout(pump, 120);
          }
        });
      });
    }
  }

  pump();
}

function rerunEnhancements() {
  console.log("VS Tamer: rerunEnhancements", location.pathname);

if (isAdvertPage()) {
    injectReverseImageTopRight();
    injectPreferredMainImageButton();
    injectAdvertMessageButtons();
    return;
  }

  if (isFavouritesPage()) {
    initFavouritesMode();
    return;
  }

  renderCachedListingsPage(() => processListingsPage());
}

let vsTamerTimer = null;

function scheduleVsTamerRun() {
  clearTimeout(vsTamerTimer);

  vsTamerTimer = setTimeout(function () {
    try {
      rerunEnhancements();
    } catch (e) {
      console.error("VS Tamer ERROR:", e);
    }
  }, 400);
}

function startVsTamer() {
  console.log("VS Tamer starting with page observer");

  scheduleVsTamerRun();

  let observedUrl = location.href;
  const observer = new MutationObserver(function () {
    if (observedUrl !== location.href) {
      observedUrl = location.href;
      scheduleVsTamerRun();
    }
    if (isFavouritesPage()) return;
    if (isAdvertPage()) {
      if (!document.getElementById("vs-reverse-image-buttons-inline") ||
          (document.querySelector(".phone_link") && !document.getElementById("vs-advert-message-buttons"))) scheduleVsTamerRun();
      return;
    }
    const missing = Array.from(document.querySelectorAll("a[href]"))
      .filter(a => /\/(escort|massage|escorts)\/.*\/\d{6,}(?:[?#]|$)/i.test(a.href))
      .some(a => {
        const card = getListingCardFromLink(a);
        return card && (!card.querySelector(".newData") ||
          (Number(card.dataset.vsGalleryExpected) > 0 && !card.querySelector(".vs-listing-thumb-strip"))) && card.dataset.vsTamerProcessing !== "1" &&
          card.dataset.vsTamerFiltered !== "1";
      });
    if (missing) scheduleVsTamerRun();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startVsTamer);
} else {
  startVsTamer();
}
})();
