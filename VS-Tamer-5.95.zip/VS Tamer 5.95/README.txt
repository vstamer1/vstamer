VS Tamer

Chrome extension for vivastreet.co.uk. Enhances listing details, favourites, Notes, contact flags, messaging, previews, reverse-image searches and filters.

Update: replace existing unpacked files, Reload in chrome://extensions, then refresh Vivastreet. Do not uninstall if retaining saved data. First installation: enable Developer mode and Load unpacked, selecting the folder containing manifest.json.

Privacy: donation wallets, Support/QR requests, Finder files and icon-generation metadata removed from this distribution. ZIP ownership is omitted and timestamps standardised. Branding remains; copies can still be recognised.

Saved activity is separate from this folder. Chrome holds Notes, favourites, flags, cached adverts and the last WhatsApp draft. Legacy favourites backup may use Chrome sync. Exported backups contain private data and are Base64-encoded, not encrypted. Keep backups private.

Vivastreet/image requests, WhatsApp and reverse-image searches still use external services. SMS needs a compatible messaging app. Storage keys and backup compatibility are unchanged.
