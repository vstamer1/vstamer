chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id) return;

  chrome.tabs.sendMessage(tab.id, "toggle", () => {
    if (chrome.runtime.lastError) {
      console.log("VS Tamer toggle skipped:", chrome.runtime.lastError.message);
    } else {
      console.log("VS Tamer toggle message sent");
    }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!request || request.action !== "fetchHTML") return;

  fetch(request.url, {
    credentials: "include"
  })
    .then((response) => response.text())
    .then((html) => {
      sendResponse({ html });
    })
    .catch((error) => {
      console.error("VS Tamer fetchHTML error:", error);
      sendResponse({ html: null, error: String(error) });
    });

  return true;
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || message.action !== "vsTakeScreengrab") return;

  chrome.tabs.captureVisibleTab(
    sender.tab.windowId,
    { format: "jpeg", quality: 85 },
    async function (dataUrl) {
      try {
        if (chrome.runtime.lastError || !dataUrl) {
          console.log("VS screengrab error:", chrome.runtime.lastError?.message);
          sendResponse({ ok: false });
          return;
        }

        const crop = message.crop;

        const originalBlob = await fetch(dataUrl).then(r => r.blob());
        const bitmap = await createImageBitmap(originalBlob);

        const canvas = new OffscreenCanvas(
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr)
        );

        const ctx = canvas.getContext("2d");

        ctx.drawImage(
          bitmap,
          Math.round(crop.x * crop.dpr),
          Math.round(crop.y * crop.dpr),
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr),
          0,
          0,
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr)
        );

        const croppedBlob = await canvas.convertToBlob({
          type: "image/jpeg",
          quality: 0.85
        });

        const arrayBuffer = await croppedBlob.arrayBuffer();
        const bytes = new Uint8Array(arrayBuffer);

        let binary = "";
        for (let i = 0; i < bytes.length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }

        const croppedDataUrl = "data:image/jpeg;base64," + btoa(binary);

        const d = new Date();
        const yy = String(d.getFullYear()).slice(-2);
        const mm = String(d.getMonth() + 1).padStart(2, "0");
        const dd = String(d.getDate()).padStart(2, "0");

        chrome.downloads.download({
          url: croppedDataUrl,
          filename: `screendefaultrender${yy}${mm}${dd}.jpg`,
          saveAs: false,
          conflictAction: "uniquify"
        });

        sendResponse({ ok: true });

      } catch (e) {
        console.log("VS screengrab crop error:", e);
        sendResponse({ ok: false, error: String(e) });
      }
    }
  );

  return true;
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || message.action !== "vsCaptureVisibleCrop") return;

  chrome.tabs.captureVisibleTab(
    sender.tab.windowId,
    { format: "jpeg", quality: 85 },
    async function (dataUrl) {
      try {
        if (chrome.runtime.lastError || !dataUrl) {
          sendResponse({ ok: false });
          return;
        }

        const crop = message.crop;

        const originalBlob = await fetch(dataUrl).then(r => r.blob());
        const bitmap = await createImageBitmap(originalBlob);

        const canvas = new OffscreenCanvas(
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr)
        );

        const ctx = canvas.getContext("2d");

        ctx.drawImage(
          bitmap,
          Math.round(crop.x * crop.dpr),
          Math.round(crop.y * crop.dpr),
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr),
          0,
          0,
          Math.round(crop.width * crop.dpr),
          Math.round(crop.height * crop.dpr)
        );

        const blob = await canvas.convertToBlob({
          type: "image/jpeg",
          quality: 0.85
        });

        const buffer = await blob.arrayBuffer();
        const bytes = new Uint8Array(buffer);

        let binary = "";
        for (let i = 0; i < bytes.length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }

        sendResponse({
          ok: true,
          dataUrl: "data:image/jpeg;base64," + btoa(binary)
        });
      } catch (e) {
        console.log("VS segment capture error:", e);
        sendResponse({ ok: false, error: String(e) });
      }
    }
  );

  return true;
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || message.action !== "vsStitchScreengrab") return;

  (async function () {
    try {
      const dpr = message.dpr || 1;
      const width = Math.round(message.width * dpr);
      const height = Math.round(message.height * dpr);

      const canvas = new OffscreenCanvas(width, height);
      const ctx = canvas.getContext("2d");

      for (const segment of message.segments || []) {
        const blob = await fetch(segment.dataUrl).then(r => r.blob());
        const bitmap = await createImageBitmap(blob);

        ctx.drawImage(
          bitmap,
          0,
          Math.round(segment.y * dpr)
        );
      }

      const finalBlob = await canvas.convertToBlob({
        type: "image/jpeg",
        quality: 0.85
      });

      const buffer = await finalBlob.arrayBuffer();
      const bytes = new Uint8Array(buffer);

      let binary = "";
      for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
      }

      const finalDataUrl = "data:image/jpeg;base64," + btoa(binary);

      const d = new Date();
      const yy = String(d.getFullYear()).slice(-2);
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");

      chrome.downloads.download({
        url: finalDataUrl,
        filename: `screendefaultrender${yy}${mm}${dd}.jpg`,
        saveAs: false,
        conflictAction: "uniquify"
      });

      sendResponse({ ok: true });
    } catch (e) {
      console.log("VS stitch screengrab error:", e);
      sendResponse({ ok: false, error: String(e) });
    }
  })();

  return true;
});