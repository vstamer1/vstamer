(() => {
  if (!location.hostname.includes("vivastreet.co.uk")) return;

  const NUMBERS_KEY = "numbers";
  const AD_META_KEY = "vsAdMeta";
  const ADVERTISER_CACHE_KEY = "vsAdvertiserCache";
  const FILTERS_KEY = "vsFilters";
const IMAGE_CHECK_KEY = "vsReverseImageChecks";

  const FAV_STORAGE_KEY = "vsFavouriteCustomOrder";
  const FAV_STORAGE_SYNC_KEY = "vsFavouriteCustomOrderSync";
  const FAV_GROUPS = ["Live", "Watchlist", "Carousel"];

function isAdvertPage() {
  return /\/(escort|massage|escorts)\//i.test(location.pathname) && /\/\d{6,}/.test(location.pathname);
}

let favObserverStarted = false;
let favApplying = false;
let favUiInteracting = false;
let favObserver = null;
let favObserverPausedUntil = 0;

const VS_WA_SELECTED = {};
const VS_WA_DEFAULT_MESSAGE = "Hi...";

  function cleanLink(url) {
    return (url || "").split("?")[0];
  }

  function getListingCardFromLink(link) {
    return (
      link.closest(".clad__ad") ||
      link.closest("article") ||
      link.closest("li") ||
      link.parentElement
    );
  }

function attachFastTooltip(el, text) {
  let tooltip;

  function removeTooltip() {
    document.querySelectorAll(".vs-fast-tooltip").forEach((t) => t.remove());
    tooltip = null;
  }

  function move(e) {
    if (!tooltip) return;
    tooltip.style.left = e.clientX + 10 + "px";
    tooltip.style.top = e.clientY + 10 + "px";
  }

  el.addEventListener("mouseenter", (e) => {
    removeTooltip();

    tooltip = document.createElement("div");
    tooltip.className = "vs-fast-tooltip";
    tooltip.textContent = text;

    tooltip.style.position = "fixed";
    tooltip.style.zIndex = "999999";
    tooltip.style.background = "#111";
    tooltip.style.color = "#fff";
    tooltip.style.fontSize = "11px";
    tooltip.style.padding = "4px 6px";
    tooltip.style.borderRadius = "6px";
    tooltip.style.whiteSpace = "nowrap";
    tooltip.style.pointerEvents = "none";
    tooltip.style.boxShadow = "0 2px 6px rgba(0,0,0,0.25)";

    document.body.appendChild(tooltip);
    move(e);
  });

  el.addEventListener("mousemove", move);
  el.addEventListener("mouseleave", removeTooltip);
  el.addEventListener("mousedown", removeTooltip);
  el.addEventListener("click", removeTooltip);
  window.addEventListener("blur", removeTooltip);
}

function insertAfter(newNode, referenceNode) {
  try {
    if (!newNode || !referenceNode || !referenceNode.parentNode) return;

    const parent = referenceNode.parentNode;

    if (referenceNode.nextSibling) {
      parent.insertBefore(newNode, referenceNode.nextSibling);
    } else {
      parent.appendChild(newNode);
    }
  } catch (e) {
    console.log("VS insertAfter skipped:", e);
  }
}

  function saveFavourites(data, callback) {
    chrome.storage.local.set({ [FAV_STORAGE_KEY]: data }, function () {
      chrome.storage.sync.set({ [FAV_STORAGE_SYNC_KEY]: data }, function () {
        if (callback) callback();
      });
    });
  }

  function getRawWhatsappDigits(number) {
    if (!number) return "";
    let digits = String(number).replace(/\D/g, "");
    if (digits.startsWith("0")) digits = "44" + digits.substring(1);
    return digits;
  }

  function formatDisplayPhone(number) {
    const digits = getRawWhatsappDigits(number);
    if (!digits) return "-";
    if (digits.startsWith("44") && digits.length >= 12) {
      return `44 (0) ${digits.substring(2, 6)} ${digits.substring(6)}`;
    }
    return digits;
  }

  function normalizeNationality(value) {
    return (value || "").trim().toLowerCase();
  }

function parseMoneyNumber(text) {
  if (!text) return null;

  const clean = String(text)
    .replace(/,/g, "")
    .replace(/£/g, "")
    .trim();

  if (!clean || clean === "-") return null;

  const match = clean.match(/\d+(\.\d+)?/);
  return match ? Number(match[0]) : null;
}

  function titleCase(text) {
    return String(text || "")
      .replace(/[-_]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function extractAreaFromUrl(url) {
    try {
      const u = new URL(url);
      const parts = u.pathname.split("/").filter(Boolean);
      const typeIndex = parts.findIndex((p) =>
        ["escort", "massage", "escorts"].includes(p)
      );
      if (typeIndex !== -1 && parts[typeIndex + 1]) {
        return titleCase(decodeURIComponent(parts[typeIndex + 1]));
      }
    } catch (e) {}
    return "-";
  }

  function formatDateTime(ts) {
    if (!ts) return "-";
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${String(d.getFullYear()).slice(-2)} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function getNationalityFlag(nationality) {
    if (!nationality) return "";
    const n = nationality.toLowerCase().trim();

    const map = {
      romanian: "🇷🇴",
      romania: "🇷🇴",
      moldovan: "🇲🇩",
      moldova: "🇲🇩",
      colombian: "🇨🇴",
      brazilian: "🇧🇷",
      spanish: "🇪🇸",
      spain: "🇪🇸",
  french: "🇫🇷",
      italian: "🇮🇹",
      british: "🇬🇧",
      english: "🇬🇧",
      ukrainian: "🇺🇦",
      polish: "🇵🇱",
      hungarian: "🇭🇺",
      bulgarian: "🇧🇬",
      portuguese: "🇵🇹",
      german: "🇩🇪",
      belgian: "🇧🇪",
      dutch: "🇳🇱"
    };

    return map[n] || "";
  }

  function getGroupColours(group) {
    if (group === "Live") {
      return { header: "#fff3cd", card: "#fff3cd", border: "rgba(186,130,0,0.35)" };
    }
    if (group === "Watchlist") {
      return { header: "#e7f1ff", card: "#e7f1ff", border: "rgba(31,111,235,0.28)" };
    }
    if (group === "Carousel") {
      return { header: "#f0e5ff", card: "#f0e5ff", border: "rgba(111,66,193,0.28)" };
    }
    return { header: "#eeeeee", card: "#eeeeee", border: "rgba(0,0,0,0.10)" };
  }

function getFilters(callback) {

  chrome.storage.local.get([FILTERS_KEY], function (res) {

    const f = res[FILTERS_KEY] || {};

    callback({

      inc15m40: !!f.inc15m40,

      exc15m40: !!f.exc15m40,

      price15m: Number(f.price15m || 40),

      op15m: f.op15m || "eq",

      inc30m60: !!f.inc30m60,

      exc30m60: !!f.exc30m60,

      price30m: Number(f.price30m || 60),

      op30m: f.op30m || "eq",

      inc1hr120: !!f.inc1hr120,

      exc1hr120: !!f.exc1hr120,

      price1hr: Number(f.price1hr || 120),

      op1hr: f.op1hr || "eq",

      nat1: f.nat1 || "",

      nat2: f.nat2 || "",

      nat3: f.nat3 || "",

      incNat1: !!f.incNat1,

      excNat1: !!f.excNat1,

      incNat2: !!f.incNat2,

      excNat2: !!f.excNat2,

      incNat3: !!f.incNat3,

      excNat3: !!f.excNat3

    });

  });

}

function pricePasses(value, operator, target, isInclude) {
  const n = parseMoneyNumber(value);
  const isBlank = n === null;

  // Include = match OR blank
  if (isInclude) {
    if (isBlank) return true;
    if (operator === "lt") return n < target;
    if (operator === "eq") return n === target;
    if (operator === "gt") return n > target;
    return true;
  }

  // Exclude = exclude only actual matching values, not blanks
  if (isBlank) return true;
  if (operator === "lt") return !(n < target);
  if (operator === "eq") return n !== target;
  if (operator === "gt") return !(n > target);

  return true;
}

function passesFilters(ad, filters) {

  const n15 = parseMoneyNumber(ad.fmin);

  const n30 = parseMoneyNumber(ad.tmin);

  const n1hr = parseMoneyNumber(ad.hr);

  const nat = normalizeNationality(ad.nationality);

  const isNatBlank = !nat || nat === "-";

  function priceIncludeMatch(value, target, op) {

    if (value === null) return true;

    if (op === "lt") return value < target;

    if (op === "gt") return value > target;

    return value === target;

  }

  function priceExcludeMatch(value, target, op) {

    if (value === null) return false;

    if (op === "lt") return value < target;

    if (op === "gt") return value > target;

    return value === target;

  }

  if (filters.inc15m40 && !priceIncludeMatch(n15, filters.price15m, filters.op15m)) return false;

  if (filters.exc15m40 && priceExcludeMatch(n15, filters.price15m, filters.op15m)) return false;

  if (filters.inc30m60 && !priceIncludeMatch(n30, filters.price30m, filters.op30m)) return false;

  if (filters.exc30m60 && priceExcludeMatch(n30, filters.price30m, filters.op30m)) return false;

  if (filters.inc1hr120 && !priceIncludeMatch(n1hr, filters.price1hr, filters.op1hr)) return false;

  if (filters.exc1hr120 && priceExcludeMatch(n1hr, filters.price1hr, filters.op1hr)) return false;

  const includeNats = [];

  const excludeNats = [];

  if (filters.incNat1 && filters.nat1) includeNats.push(normalizeNationality(filters.nat1));

  if (filters.incNat2 && filters.nat2) includeNats.push(normalizeNationality(filters.nat2));

  if (filters.incNat3 && filters.nat3) includeNats.push(normalizeNationality(filters.nat3));

  if (filters.excNat1 && filters.nat1) excludeNats.push(normalizeNationality(filters.nat1));

  if (filters.excNat2 && filters.nat2) excludeNats.push(normalizeNationality(filters.nat2));

  if (filters.excNat3 && filters.nat3) excludeNats.push(normalizeNationality(filters.nat3));

  // INCLUDE nationality = match any selected include nationality OR blank

  if (includeNats.length > 0 && !includeNats.includes(nat) && !isNatBlank) return false;

  // EXCLUDE nationality = exclude only actual matching values, not blanks

  if (excludeNats.includes(nat)) return false;

  return true;

}
  function getDescriptionTextFromHtml(html) {
    if (!html) return "";

    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/\s+/g, " ")
      .trim();

    const lower = text.toLowerCase();
    const start = lower.indexOf("description");
    if (start === -1) return "";

    const adIdIndex = lower.indexOf("ad id", start);
    const contactIndex = lower.indexOf("contact the advertiser", start);

    let end = -1;
    if (adIdIndex !== -1 && contactIndex !== -1) end = Math.min(adIdIndex, contactIndex);
    else if (adIdIndex !== -1) end = adIdIndex;
    else if (contactIndex !== -1) end = contactIndex;

    if (end === -1 || end <= start) return "";

    return text.substring(start + "description".length, end).trim().toLowerCase();
  }

  function hasVideoKeyword(text) {
    if (!text) return false;
    return (
      text.includes("facetime") ||
      text.includes("whatsapp") ||
      text.includes("video call") ||
      text.includes("videocall") ||
      /\bvideo\w*/i.test(text) ||
      /\bconfirm\w*/i.test(text)
    );
  }

  function getBestImage(tempElement) {
    const selectors = [
      'meta[property="og:image"]',
      ".kiwii-carousel img",
      ".gallery img",
      ".swiper img",
      ".slick-slide img",
      ".vs-image img",
      "img"
    ];

    for (const selector of selectors) {
      const el = tempElement.querySelector(selector);
      if (!el) continue;

      let src = "";
      if (el.tagName && el.tagName.toLowerCase() === "meta") {
        src = el.getAttribute("content") || "";
      } else {
        src =
          el.getAttribute("src") ||
          el.getAttribute("data-src") ||
          el.getAttribute("data-lazy-src") ||
          "";
      }

      if (src && !src.startsWith("data:")) return src;
    }

    return "";
  }

  function upsertAdMeta(url, patch, callback) {
    chrome.storage.local.get([AD_META_KEY], function (res) {
      const data = res[AD_META_KEY] || {};
      const key = cleanLink(url);
      const now = Date.now();

      if (!data[key]) {
        data[key] = { firstSeen: now, lastSeen: now };
      } else {
        if (!data[key].firstSeen) data[key].firstSeen = now;
        data[key].lastSeen = now;
      }

      Object.assign(data[key], patch || {});

      chrome.storage.local.set({ [AD_META_KEY]: data }, function () {
        if (callback) callback(data[key]);
      });
    });
  }

  function storeNumber(rawDigits, link, advertData, callback) {
    chrome.storage.local.get([NUMBERS_KEY], function (res) {
      const numbers = res[NUMBERS_KEY] || {};
      const clean = cleanLink(link);

      if (!numbers[rawDigits]) numbers[rawDigits] = { links: [] };

      const exists = numbers[rawDigits].links.find((item) => item.url === clean);

      if (!exists) {
        numbers[rawDigits].links.push({
          url: clean,
          title: advertData.title || clean,
          price: advertData.price || "-",
          image: advertData.image || "",
          fmin: advertData.fmin || "-",
          tmin: advertData.tmin || "-",
          hr: advertData.hr || "-",
          nationality: advertData.nationality || "-",
          age: advertData.age || "-",
          ts: Date.now()
        });
      } else {
        Object.assign(exists, {
          title: advertData.title || exists.title,
          price: advertData.price || exists.price,
          image: advertData.image || exists.image,
          fmin: advertData.fmin || exists.fmin,
          tmin: advertData.tmin || exists.tmin,
          hr: advertData.hr || exists.hr,
          nationality: advertData.nationality || exists.nationality,
          age: advertData.age || exists.age,
          ts: Date.now()
        });
      }

      chrome.storage.local.set({ [NUMBERS_KEY]: numbers }, function () {
        if (callback) callback(numbers[rawDigits].links);
      });
    });
  }

  function extractAdvertiserInfo(tempElement) {
    const anchors = Array.from(tempElement.querySelectorAll("a[href]"));
    const found = anchors.find((a) => {
      const href = a.getAttribute("href") || "";
      const txt = (a.textContent || "").trim().toLowerCase();
      return href.includes("/profile/ind/") || txt.includes("posted by #");
    });

    if (!found) return null;

    const href = found.getAttribute("href") || "";
    let absoluteUrl = href.startsWith("http") ? href : new URL(href, location.origin).href;

    if (!absoluteUrl.includes("show_personal_ads=1")) {
      absoluteUrl += (absoluteUrl.includes("?") ? "&" : "?") + "show_personal_ads=1";
    }

    const m = absoluteUrl.match(/\/profile\/ind\/(\d+)/i);
    const id = m ? m[1] : null;

    return { id, url: absoluteUrl, label: (found.textContent || "").trim() };
  }

  function extractPreviewFromAdvertiserCard(anchor, adMetaCache) {
    const href = cleanLink(anchor.href || anchor.getAttribute("href") || "");
    const container =
      anchor.closest("article") ||
      anchor.closest("li") ||
      anchor.closest(".clad__ad") ||
      anchor.parentElement;

    const cached = adMetaCache && adMetaCache[href] ? adMetaCache[href] : null;

    let title = "";
    if (cached && cached.title) {
      title = cached.title;
    } else {
      title = (anchor.textContent || "").trim();
      if ((!title || title.length < 4) && container) {
        const h = container.querySelector("h1,h2,h3,.clad__title,a");
        if (h) title = (h.textContent || "").trim();
      }
    }

    let image = "";
    if (cached && cached.image) {
      image = cached.image;
    } else if (container) {
      const img = container.querySelector("img");
      if (img) {
        image =
          img.getAttribute("src") ||
          img.getAttribute("data-src") ||
          img.getAttribute("data-lazy-src") ||
          "";
      }
    }

    let price = "-";
    if (cached && cached.price) {
      price = cached.price;
    } else if (container) {
      const txt = container.innerText || "";
      const incall = txt.match(/incall\s*£\s*\d+\/h/i);
      const pound = txt.match(/£\s*\d+\/h/i) || txt.match(/£\s*\d+/i);
      price = (incall && incall[0]) || (pound && pound[0]) || "-";
    }

    return {
      url: href,
      title: title || href,
      image: image || "",
      price: price || "-",
      fmin: (cached && cached.fmin) || "-",
      tmin: (cached && cached.tmin) || "-",
      hr: (cached && cached.hr) || "-",
      nationality: (cached && cached.nationality) || "-",
      age: (cached && cached.age) || "-"
    };
  }

  function parseAdvertiserAds(html, currentUrl, callback) {
    const temp = document.createElement("div");
    temp.innerHTML = html;

    chrome.storage.local.get([AD_META_KEY], function (res) {
      const adMetaCache = res[AD_META_KEY] || {};

      const anchors = Array.from(temp.querySelectorAll("a[href]")).filter((a) => {
        const href = cleanLink(a.href || a.getAttribute("href") || "");
        const text = (a.textContent || "").trim().toLowerCase();

        if (!href) return false;
        if (text === "log out" || text === "logout") return false;
        if (href.includes("/profile/")) return false;
        if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(href)) return false;

        return /\/\d{6,}$/.test(href);
      });

      const seen = new Set();
      const ads = [];

      anchors.forEach((a) => {
        const href = cleanLink(a.href || a.getAttribute("href") || "");
        if (!href) return;
        if (cleanLink(href) === cleanLink(currentUrl)) return;
        if (seen.has(href)) return;

        seen.add(href);

        const item = extractPreviewFromAdvertiserCard(a, adMetaCache);
        if (!item || !item.url) return;

        ads.push(item);
      });

      callback(ads);
    });
  }

  function fetchAdvertiserAds(advertiserId, advertiserUrl, currentUrl, callback) {
    if (!advertiserId || !advertiserUrl) {
      callback([]);
      return;
    }

    chrome.storage.local.get([ADVERTISER_CACHE_KEY], function (res) {
      const cache = res[ADVERTISER_CACHE_KEY] || {};
      const cached = cache[advertiserId];

      if (cached && cached.fetchedAt && Date.now() - cached.fetchedAt < 10 * 60 * 1000) {
        const filtered = (cached.ads || []).filter(
          (x) => cleanLink(x.url) !== cleanLink(currentUrl)
        );
        callback(filtered);
        return;
      }

      chrome.runtime.sendMessage({ action: "fetchHTML", url: advertiserUrl }, function (response) {
        if (!response || !response.html) {
          callback([]);
          return;
        }

        parseAdvertiserAds(response.html, currentUrl, function (ads) {
          cache[advertiserId] = { fetchedAt: Date.now(), ads };

          chrome.storage.local.set({ [ADVERTISER_CACHE_KEY]: cache }, function () {
            callback(ads);
          });
        });
      });
    });
  }

function createWhatsAppButton(rawDigits) {
  const btn = document.createElement("span");
attachFastTooltip(btn, "WhatsApp");

  btn.style.cursor = "pointer";
  btn.style.marginLeft = "6px";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.verticalAlign = "middle";

  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 32 32">
      <path fill="#25D366" d="M16 .4C7.3.4.4 7.3.4 16c0 2.8.7 5.4 2 7.7L0 32l8.5-2.2c2.2 1.2 4.7 1.9 7.5 1.9 8.7 0 15.6-6.9 15.6-15.6S24.7.4 16 .4z"/>
      <path fill="#fff" d="M24.1 19.3c-.4-.2-2.3-1.1-2.6-1.3-.4-.1-.6-.2-.9.2-.2.4-1 1.3-1.2 1.6-.2.2-.4.3-.8.1-.4-.2-1.6-.6-3-1.9-1.1-1-1.9-2.3-2.1-2.7-.2-.4 0-.6.2-.8.2-.2.4-.4.6-.7.2-.2.2-.4.4-.6.1-.2.1-.5 0-.7-.1-.2-.9-2.2-1.2-3-.3-.8-.6-.7-.9-.7h-.8c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.7 0 1.6 1.2 3.2 1.3 3.4.2.2 2.3 3.6 5.6 5 .8.3 1.4.5 1.9.7.8.2 1.6.2 2.2.1.7-.1 2.3-.9 2.6-1.8.3-.9.3-1.6.2-1.8-.1-.2-.3-.3-.7-.5z"/>
    </svg>
  `;

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

const message = prompt("Type WhatsApp message:", VS_WA_DEFAULT_MESSAGE);

if (!message || !message.trim()) return;

const encodedMessage = encodeURIComponent(message.trim());

window.open(`https://wa.me/${rawDigits}?text=${encodedMessage}`, "_blank");
  };

  return btn;
}

let vsBmcLastDismissed = 0;
let vsBmcEngagementTimerStarted = false;

const VS_BMC_COOLDOWN = 15 * 60 * 1000; // 15 minutes

const VS_CRYPTO_WALLETS = {
  BTC: "bc1qjzrmt6zrw7cg6m03vjxjauq48m3z8twmqefzdp",
  ETH: "0x3D49E807c18e0e1cd7f684c5122f26a872196d51",
  SOL: "5CGvcZ5fkCwUMMrQj9sgHESQ42Ne7TkfZyoCkK51mucp"
};

function makeQrUrl(coin, address) {
  return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&margin=10&data=${encodeURIComponent(address)}`;
}

function injectBuyMeCoffeeButton() {
  if (document.getElementById("vs-bmc-wrap")) return;
  if (Date.now() - vsBmcLastDismissed < VS_BMC_COOLDOWN) return;

  const wrap = document.createElement("div");
  wrap.id = "vs-bmc-wrap";

  wrap.style.position = "fixed";
  wrap.style.left = "16px";
  wrap.style.bottom = "16px";
  wrap.style.zIndex = "2147483647";
  wrap.style.fontFamily = "Arial, sans-serif";

  const collapsed = document.createElement("button");
  collapsed.type = "button";
  collapsed.textContent = "🔥 Support VS Tamer 🔥";

  collapsed.style.border = "0";
  collapsed.style.padding = "14px 22px";
  collapsed.style.borderRadius = "30px";
  collapsed.style.background = "#40DCA5";
  collapsed.style.color = "#fff";
  collapsed.style.fontSize = "12px";
  collapsed.style.fontWeight = "800";
  collapsed.style.boxShadow = "0 6px 18px rgba(0,0,0,0.3)";
  collapsed.style.cursor = "pointer";

  const panel = document.createElement("div");
  panel.style.display = "none";
  panel.style.background = "#111";
  panel.style.color = "#fff";
  panel.style.padding = "12px";
  panel.style.borderRadius = "14px";
  panel.style.boxShadow = "0 8px 24px rgba(0,0,0,0.35)";
  panel.style.width = "560px";

  panel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <div style="font-size:14px;font-weight:800;">🔥 Support VS Tamer 🔥</div>
      <span id="vs-bmc-close" style="
        width:20px;height:20px;border-radius:50%;
        background:rgba(255,255,255,0.18);
        display:flex;align-items:center;justify-content:center;
        cursor:pointer;font-size:12px;font-weight:900;color:#fff;
      ">✕</span>
    </div>

<div style="
  display:flex;
  flex-direction:row;
  gap:10px;
  align-items:flex-start;
  justify-content:space-between;
">
      ${Object.entries(VS_CRYPTO_WALLETS).map(([coin, address]) => `
        <div style="background:#fff;color:#111;border-radius:10px;padding:8px;text-align:center;">
          <div style="font-weight:800;font-size:13px;margin-bottom:6px;">${coin}</div>
          <img src="${makeQrUrl(coin, address)}" style="width:150px;height:150px;display:block;margin:0 auto 6px auto;">
          <button data-wallet="${address}" style="
            border:0;border-radius:7px;padding:5px 8px;
            font-size:11px;font-weight:700;cursor:pointer;
            background:#40DCA5;color:#fff;
          ">Copy</button>
        </div>
      `).join("")}
    </div>
  `;

  collapsed.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();
    collapsed.style.display = "none";
    panel.style.display = "block";
  };

  panel.addEventListener("click", function (e) {
    const btn = e.target.closest("button[data-wallet]");
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();

    const wallet = btn.getAttribute("data-wallet");

    navigator.clipboard.writeText(wallet).then(function () {
      const oldText = btn.textContent;
      btn.textContent = "Copied";
      setTimeout(() => {
        btn.textContent = oldText;
      }, 1200);
    });
  });

  wrap.appendChild(collapsed);
  wrap.appendChild(panel);
  document.documentElement.appendChild(wrap);

// Close panel when clicking outside

function closeSupportBox() {
  vsBmcLastDismissed = Date.now();
  vsBmcEngagementTimerStarted = false;

  wrap.remove();
  document.removeEventListener("click", handleOutsideClick);
}

function handleOutsideClick(e) {
  if (panel.style.display === "block" && !wrap.contains(e.target)) {
    closeSupportBox();
  }
}

document.addEventListener("click", handleOutsideClick);

document.getElementById("vs-bmc-close").onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  closeSupportBox();
};
}

function startBuyMeCoffeeAfterEngagement() {
  if (vsBmcEngagementTimerStarted) return;
  if (Date.now() - vsBmcLastDismissed < VS_BMC_COOLDOWN) return;

  vsBmcEngagementTimerStarted = true;

  setTimeout(function () {
    vsBmcEngagementTimerStarted = false;
    injectBuyMeCoffeeButton();
  }, 10000);
}

["click", "scroll", "keydown", "touchstart"].forEach(function (eventName) {
  window.addEventListener(
    eventName,
    startBuyMeCoffeeAfterEngagement,
    { passive: true }
  );
});

function createReverseImageButtons(imageUrl) {
  if (!imageUrl) return document.createTextNode("");

  const wrap = document.createElement("span");
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.gap = "5px";
  wrap.style.marginLeft = "8px";
  wrap.style.verticalAlign = "middle";

  const encoded = encodeURIComponent(imageUrl);

  const engines = [
    {
      title: "Google Lens",
      url: `https://lens.google.com/uploadbyurl?url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
          <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
          <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
          <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
          <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
          <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
          <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
          <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
          <circle cx="24" cy="24" r="8" fill="#4285F4"/>
          <circle cx="24" cy="24" r="4" fill="#fff"/>
        </svg>
      `
    },
    {
      title: "Yandex Image Search",
      url: `https://yandex.com/images/search?rpt=imageview&url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
          <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial, sans-serif" font-weight="700" fill="#fff">Y</text>
        </svg>
      `
    },
    {
      title: "TinEye",
      url: `https://tineye.com/search?url=${encoded}`,
      svg: `
        <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#111827"/>
          <circle cx="24" cy="24" r="11" fill="#fff"/>
          <circle cx="24" cy="24" r="6" fill="#2563EB"/>
          <circle cx="28" cy="20" r="2" fill="#fff"/>
        </svg>
      `
    }
  ];

  engines.forEach((engine) => {
    const btn = document.createElement("span");
    btn.innerHTML = engine.svg;
    btn.style.cursor = "pointer";
    btn.style.display = "inline-flex";
    btn.style.alignItems = "center";
    btn.style.justifyContent = "center";
    btn.style.width = "20px";
    btn.style.height = "20px";
    btn.style.verticalAlign = "middle";

    btn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      window.open(engine.url, "_blank");
    };

    wrap.appendChild(btn);
  });

  return wrap;
}

function createAngelButton() {
  const btn = document.createElement("span");
  btn.textContent = "✅";
attachFastTooltip(btn, "Verification Language");
  btn.style.marginLeft = "6px";
  btn.style.fontSize = "30px";
  btn.style.lineHeight = "30px";
  btn.style.verticalAlign = "middle";
  btn.style.cursor = "default";

  return btn;
}

function getCurrentAdvertImageUrl() {
  // 1. Find the main visible gallery/image area
  const gallery =
    document.querySelector(".kiwii-carousel") ||
    document.querySelector(".gallery") ||
    document.querySelector(".swiper") ||
    document.querySelector(".slick-slider") ||
    document.querySelector("main");

  if (!gallery) return "";

  const rect = gallery.getBoundingClientRect();

  // 2. Look at the centre of the gallery currently on screen
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;

  const elements = document.elementsFromPoint(x, y);

  // 3. Find the actual image currently visible at that point
  let img =
    elements.find((el) => el.tagName && el.tagName.toLowerCase() === "img") ||
    elements.map((el) => el.querySelector && el.querySelector("img")).find(Boolean);

  // 4. Fallback: largest visible image
  if (!img) {
    img = Array.from(document.querySelectorAll("img"))
      .filter((image) => {
        const r = image.getBoundingClientRect();
        return (
          r.width > 250 &&
          r.height > 250 &&
          r.left < window.innerWidth &&
          r.right > 0 &&
          r.top < window.innerHeight &&
          r.bottom > 0
        );
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return br.width * br.height - ar.width * ar.height;
      })[0];
  }

  if (!img) return "";

  let src =
    img.currentSrc ||
    img.getAttribute("src") ||
    img.getAttribute("data-src") ||
    img.getAttribute("data-lazy-src") ||
    "";

  if (!src || src.startsWith("data:")) return "";

  if (src.startsWith("/")) {
    src = new URL(src, location.origin).href;
  }

  return src;
}
function createReverseImageAdvertButtons() {
  const old = document.getElementById("vs-reverse-image-buttons");
  if (old) old.remove();

  const wrap = document.createElement("div");
  wrap.id = "vs-reverse-image-buttons";
  wrap.style.position = "fixed";
  wrap.style.top = "90px";
  wrap.style.right = "18px";
  wrap.style.zIndex = "999999";
  wrap.style.display = "flex";
  wrap.style.gap = "8px";
  wrap.style.alignItems = "center";
  wrap.style.padding = "8px";
  wrap.style.borderRadius = "10px";
  wrap.style.background = "rgba(255,255,255,0.96)";
  wrap.style.border = "1px solid rgba(0,0,0,0.15)";
  wrap.style.boxShadow = "0 4px 14px rgba(0,0,0,0.18)";

  const engines = [
    {
      title: "Google Lens",
      getUrl: (img) => `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
          <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
          <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
          <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
          <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
          <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
          <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
          <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
          <circle cx="24" cy="24" r="8" fill="#4285F4"/>
          <circle cx="24" cy="24" r="4" fill="#fff"/>
        </svg>
      `
    },
    {
      title: "Yandex Image Search",
      getUrl: (img) => `https://yandex.com/images/search?rpt=imageview&url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
          <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial" font-weight="700" fill="#fff">Y</text>
        </svg>
      `
    },
    {
      title: "TinEye",
      getUrl: (img) => `https://tineye.com/search?url=${encodeURIComponent(img)}`,
      svg: `
        <svg width="22" height="22" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
          <circle cx="24" cy="24" r="22" fill="#111827"/>
          <circle cx="24" cy="24" r="11" fill="#fff"/>
          <circle cx="24" cy="24" r="6" fill="#2563EB"/>
          <circle cx="28" cy="20" r="2" fill="#fff"/>
        </svg>
      `
    }
  ];

  engines.forEach((engine) => {
    const btn = document.createElement("span");
 attachFastTooltip(btn, engine.title);
    btn.innerHTML = engine.svg;
    btn.style.cursor = "pointer";
    btn.style.display = "inline-flex";
    btn.style.alignItems = "center";
    btn.style.justifyContent = "center";
    btn.style.width = "22px";
    btn.style.height = "22px";

    btn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      const currentImage = getCurrentAdvertImageUrl();

      if (!currentImage) {
        alert("No advert image found.");
        return;
      }

      window.open(engine.getUrl(currentImage), "_blank");
    };

    wrap.appendChild(btn);
  });

  document.body.appendChild(wrap);
}

  function createPhoneMatchElement() {
    const el = document.createElement("span");
    el.textContent = "☎️";
    el.style.cursor = "pointer";
    el.style.marginLeft = "2px";
    el.style.fontSize = "20px";
    el.style.lineHeight = "20px";
    el.style.verticalAlign = "middle";
    return el;
  }

  function createAdvertiserMatchElement() {
    const el = document.createElement("span");
    el.textContent = "🚺";
    el.style.cursor = "pointer";
    el.style.marginLeft = "2px";
    el.style.fontSize = "20px";
    el.style.lineHeight = "20px";
    el.style.verticalAlign = "middle";
    return el;
  }

  function removeExistingPreview() {
    const existing = document.getElementById("vs-preview-popup");
    if (existing) existing.remove();
  }

  function showPreviewPopup(e, item, accentEmoji) {
    removeExistingPreview();

    const popup = document.createElement("div");
    popup.id = "vs-preview-popup";
    popup.style.position = "fixed";
    popup.style.zIndex = "999999";
    popup.style.background = "#fff";
    popup.style.border = "1px solid #d9d9d9";
    popup.style.borderRadius = "10px";
    popup.style.boxShadow = "0 8px 24px rgba(0,0,0,0.22)";
    popup.style.padding = "10px";
    popup.style.width = "280px";
    popup.style.fontSize = "12px";
    popup.style.lineHeight = "1.35";
    popup.style.color = "#111";

    if (item.image) {
      const img = document.createElement("img");
      img.src = item.image;
      img.style.width = "100%";
      img.style.height = "160px";
      img.style.objectFit = "cover";
      img.style.borderRadius = "8px";
      img.style.display = "block";
      img.style.marginBottom = "8px";
      popup.appendChild(img);
    }

    const title = document.createElement("div");
    title.style.fontWeight = "700";
    title.style.fontSize = "13px";
    title.style.marginBottom = "6px";
    title.textContent = `${accentEmoji || ""} ${
      item.title && item.title !== item.url ? item.title : "Advert"
    }`.trim();

    const price = document.createElement("div");
    price.style.color = "#0a7a0a";
    price.style.fontWeight = "700";
    price.style.marginBottom = "6px";
    price.textContent = item.price || "-";

    const rates = document.createElement("div");
    rates.style.color = "#1f4ed8";
    rates.style.marginBottom = "4px";
    rates.textContent = `15m-${item.fmin || "-"} | 30m-${item.tmin || "-"} | 1hr-${item.hr || "-"}`;

    const meta = document.createElement("div");
    meta.style.color = "#444";
    meta.style.marginBottom = "6px";
    meta.textContent = `Nationality: ${item.nationality || "-"} | Age: ${item.age || "-"}`;

    popup.appendChild(title);
    popup.appendChild(price);
    popup.appendChild(rates);
    popup.appendChild(meta);

    document.body.appendChild(popup);

    let left = e.clientX + 12;
    let top = e.clientY + 12;

    const rect = popup.getBoundingClientRect();

    if (left + rect.width > window.innerWidth - 10) {
      left = window.innerWidth - rect.width - 10;
    }
    if (top + rect.height > window.innerHeight - 10) {
      top = window.innerHeight - rect.height - 10;
    }

    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;
  }

  function renderPhoneMatches(container, links, currentUrl) {
    if (!container) return;
    container.innerHTML = "Same phone number: ";

    const currentClean = cleanLink(currentUrl);
    const otherLinks = (links || []).filter((item) => cleanLink(item.url) !== currentClean);

    if (otherLinks.length === 0) {
      container.appendChild(document.createTextNode("0"));
      return;
    }

    otherLinks.forEach((item) => {
      const el = createPhoneMatchElement();
      el.title = item.title || item.url;

      el.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.open(item.url, "_blank");
      };

      el.onmouseenter = function (e) {
        showPreviewPopup(e, item, "☎️");
      };

      el.onmousemove = function (e) {
        showPreviewPopup(e, item, "☎️");
      };

      el.onmouseleave = function () {
        removeExistingPreview();
      };

      container.appendChild(el);
    });
  }

  function renderAdvertiserMatches(container, ads) {
    if (!container) return;
    container.innerHTML = "Other Adverts: ";

    if (!ads || ads.length === 0) {
      container.appendChild(document.createTextNode("0"));
      return;
    }

    ads.forEach((item) => {
      const el = createAdvertiserMatchElement();
      el.title = item.title || item.url;

      el.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.open(item.url, "_blank");
      };

      el.onmouseenter = function (e) {
        showPreviewPopup(e, item, "🚺");
      };

      el.onmousemove = function (e) {
        showPreviewPopup(e, item, "🚺");
      };

      el.onmouseleave = function () {
        removeExistingPreview();
      };

      container.appendChild(el);
    });
  }

  function addSeenBox(card, metaEntry) {
    const old = card.querySelector(".vs-seen-box");
    if (old) old.remove();

    card.style.position = "relative";

    const box = document.createElement("div");
    box.className = "vs-seen-box";
    box.style.position = "absolute";
    box.style.top = "50px";
    box.style.right = "12px";
    box.style.zIndex = "20";
    box.style.background = "rgba(255,255,255,0.96)";
    box.style.border = "1px solid rgba(0,0,0,0.15)";
    box.style.borderRadius = "8px";
    box.style.padding = "5px 7px";
    box.style.fontSize = "10px";
    box.style.lineHeight = "1.35";
    box.style.textAlign = "right";
    box.style.boxShadow = "0 2px 6px rgba(0,0,0,0.10)";
    box.style.maxWidth = "145px";

    const firstSeen = metaEntry && metaEntry.firstSeen ? formatDateTime(metaEntry.firstSeen) : "-";
    const lastSeen = metaEntry && metaEntry.lastSeen ? formatDateTime(metaEntry.lastSeen) : "-";

    box.innerHTML = `
      <div><strong>First:</strong> ${firstSeen}</div>
      <div><strong>Last:</strong> ${lastSeen}</div>
    `;

    card.appendChild(box);
  }

  function applyAdvertiserClusterStyle(card, advertiserId, advertiserAds) {
    const oldTag = card.querySelector(".vs-cluster-tag");
    if (oldTag) oldTag.remove();

    card.style.borderLeft = "";
    card.style.backgroundColor = "";
  }

function ensureWhatsAppBulkBar() {
  let bar = document.getElementById("vs-wa-bulk-bar");

  if (!bar) {
    bar = document.createElement("div");
    bar.id = "vs-wa-bulk-bar";

    bar.style.position = "fixed";
    bar.style.bottom = "18px";
    bar.style.right = "18px";
    bar.style.zIndex = "999999";
    bar.style.background = "#25D366";
    bar.style.color = "#fff";
    bar.style.padding = "12px";
    bar.style.borderRadius = "12px";
    bar.style.boxShadow = "0 6px 18px rgba(0,0,0,0.25)";
    bar.style.display = "none";
    bar.style.flexDirection = "column";
    bar.style.gap = "8px";
    bar.style.fontSize = "13px";
    bar.style.fontWeight = "700";
    bar.style.width = "320px";

    bar.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
        <span id="vs-wa-count">0 selected</span>
        <button id="vs-wa-clear" type="button" style="border:0;border-radius:8px;padding:7px 9px;cursor:pointer;font-weight:800;">
          Clear
        </button>
      </div>

     <textarea id="vs-wa-message" placeholder="Type bulk WhatsApp message..." style="
  width:100%;
  height:44px;
  min-height:44px;
  resize:vertical;
        border:0;
        border-radius:8px;
        padding:8px;
        font-size:13px;
        box-sizing:border-box;
        font-family:Arial, sans-serif;
      "></textarea>

      <button id="vs-wa-open" type="button" style="border:0;border-radius:8px;padding:9px 10px;cursor:pointer;font-weight:800;">
        Bulk-send WhatsApp
      </button>
    `;

    document.body.appendChild(bar);

    const msgBox = document.getElementById("vs-wa-message");
    msgBox.value = VS_WA_DEFAULT_MESSAGE;

    document.getElementById("vs-wa-open").onclick = function () {
      const selected = Object.values(VS_WA_SELECTED).filter(Boolean);
      const message = (msgBox.value || "").trim();

      if (!message) {
        alert("Please type a message first.");
        return;
      }

      selected.forEach((item, idx) => {
        setTimeout(() => {
          window.open(
            `https://wa.me/${item.rawDigits}?text=${encodeURIComponent(message)}`,
            "_blank"
          );
        }, idx * 650);
      });
    };

    document.getElementById("vs-wa-clear").onclick = function () {
      Object.keys(VS_WA_SELECTED).forEach((key) => delete VS_WA_SELECTED[key]);

      document.querySelectorAll(".vs-wa-select").forEach((cb) => {
        cb.checked = false;
      });

      updateWhatsAppBulkBar();
    };
  }

  updateWhatsAppBulkBar();
}
function updateWhatsAppBulkBar() {
  const bar = document.getElementById("vs-wa-bulk-bar");
  const countEl = document.getElementById("vs-wa-count");
  if (!bar || !countEl) return;

  const count = Object.values(VS_WA_SELECTED).filter(Boolean).length;
  countEl.textContent = `${count} selected`;
  bar.style.display = count > 0 ? "flex" : "none";
}

function addWhatsAppSelectBox(card, advertKey, rawDigits, title) {
  if (!card || !rawDigits) return;

  const existing = card.querySelector(".vs-wa-select-wrap");
  if (existing) existing.remove();

  const wrap = document.createElement("label");
  wrap.className = "vs-wa-select-wrap";

wrap.style.display = "inline-flex";
wrap.style.alignItems = "center";
wrap.style.justifyContent = "center";
wrap.style.gap = "4px";

wrap.style.padding = "4px 8px";
wrap.style.height = "26px";
wrap.style.lineHeight = "16px";

wrap.style.borderRadius = "4px";
wrap.style.border = "1px solid #34a853";
wrap.style.background = "#e6f4ea";
wrap.style.color = "#1e7e34";

wrap.style.fontSize = "12px";
wrap.style.fontWeight = "600";

wrap.style.cursor = "pointer";
wrap.style.width = "fit-content";
wrap.style.marginLeft = "6px";
wrap.style.verticalAlign = "middle";
wrap.style.boxSizing = "border-box";

wrap.onmouseenter = () => wrap.style.background = "#d2ead8";
wrap.onmouseleave = () => wrap.style.background = "#e6f4ea";

  const cb = document.createElement("input");
  cb.type = "checkbox";
  cb.className = "vs-wa-select";
  cb.checked = !!VS_WA_SELECTED[advertKey];
  cb.style.margin = "0";
  cb.style.width = "13px";
  cb.style.height = "13px";
  cb.style.accentColor = "#777";
  cb.style.cursor = "pointer";

  cb.onchange = function (e) {
    e.stopPropagation();

    if (cb.checked) {
      VS_WA_SELECTED[advertKey] = { rawDigits, title: title || "Advert" };
    } else {
      delete VS_WA_SELECTED[advertKey];
    }

    ensureWhatsAppBulkBar();
  };

  wrap.appendChild(cb);
  wrap.appendChild(document.createTextNode("Bulk-send WA"));

  const locationLine =
    card.querySelector(".clad__location") ||
    card.querySelector("[class*='location']") ||
    Array.from(card.querySelectorAll("span, p, div"))
      .filter((el) => {
        const txt = (el.innerText || "").trim();
        const r = el.getBoundingClientRect();
        return (
          txt &&
          txt.length < 120 &&
          r.width > 40 &&
          /london|manchester|birmingham|north|south|east|west|central/i.test(txt)
        );
      })
      .sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top)[0];

if (locationLine) {
  locationLine.style.display = "inline-flex";
  locationLine.style.alignItems = "center";
  locationLine.appendChild(wrap);
} else {
  const anchor =
    card.querySelector(".clad__title") ||
    card.querySelector("h2") ||
    card.querySelector("h3") ||
    card.querySelector("a.clad__ad_link");

  if (anchor && anchor.parentElement) {
    anchor.parentElement.appendChild(wrap);
  } else {
    card.appendChild(wrap);
  }
}

  ensureWhatsAppBulkBar();
}

function extractRealAdvertTitleFromHtml(html, url) {
  const doc = new DOMParser().parseFromString(html, "text/html");

  let title =
    doc.querySelector("h1")?.textContent ||
    doc.querySelector('[data-automation="adTitle"]')?.textContent ||
    doc.querySelector(".kiwii-font-xlarge")?.textContent ||
    doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ||
    doc.querySelector("title")?.textContent ||
    "";

  title = title
    .replace(/18\+\s*id\s*verified/gi, "")
    .replace(/verified/gi, "")
    .replace(/\|\s*vivastreet.*$/i, "")
    .replace(/-\s*vivastreet.*$/i, "")
    .replace(/\s+/g, " ")
    .trim();

  if (title) return title;

  try {
    const parts = new URL(url).pathname.split("/").filter(Boolean);
    const slug = parts[parts.length - 2] || "";

    const fromSlug = slug
      .replace(/[-_]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    return fromSlug ? titleCase(fromSlug) : "Advert";
  } catch (e) {
    return "Advert";
  }
}

  function processAd(link, response, filters) {
    try {
      if (!response || !response.html) return;

      const card = getListingCardFromLink(link);
      if (!card) return;

      const tempElement = document.createElement("div");
      tempElement.innerHTML = response.html;

let title = extractRealAdvertTitleFromHtml(response.html, link.href);

      let nationality = "-";
      let age = "-";

      const rows = tempElement.querySelectorAll("tr");
      rows.forEach((row) => {
        const cells = row.querySelectorAll("td");
        if (cells.length < 2) return;

        const label = cells[0].innerText.trim();
        const value = cells[1].innerText.trim();

        if (label === "Nationality") nationality = value;
        if (label === "Age") age = value.replace(/\s*years old/i, "").trim();
      });

      const phoneNumberElement = tempElement.querySelector(".phone_link");
      const rawPhoneNumber = phoneNumberElement
        ? phoneNumberElement.getAttribute("data-phone-number")
        : "-";

      const rawWhatsappDigits = getRawWhatsappDigits(rawPhoneNumber);
      const displayPhone = formatDisplayPhone(rawPhoneNumber);
      const area = extractAreaFromUrl(link.href);

      const fmin = tempElement.querySelector('[data-automation="tdRate15minutesIncall"]')?.innerText.trim() || "-";
      const tmin = tempElement.querySelector('[data-automation="tdRate30minutesIncall"]')?.innerText.trim() || "-";
      const hr = tempElement.querySelector('[data-automation="tdRate1hourIncall"]')?.innerText.trim() || "-";

      let price = "-";
      const priceElement =
        tempElement.querySelector(".price") ||
        tempElement.querySelector('[data-automation="price"]') ||
        tempElement.querySelector(".ad-price") ||
        tempElement.querySelector(".kiwii-price");

      if (priceElement) price = priceElement.innerText.trim();

      const advertDescriptionText = getDescriptionTextFromHtml(response.html);
      const showAngel = hasVideoKeyword(advertDescriptionText);
      const image = getBestImage(tempElement);
      const advertiserInfo = extractAdvertiserInfo(tempElement);

      const adData = {
        title,
        area,
        rawWhatsappDigits,
        displayPhone,
        price,
        image,
        fmin,
        tmin,
        hr,
        nationality,
        age,
        advertiserId: advertiserInfo ? advertiserInfo.id : "",
        advertiserUrl: advertiserInfo ? advertiserInfo.url : ""
      };

      upsertAdMeta(link.href, adData, function (metaEntry) {
        addSeenBox(card, metaEntry);
      });

      const filterAd = { fmin, tmin, hr, nationality };

      if (!passesFilters(filterAd, filters)) {
        card.style.display = "none";
        return;
      } else {
        card.style.display = "";
      }

      const oldData = card.querySelector(".newData");
      if (oldData) oldData.remove();

      const anchor =
        card.querySelector(".clad__title") ||
        card.querySelector("h2") ||
        card.querySelector("h3") ||
        link;

      const newDiv = document.createElement("div");
      newDiv.className = "newData";

      const nationalityFlag = getNationalityFlag(nationality);
      const nationalityDisplay = nationalityFlag ? `${nationalityFlag} ${nationality}` : nationality;

      newDiv.innerHTML = `
        <p class="vs-price-line" style="color:blue;margin:4px 0;font-weight:600;">
          15m-${fmin} || 30m-${tmin} || 1hr-${hr}
        </p>

        <p class="vs-number-line" style="color:green;font-size:1.05em;font-weight:600;margin:4px 0;">
          Nationality: ${nationalityDisplay} || Number: ${displayPhone}
        </p>

        <p class="vs-advertiser-line" style="margin:4px 0 0 0;font-weight:600;">
          Other Adverts: 0
        </p>

        <p class="vs-phone-line" style="margin:2px 0 0 0;font-weight:600;">
          Same phone number: 0
        </p>
      `;

      insertAfter(newDiv, anchor);

const priceLine = newDiv.querySelector(".vs-price-line");

if (showAngel && priceLine) {
  priceLine.appendChild(createAngelButton());
}

      const advertiserLine = newDiv.querySelector(".vs-advertiser-line");
      const phoneLine = newDiv.querySelector(".vs-phone-line");
      const numberLine = newDiv.querySelector(".vs-number-line");

if (rawWhatsappDigits) {
  addWhatsAppSelectBox(card, cleanLink(link.href), rawWhatsappDigits, title);

  numberLine.appendChild(createWhatsAppButton(rawWhatsappDigits));

        storeNumber(rawWhatsappDigits, link.href, adData, function (phoneMatches) {
          const sorted = [...phoneMatches].sort((a, b) => b.ts - a.ts);
          renderPhoneMatches(phoneLine, sorted, link.href);
        });
      } else {
        phoneLine.textContent = "Same phone number: 0";
      }

      if (advertiserInfo && advertiserInfo.id && advertiserInfo.url) {
        fetchAdvertiserAds(advertiserInfo.id, advertiserInfo.url, link.href, function (ads) {
          applyAdvertiserClusterStyle(card, advertiserInfo.id, ads);
          renderAdvertiserMatches(advertiserLine, ads);
        });
      } else {
        advertiserLine.textContent = "Other Adverts: 0";
        applyAdvertiserClusterStyle(card, null, []);
      }
    } catch (e) {
      console.log("VS Tamer error:", e);
    }
  }

function processListingsPage() {
  console.log("VS Tamer: processListingsPage running");

  getFilters(function (filters) {
    const links = Array.from(
      document.querySelectorAll(
        "a.clad__ad_link, a[href*='/escort/'], a[href*='/massage/'], a[href*='/escorts/']"
      )
    ).filter((link) => {
      if (!link || !link.href) return false;
      if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(link.href)) return false;
      if (!/\/\d{6,}/.test(link.href)) return false;
      return true;
    });

    console.log("VS Tamer: listing links found:", links.length);

    links.forEach((link) => {
      chrome.runtime.sendMessage(
        { action: "fetchHTML", url: link.href },
        function (response) {
          if (chrome.runtime.lastError) {
            console.log("VS Tamer fetchHTML error:", chrome.runtime.lastError.message);
            return;
          }

          processAd(link, response, filters);
        }
      );
    });
  });
}

function isFavouritesPage() {
  const path = window.location.pathname.toLowerCase();

  return (
    path === "/favourites" ||
    path === "/favorites" ||
    path.includes("/favourites") ||
    path.includes("/favorites")
  );
}

  function getFavouriteCards() {
    const links = Array.from(document.querySelectorAll("a.clad__ad_link"));
    const cards = [];

    links.forEach((link, idx) => {
      const card = getListingCardFromLink(link);
      if (!card) return;

      if (!cards.find((x) => x.card === card)) {
        cards.push({
          card,
          link,
          key: cleanLink(link.href),
          originalIndex: idx
        });
      }
    });

    return cards;
  }

  function getCardsParent(cards) {
    if (!cards.length) return null;
    return cards[0].card.parentElement;
  }

  function mapLegacyGroup(groupName) {
    if (groupName === "Targets") return "Live";
    if (groupName === "Shortlist") return "Watchlist";
    if (groupName === "Try Later") return "Watchlist";
    if (groupName === "Monitor") return "Carousel";
    return groupName;
  }

  function ensureFavouriteDefaults(callback) {
    const cards = getFavouriteCards();

    chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
      let data = res[FAV_STORAGE_KEY];

      if (!data || Object.keys(data).length === 0) {
        chrome.storage.sync.get([FAV_STORAGE_SYNC_KEY], function (syncRes) {
          const backup = syncRes[FAV_STORAGE_SYNC_KEY];

          if (backup && Object.keys(backup).length > 0) {
            chrome.storage.local.set({ [FAV_STORAGE_KEY]: backup }, function () {
              ensureFavouriteDefaults(callback);
            });
            return;
          }

          continueInit({});
        });
        return;
      }

      continueInit(data);

      function continueInit(data) {
        let changed = false;

        cards.forEach((item, index) => {
          if (!data[item.key]) {
            data[item.key] = {
              group: "Watchlist",
              order: index + 1
            };
            changed = true;
          } else {
            data[item.key].group = mapLegacyGroup(data[item.key].group);

            if (!data[item.key].group || !FAV_GROUPS.includes(data[item.key].group)) {
              data[item.key].group = "Watchlist";
              changed = true;
            }

            if (typeof data[item.key].order !== "number") {
              data[item.key].order = index + 1;
              changed = true;
            }
          }
        });

        if (changed) {
          saveFavourites(data, function () {
            callback(data);
          });
        } else {
          callback(data);
        }
      }
    });
  }

  function normaliseGroupOrders(data) {
    FAV_GROUPS.forEach((groupName) => {
      const entries = Object.entries(data)
        .filter(([_, meta]) => mapLegacyGroup(meta.group) === groupName)
        .sort((a, b) => (a[1].order || 999999) - (b[1].order || 999999));

      entries.forEach(([key, meta], idx) => {
        meta.group = mapLegacyGroup(meta.group);
        meta.order = idx + 1;
        data[key] = meta;
      });
    });

    return data;
  }

  function reorderFavouritesDom(data) {
    const cards = getFavouriteCards();
    const parent = getCardsParent(cards);
    if (!parent) return;

    const grouped = cards.map((item) => {
      const meta = data[item.key] || { group: "Watchlist", order: 999999 };
      const groupName = mapLegacyGroup(meta.group);
      const groupRank = FAV_GROUPS.indexOf(groupName);

      return {
        ...item,
        group: groupName || "Watchlist",
        order: typeof meta.order === "number" ? meta.order : 999999,
        groupRank: groupRank === -1 ? 999 : groupRank
      };
    });

    grouped.sort((a, b) => {
      if (a.groupRank !== b.groupRank) return a.groupRank - b.groupRank;
      if (a.order !== b.order) return a.order - b.order;
      return a.originalIndex - b.originalIndex;
    });

    grouped.forEach((item) => parent.appendChild(item.card));
  }

  function applyGroupCardColours(data) {
    const cards = getFavouriteCards();

    cards.forEach((item) => {
      const meta = data[item.key] || { group: "Watchlist" };
      const group = mapLegacyGroup(meta.group) || "Watchlist";
      const colours = getGroupColours(group);

      item.card.style.backgroundColor = colours.card;
      item.card.style.borderRadius = "8px";
      item.card.style.outline = `1px solid ${colours.border}`;
      item.card.style.outlineOffset = "-1px";
    });
  }

  function insertGroupHeaders(data) {
    document.querySelectorAll(".vs-fav-group-header").forEach((el) => el.remove());

    const cards = getFavouriteCards();
    const seen = {};

    cards.forEach((item) => {
      const meta = data[item.key] || { group: "Watchlist" };
      const group = mapLegacyGroup(meta.group) || "Watchlist";

      if (seen[group]) return;
      seen[group] = true;

      const header = document.createElement("div");
      const colours = getGroupColours(group);

      header.className = "vs-fav-group-header";
      header.textContent = group;
      header.style.fontSize = "18px";
      header.style.fontWeight = "700";
      header.style.margin = "16px 0 8px 0";
      header.style.padding = "8px 10px";
      header.style.borderRadius = "8px";
      header.style.background = colours.header;

      item.card.parentElement.insertBefore(header, item.card);
    });
  }
function formatPhoneForWhatsAppCopy(meta, cardText) {
  let raw = meta.rawWhatsappDigits || "";

  if (!raw) {
    const match = cardText.match(/Number:\s*([^\n\r]+)/i);
    raw = match ? match[1].replace(/\D/g, "") : "";
  }

  if (!raw) return "-";

  if (raw.startsWith("0")) {
    raw = "44" + raw.substring(1);
  }

  if (raw.startsWith("44") && raw.length >= 12) {
    return `+44 ${raw.substring(2, 6)} ${raw.substring(6)}`;
  }

  return `+${raw}`;
}

function saveFavouriteNote(itemKey, note, callback) {
  chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
    let data = res[FAV_STORAGE_KEY] || {};
    data = normaliseGroupOrders(data);

    if (!data[itemKey]) {
      data[itemKey] = {
        group: "Watchlist",
        order: 999999
      };
    }

    data[itemKey].note = note || "";

    saveFavourites(data, function () {
      if (callback) callback();
    });
  });
}

function getLiveListItemText(item, metaCache, favData) {
  const meta = metaCache[item.key] || {};
  const favMeta = favData[item.key] || {};
  const cardText = item.card.innerText || "";

  const titleFromCard =
    item.card.querySelector(".clad__title")?.innerText?.trim() ||
    item.card.querySelector("h2")?.innerText?.trim() ||
    item.card.querySelector("h3")?.innerText?.trim() ||
    "";

  let rawTitle = meta.title || titleFromCard || "Advert";

  rawTitle = rawTitle
    .replace(/18\+\s*id\s*verified/gi, "")
    .replace(/verified/gi, "")
    .replace(/\s+/g, " ")
    .trim();

  const title = rawTitle || "Advert";

  const nationality = meta.nationality || "";
  const flag = getNationalityFlag(nationality);

  const area = meta.area || extractAreaFromUrl(item.link.href);
  const price15 = meta.fmin || "-";
  const phone = formatPhoneForWhatsAppCopy(meta, cardText);
  const note = (favMeta.note || "").trim();

  let line = `${title}`;

  if (flag) {
    line += ` — ${flag}`;
  }

  line += ` - ${area} - ${price15} — ${phone}`;

  if (note) {
    line += ` - ${note}`;
  }

  return line;
}
  function createCopyLiveListButton(data) {
    const old = document.querySelector("#vs-copy-live-list-wrap");
    if (old) old.remove();

    const cards = getFavouriteCards();
    if (!cards.length) return;

    const parent = getCardsParent(cards);
    if (!parent) return;

    const wrap = document.createElement("div");
    wrap.id = "vs-copy-live-list-wrap";
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.gap = "8px";
    wrap.style.margin = "10px 0 14px 0";
    wrap.style.padding = "10px";
    wrap.style.borderRadius = "10px";
    wrap.style.background = "rgba(255,255,255,0.96)";
    wrap.style.border = "1px solid rgba(0,0,0,0.12)";
    wrap.style.boxShadow = "0 2px 8px rgba(0,0,0,0.06)";

    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "Copy Live List";
    btn.style.padding = "8px 12px";
    btn.style.borderRadius = "8px";
    btn.style.border = "0";
    btn.style.cursor = "pointer";
    btn.style.fontWeight = "700";
    btn.style.background = "#25D366";
    btn.style.color = "#fff";

    const status = document.createElement("span");
    status.textContent = "";
    status.style.fontSize = "12px";
    status.style.color = "#555";

btn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  chrome.storage.local.get([AD_META_KEY, FAV_STORAGE_KEY], function (res) {
    const metaCache = res[AD_META_KEY] || {};
    const favData = normaliseGroupOrders(res[FAV_STORAGE_KEY] || {});

    const liveCards = getFavouriteCards()
      .filter((item) => {
        const meta = favData[item.key] || {};
        return mapLegacyGroup(meta.group) === "Live";
      })
      .sort((a, b) => {
        const am = favData[a.key] || {};
        const bm = favData[b.key] || {};
        return (am.order || 999999) - (bm.order || 999999);
      });

    if (!liveCards.length) {
      status.textContent = "No Live adverts found";
      return;
    }

    status.textContent = "Fetching headlines...";

    let pending = liveCards.length;

    liveCards.forEach((item) => {
      chrome.runtime.sendMessage(
        { action: "fetchHTML", url: item.link.href },
        function (response) {
          if (chrome.runtime.lastError) {
            console.log("VS Copy Live title fetch error:", chrome.runtime.lastError.message);
            pendingDone();
            return;
          }

          if (response && response.html) {
            const temp = document.createElement("div");
            temp.innerHTML = response.html;

            const title = extractRealAdvertTitleFromHtml(response.html, item.link.href);

            if (title && title !== "Advert") {
              metaCache[item.key] = metaCache[item.key] || {};
              metaCache[item.key].title = title;

              upsertAdMeta(item.link.href, { title });
            }
          }

          pendingDone();
        }
      );
    });

    function pendingDone() {
      pending -= 1;
      if (pending > 0) return;

      const lines = liveCards.map((item, idx) => {
        return `${idx + 1}. ${getLiveListItemText(item, metaCache, favData)}`;
      });

      const message = `Live List\n\n${lines.join("\n")}`;

      function markCopied() {
        status.textContent = `Copied ${liveCards.length} advert${liveCards.length === 1 ? "" : "s"}`;
        setTimeout(() => {
          status.textContent = "";
        }, 2500);
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(message).then(markCopied).catch(() => {
          fallbackCopyText(message);
          markCopied();
        });
      } else {
        fallbackCopyText(message);
        markCopied();
      }
    }
  });
};
    wrap.appendChild(btn);
    wrap.appendChild(status);

    const firstHeaderOrCard = parent.querySelector(".vs-fav-group-header") || cards[0].card;
    parent.insertBefore(wrap, firstHeaderOrCard);
  }

  function fallbackCopyText(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    ta.style.top = "-9999px";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();

    try {
      document.execCommand("copy");
    } catch (e) {}

    ta.remove();
  }

  function moveItemWithinGroup(itemKey, direction) {
    chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
      let data = res[FAV_STORAGE_KEY] || {};
      data = normaliseGroupOrders(data);

      const current = data[itemKey];
      if (!current) return;

      const currentGroup = mapLegacyGroup(current.group);

      const sameGroup = Object.entries(data)
        .filter(([_, meta]) => mapLegacyGroup(meta.group) === currentGroup)
        .sort((a, b) => a[1].order - b[1].order);

      const idx = sameGroup.findIndex(([key]) => key === itemKey);
      if (idx === -1) return;

      const swapIdx = direction === "up" ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= sameGroup.length) return;

      const otherKey = sameGroup[swapIdx][0];
      const currentOrder = data[itemKey].order;
      data[itemKey].order = data[otherKey].order;
      data[otherKey].order = currentOrder;

      data = normaliseGroupOrders(data);

      saveFavourites(data, function () {
        favUiInteracting = false;
        applyFavouriteCustomisation();
      });
    });
  }

function forceFavouriteRedraw(data, scrollYToRestore) {
  favUiInteracting = false;
  favApplying = false;

  data = normaliseGroupOrders(data);

  reorderFavouritesDom(data);
  insertGroupHeaders(data);
  applyGroupCardColours(data);
  injectFavouriteControls(data);
  createCopyLiveListButton(data);

  if (typeof scrollYToRestore === "number") {
    window.scrollTo(0, scrollYToRestore);
  }
}

function changeItemGroup(itemKey, newGroup, scrollYToRestore) {
  chrome.storage.local.get([FAV_STORAGE_KEY], function (res) {
    let data = res[FAV_STORAGE_KEY] || {};
    data = normaliseGroupOrders(data);

    if (!data[itemKey]) {
      data[itemKey] = { group: newGroup, order: 999999 };
    }

    data[itemKey].group = newGroup;

    const maxOrderInGroup = Math.max(
      0,
      ...Object.values(data)
        .filter((meta) => mapLegacyGroup(meta.group) === newGroup)
        .map((meta) => meta.order || 0)
    );

    data[itemKey].order = maxOrderInGroup + 1;
    data = normaliseGroupOrders(data);

    saveFavourites(data, function () {
      forceFavouriteRedraw(data, scrollYToRestore);
    });
  });
}

function getReverseImageCheckKey(engineName, imageUrl) {
  return `${cleanLink(location.href)}|${engineName}|${imageUrl}`;
}

function loadReverseImageCheck(engineName, imageUrl, marker) {
  const key = getReverseImageCheckKey(engineName, imageUrl);

  chrome.storage.local.get([IMAGE_CHECK_KEY], function (res) {
    const data = res[IMAGE_CHECK_KEY] || {};
    marker.textContent = data[key] ? "🚮" : "⬜";
  });
}

function toggleReverseImageCheck(engineName, imageUrl, marker) {
  const key = getReverseImageCheckKey(engineName, imageUrl);

  chrome.storage.local.get([IMAGE_CHECK_KEY], function (res) {
    const data = res[IMAGE_CHECK_KEY] || {};

    data[key] = !data[key];

    chrome.storage.local.set({ [IMAGE_CHECK_KEY]: data }, function () {
      marker.textContent = data[key] ? "🚮" : "⬜";
    });
  });
}
function injectReverseImageTopRight() {
  if (!isAdvertPage()) return;

  const old = document.getElementById("vs-reverse-image-buttons-inline");
  if (old) old.remove();

  const heart =
    document.querySelector('button[aria-label*="fav" i]') ||
    document.querySelector('button[title*="fav" i]') ||
    Array.from(document.querySelectorAll("button")).find((btn) =>
      /fav|save|heart|shortlist/i.test(btn.innerText || btn.getAttribute("aria-label") || btn.getAttribute("title") || "")
    ) ||
    document.querySelector("button svg")?.closest("button");

  if (!heart || !heart.parentElement) {
    console.log("VS: heart not found");
    return;
  }

  const wrap = document.createElement("span");
  wrap.id = "vs-reverse-image-buttons-inline";
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.justifyContent = "flex-end";
  wrap.style.gap = "6px";
  wrap.style.marginRight = "8px";
  wrap.style.verticalAlign = "middle";

  const engines = [
    {
      title: "G-Lens",
      getUrl: (img) => `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="6" width="14" height="6" rx="3" fill="#4285F4"/>
        <rect x="6" y="6" width="6" height="14" rx="3" fill="#4285F4"/>
        <rect x="28" y="6" width="14" height="6" rx="3" fill="#EA4335"/>
        <rect x="36" y="6" width="6" height="14" rx="3" fill="#EA4335"/>
        <rect x="6" y="28" width="6" height="14" rx="3" fill="#34A853"/>
        <rect x="6" y="36" width="14" height="6" rx="3" fill="#34A853"/>
        <rect x="36" y="28" width="6" height="14" rx="3" fill="#FBBC05"/>
        <rect x="28" y="36" width="14" height="6" rx="3" fill="#FBBC05"/>
        <circle cx="24" cy="24" r="8" fill="#4285F4"/>
        <circle cx="24" cy="24" r="4" fill="#fff"/>
      </svg>`
    },
    {
      title: "Yandex",
      getUrl: (img) => `https://yandex.com/images/search?rpt=imageview&url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="22" fill="#FC3F1D"/>
        <text x="24" y="32" text-anchor="middle" font-size="26" font-family="Arial" font-weight="700" fill="#fff">Y</text>
      </svg>`
    },
    {
      title: "TinEye",
      getUrl: (img) => `https://tineye.com/search?url=${encodeURIComponent(img)}`,
      svg: `<svg width="36" height="36" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="22" fill="#111827"/>
        <circle cx="24" cy="24" r="11" fill="#fff"/>
        <circle cx="24" cy="24" r="6" fill="#2563EB"/>
        <circle cx="28" cy="20" r="2" fill="#fff"/>
      </svg>`
    }
  ];

engines.forEach((engine) => {
  const box = document.createElement("span");
  box.style.display = "inline-flex";
  box.style.flexDirection = "row";
  box.style.alignItems = "center";
  box.style.justifyContent = "center";
  box.style.gap = "4px";

  const btn = document.createElement("span");
btn.style.position = "relative";
attachFastTooltip(btn, engine.title);
  btn.innerHTML = engine.svg;
  btn.style.cursor = "pointer";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.justifyContent = "center";
  btn.style.width = "28px";
  btn.style.height = "28px";

  const marker = document.createElement("span");
attachFastTooltip(marker, `Click if match found for ${engine.title}`);
  marker.textContent = "⬜";
  marker.style.cursor = "pointer";
  marker.style.fontSize = "28px";
marker.style.lineHeight = "28px";
marker.style.height = "28px";
marker.style.display = "inline-flex";
marker.style.alignItems = "center";
marker.style.justifyContent = "center";
marker.style.marginLeft = "2px";

  btn.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    const img = getCurrentAdvertImageUrl();
    if (!img) return;

    window.open(engine.getUrl(img), "_blank");
  };

  marker.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();

    const img = getCurrentAdvertImageUrl();
    if (!img) return;

    toggleReverseImageCheck(engine.title, img, marker);
  };

  const currentImg = getCurrentAdvertImageUrl();
  if (currentImg) {
    loadReverseImageCheck(engine.title, currentImg, marker);
  }

  box.appendChild(btn);
  box.appendChild(marker);
  wrap.appendChild(box);
});

  const parent = heart.parentElement;
  parent.style.display = "flex";
  parent.style.alignItems = "center";
  parent.style.justifyContent = "flex-end";
  parent.insertBefore(wrap, heart);
}
function injectFavouriteControls(data) {
  const cards = getFavouriteCards();

  cards.forEach((item) => {
    const existing = item.card.querySelector(".vs-fav-controls");
    if (existing) existing.remove();

    const meta = data[item.key] || { group: "Watchlist", order: 999999 };
    const currentNote = meta.note || "";
    const currentGroup = mapLegacyGroup(meta.group) || "Watchlist";

    const controls = document.createElement("div");
    controls.className = "vs-fav-controls";
    controls.style.display = "flex";
    controls.style.alignItems = "center";
    controls.style.gap = "6px";
    controls.style.margin = "6px 0 8px 0";
    controls.style.flexWrap = "wrap";
    controls.style.position = "relative";
    controls.style.zIndex = "20";
    controls.style.background = "rgba(255,255,255,0.92)";
    controls.style.padding = "4px 0";

    ["click", "mousedown", "mouseup", "pointerdown"].forEach((evt) => {
      controls.addEventListener(evt, function (e) {
        favUiInteracting = true;
        e.stopPropagation();
      });
    });

    const groupButtonWrap = document.createElement("div");
    groupButtonWrap.style.display = "flex";
    groupButtonWrap.style.gap = "4px";
    groupButtonWrap.style.alignItems = "center";
    groupButtonWrap.style.flexWrap = "wrap";

    FAV_GROUPS.forEach((groupName) => {
      const groupBtn = document.createElement("button");
      groupBtn.type = "button";
      groupBtn.textContent = groupName;
      groupBtn.style.padding = "2px 7px";
      groupBtn.style.cursor = "pointer";
      groupBtn.style.borderRadius = "4px";
      groupBtn.style.border = "1px solid rgba(0,0,0,0.18)";
      groupBtn.style.fontSize = "12px";
      groupBtn.style.fontWeight = "600";

      if (currentGroup === groupName) {
        const colours = getGroupColours(groupName);
        groupBtn.style.background = colours.header;
        groupBtn.style.color = "#111";
      } else {
        groupBtn.style.background = "#fff";
        groupBtn.style.color = "#333";
      }

groupBtn.onmousedown = function (e) {
  e.preventDefault();
  e.stopPropagation();

  const currentScrollY = window.scrollY;

  changeItemGroup(item.key, groupName, currentScrollY);

  return false;
};

groupBtn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();
  return false;
};

      groupButtonWrap.appendChild(groupBtn);
    });

    const upBtn = document.createElement("button");
    upBtn.type = "button";
    upBtn.textContent = "↑";
    upBtn.style.padding = "2px 8px";
    upBtn.style.cursor = "pointer";
    upBtn.style.borderRadius = "4px";
    upBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      moveItemWithinGroup(item.key, "up");
    };

    const downBtn = document.createElement("button");
    downBtn.type = "button";
    downBtn.textContent = "↓";
    downBtn.style.padding = "2px 8px";
    downBtn.style.cursor = "pointer";
    downBtn.style.borderRadius = "4px";
    downBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      moveItemWithinGroup(item.key, "down");
    };

    const notesBtn = document.createElement("button");
    notesBtn.type = "button";
    notesBtn.textContent = currentNote ? "Notes ✓" : "Notes";
    notesBtn.style.padding = "2px 8px";
    notesBtn.style.cursor = "pointer";
    notesBtn.style.borderRadius = "4px";
    notesBtn.style.fontWeight = "600";

    const notesBox = document.createElement("div");
    notesBox.className = "vs-notes-box";
    notesBox.style.display = "none";
    notesBox.style.width = "100%";
    notesBox.style.marginTop = "6px";
    notesBox.style.padding = "8px";
    notesBox.style.border = "1px solid rgba(0,0,0,0.12)";
    notesBox.style.borderRadius = "8px";
    notesBox.style.background = "rgba(255,255,255,0.96)";

    const textarea = document.createElement("textarea");
    textarea.value = currentNote;
    textarea.placeholder = "Add notes e.g. postcode, timing, reminder...";
    textarea.style.width = "100%";
    textarea.style.minHeight = "52px";
    textarea.style.resize = "vertical";
    textarea.style.fontSize = "12px";
    textarea.style.padding = "6px";
    textarea.style.borderRadius = "6px";
    textarea.style.border = "1px solid rgba(0,0,0,0.18)";
    textarea.style.boxSizing = "border-box";

    ["click", "mousedown", "mouseup", "keydown", "focus"].forEach(function (evt) {
      textarea.addEventListener(evt, function (e) {
        favUiInteracting = true;
        e.stopPropagation();
      });
    });

    textarea.addEventListener("blur", function () {
      setTimeout(function () {
        favUiInteracting = false;
      }, 500);
    });

    const notesActions = document.createElement("div");
    notesActions.style.display = "flex";
    notesActions.style.gap = "8px";
    notesActions.style.marginTop = "8px";
notesActions.style.width = "100%";

    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.textContent = "Save";
    saveBtn.style.padding = "4px 10px";
    saveBtn.style.borderRadius = "6px";
    saveBtn.style.cursor = "pointer";
    saveBtn.style.fontWeight = "700";
saveBtn.style.flex = "1";
saveBtn.style.padding = "8px 0";
saveBtn.style.textAlign = "center";
saveBtn.style.background = "#111";
saveBtn.style.color = "#fff";
saveBtn.style.border = "0";

    const clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.textContent = "Clear";
    clearBtn.style.padding = "4px 10px";
    clearBtn.style.borderRadius = "6px";
    clearBtn.style.cursor = "pointer";
clearBtn.style.flex = "1";
clearBtn.style.padding = "8px 0";
clearBtn.style.textAlign = "center";
clearBtn.style.background = "#eee";
clearBtn.style.border = "0";

    const noteStatus = document.createElement("span");
    noteStatus.style.fontSize = "12px";
    noteStatus.style.color = "#555";
    noteStatus.style.alignSelf = "center";

    notesBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      favUiInteracting = true;

      const isOpening = notesBox.style.display === "none";
      notesBox.style.display = isOpening ? "block" : "none";

      if (isOpening) {
        setTimeout(function () {
          textarea.focus();
        }, 50);
      } else {
        setTimeout(function () {
          favUiInteracting = false;
        }, 300);
      }
    };

saveBtn.onclick = function (e) {
  e.preventDefault();
  e.stopPropagation();

  favUiInteracting = true;

  const savedText = textarea.value.trim();

  saveFavouriteNote(item.key, savedText, function () {
    notesBtn.textContent = savedText ? "Notes ✓" : "Notes";
    noteStatus.textContent = "Saved";

    textarea.blur();
    notesBox.style.display = "none";

    setTimeout(function () {
      noteStatus.textContent = "";
      favUiInteracting = false;
    }, 600);
  });
};

    clearBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();

      textarea.value = "";

      favUiInteracting = true;

      saveFavouriteNote(item.key, "", function () {
        notesBtn.textContent = "Notes";
        noteStatus.textContent = "Cleared";

        setTimeout(function () {
          noteStatus.textContent = "";
        }, 1400);

        setTimeout(function () {
          favUiInteracting = false;
        }, 1600);
      });
    };

  notesActions.appendChild(clearBtn);
notesActions.appendChild(saveBtn);
notesActions.appendChild(noteStatus);

    notesBox.appendChild(textarea);
    notesBox.appendChild(notesActions);

    controls.appendChild(groupButtonWrap);
    controls.appendChild(upBtn);
    controls.appendChild(downBtn);
    controls.appendChild(notesBtn);
    controls.appendChild(notesBox);

    item.card.insertBefore(controls, item.card.firstChild);
  });
}

function applyFavouriteCustomisation() {
  if (!isFavouritesPage()) return;
  if (favApplying || favUiInteracting) return;

  const cards = getFavouriteCards();
  if (!cards.length) return;

  favApplying = true;

  ensureFavouriteDefaults(function (data) {
    data = normaliseGroupOrders(data);
    reorderFavouritesDom(data);
    insertGroupHeaders(data);
    applyGroupCardColours(data);
    injectFavouriteControls(data);
    createCopyLiveListButton(data);
    favApplying = false;
  });
}

function pauseFavouriteObserver(ms) {
  favUiInteracting = true;
  favObserverPausedUntil = Date.now() + ms;
}

function isFavouriteObserverPaused() {
  return true; // 🔥 TEMP HARD LOCK — stops all auto re-renders
}

  function initFavouritesMode() {
    if (!isFavouritesPage()) return;

setTimeout(applyFavouriteCustomisation, 150);
    if (favObserverStarted) return;
    favObserverStarted = true;

let favTimer = null;

favObserver = new MutationObserver(function () {
  if (favApplying || isFavouriteObserverPaused()) return;

  clearTimeout(favTimer);
  favTimer = setTimeout(function () {
    if (favApplying || isFavouriteObserverPaused()) return;
    applyFavouriteCustomisation();
  }, 700);
});

favObserver.observe(document.body, {
  childList: true,
  subtree: true
});
  }

/* =========================
   PAGINATION KILLER
========================= */

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || message.action !== "vsRunPaginationKiller") return;

  runPaginationKiller(message.maxPages || 6);
  sendResponse({ ok: true });
});

function paginationFetchHtml(url, callback) {
  chrome.runtime.sendMessage(
    { action: "fetchHTML", url },
    function (response) {
      callback(response && response.html ? response.html : "");
    }
  );
}

function getPaginationBaseUrls(maxPages) {
  const urls = new Set();

  urls.add(cleanLink(location.href) + location.search);

  const pageLinks = Array.from(document.querySelectorAll("a[href]"))
    .map((a) => a.href)
    .filter((href) => {
      if (!href) return false;
      if (!href.includes("vivastreet.co.uk")) return false;
      if (!href.includes(location.pathname.split("/")[1] || "")) return false;
      return /([?&]page=\d+|\/page\/\d+|\/p\/\d+)/i.test(href);
    });

  pageLinks.forEach((href) => urls.add(href));

  if (urls.size < maxPages) {
    for (let i = 2; i <= maxPages; i++) {
      try {
        const u = new URL(location.href);
        u.searchParams.set("page", String(i));
        urls.add(u.href);
      } catch (e) {}
    }
  }

  return Array.from(urls).slice(0, maxPages);
}

function extractListingLinksFromHtml(html) {
  const temp = document.createElement("div");
  temp.innerHTML = html;

  const links = Array.from(temp.querySelectorAll("a.clad__ad_link, a[href]"))
    .map((a) => a.href || a.getAttribute("href") || "")
    .filter((href) => {
      if (!href) return false;
      if (!/(\/escort\/|\/massage\/|\/escorts\/)/i.test(href)) return false;
      if (!/\/\d{6,}/.test(href)) return false;
      return true;
    })
    .map((href) => {
      try {
        return href.startsWith("http") ? href : new URL(href, location.origin).href;
      } catch (e) {
        return "";
      }
    })
    .filter(Boolean)
    .map(cleanLink);

  return Array.from(new Set(links));
}

function extractAdvertDataForPagination(url, html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  const ogTitle =
    doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:title"]')?.getAttribute("content") ||
    "";

  const h1Title =
    doc.querySelector("h1")?.innerText?.trim() ||
    doc.querySelector(".kiwii-font-xlarge")?.innerText?.trim() ||
    doc.querySelector('[data-automation="adTitle"]')?.innerText?.trim() ||
    "";

let title = h1Title || ogTitle || doc.title || "Advert";

// 🔥 CLEAN JUNK FROM TITLE
title = title
  .replace(/18\+\s*id\s*verified/gi, "")   // remove "18+ ID Verified"
  .replace(/verified/gi, "")              // fallback catch
  .replace(/\s+/g, " ")                  // normalize spaces
  .trim();

  let nationality = "-";
  let age = "-";

  doc.querySelectorAll("tr").forEach((row) => {
    const cells = row.querySelectorAll("td");
    if (cells.length < 2) return;

    const label = cells[0].innerText.trim();
    const value = cells[1].innerText.trim();

    if (label === "Nationality") nationality = value;
    if (label === "Age") age = value.replace(/\s*years old/i, "").trim();
  });

  const phoneNumberElement = doc.querySelector(".phone_link");
  const rawPhoneNumber = phoneNumberElement
    ? phoneNumberElement.getAttribute("data-phone-number")
    : "";

  const rawWhatsappDigits = getRawWhatsappDigits(rawPhoneNumber);
  const displayPhone = formatDisplayPhone(rawPhoneNumber);

  const fmin =
    doc.querySelector('[data-automation="tdRate15minutesIncall"]')?.innerText.trim() || "-";
  const tmin =
    doc.querySelector('[data-automation="tdRate30minutesIncall"]')?.innerText.trim() || "-";
  const hr =
    doc.querySelector('[data-automation="tdRate1hourIncall"]')?.innerText.trim() || "-";

  let image =
    doc.querySelector('meta[property="og:image"]')?.getAttribute("content") ||
    doc.querySelector('meta[name="twitter:image"]')?.getAttribute("content") ||
    doc.querySelector(".kiwii-carousel img")?.getAttribute("src") ||
    doc.querySelector(".gallery img")?.getAttribute("src") ||
    doc.querySelector("img")?.getAttribute("src") ||
    "";

  if (image && image.startsWith("/")) {
    image = new URL(image, location.origin).href;
  }

  const area = extractAreaFromUrl(url);

  return {
    url,
    title,
    area,
    image,
    nationality,
    age,
    fmin,
    tmin,
    hr,
    rawWhatsappDigits,
    displayPhone
  };
}
function createPaginationOverlay() {
  const old = document.getElementById("vs-pagination-killer-overlay");
  if (old) old.remove();

  const overlay = document.createElement("div");
  overlay.id = "vs-pagination-killer-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "20px";
  overlay.style.right = "20px";
  overlay.style.width = "420px";
  overlay.style.maxHeight = "85vh";
  overlay.style.overflow = "auto";
  overlay.style.zIndex = "999999";
  overlay.style.background = "#fff";
  overlay.style.border = "1px solid rgba(0,0,0,0.18)";
  overlay.style.borderRadius = "12px";
  overlay.style.boxShadow = "0 12px 34px rgba(0,0,0,0.28)";
  overlay.style.padding = "12px";
  overlay.style.fontFamily = "Arial, sans-serif";
  overlay.style.color = "#111";

overlay.innerHTML = `
  <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
    
    <button id="vs-pk-screengrab" style="
      border:0;
      border-radius:8px;
      padding:8px 12px;
      cursor:pointer;
      font-weight:700;
      background:#25D366;
      color:#fff;
      font-size:12px;
    ">Screengrab</button>

    <div style="font-size:16px;font-weight:800;flex:1;text-align:center;">
      Filtered Matches
    </div>

    <button id="vs-pk-close" style="
      border:0;
      background:#eee;
      border-radius:7px;
      padding:5px 8px;
      cursor:pointer;
      font-weight:700;
    ">×</button>

  </div>

  <div id="vs-pk-status" style="font-size:12px;color:#555;margin-bottom:10px;">
    Starting scan...
  </div>

  <div id="vs-pk-results"></div>
`;

  document.body.appendChild(overlay);

  overlay.querySelector("#vs-pk-close").onclick = function () {
    overlay.remove();
  };

overlay.querySelector("#vs-pk-screengrab").onclick = function () {
  const rect = overlay.getBoundingClientRect();

  chrome.runtime.sendMessage({
    action: "vsTakeScreengrab",
    crop: {
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height,
      dpr: window.devicePixelRatio || 1
    }
  }, function () {
    updatePaginationStatus("Screengrab saved");
  });
};

  return overlay;
}

function updatePaginationStatus(text) {
  const el = document.querySelector("#vs-pk-status");
  if (el) el.textContent = text;
}

function addPaginationResultCard(item) {
  const results = document.querySelector("#vs-pk-results");
  if (!results) return;

  const card = document.createElement("a");
  card.href = item.url;
  card.target = "_blank";

  card.style.display = "flex";
  card.style.gap = "10px";
  card.style.border = "1px solid rgba(0,0,0,0.10)";
  card.style.borderRadius = "10px";
  card.style.padding = "8px";
  card.style.margin = "8px 0";
  card.style.background = "#f9fafb";
  card.style.textDecoration = "none";
  card.style.color = "#111";

  const imgHtml = item.image
    ? `<img src="${item.image}" style="width:82px;height:90px;object-fit:cover;border-radius:8px;flex-shrink:0;">`
    : `<div style="width:82px;height:90px;border-radius:8px;background:#eee;flex-shrink:0;"></div>`;

  card.innerHTML = `
    ${imgHtml}

    <div style="flex:1;min-width:0;">

      <div style="
        font-size:13px;
        font-weight:800;
        margin-bottom:4px;
        line-height:1.25;
        display:-webkit-box;
        -webkit-line-clamp:2;
        -webkit-box-orient:vertical;
        overflow:hidden;
        text-overflow:ellipsis;
      ">
        ${item.title || "Advert"}
      </div>

      <div style="font-size:12px;color:#1f4ed8;margin-bottom:4px;font-weight:600;">
        15m-${item.fmin || "-"} | 30m-${item.tmin || "-"} | 1hr-${item.hr || "-"}
      </div>

      <div style="font-size:12px;color:#0a7a0a;margin-bottom:4px;">
        ${getNationalityFlag(item.nationality)} ${item.nationality || "-"} | ${item.displayPhone || "-"}
      </div>

      <div style="font-size:12px;color:#555;">
        ${item.area || "-"}
      </div>

    </div>
  `;

  results.appendChild(card);
}
function runPaginationKiller(maxPages) {
  createPaginationOverlay();

  getFilters(function (filters) {
    const pageUrls = getPaginationBaseUrls(maxPages);
    const allAdLinks = new Set();
    const matched = [];

    let pageIndex = 0;

    function fetchNextPage() {
      if (pageIndex >= pageUrls.length) {
        const adLinks = Array.from(allAdLinks);

        if (!adLinks.length) {
          updatePaginationStatus("No adverts found on scanned pages.");
          return;
        }

        updatePaginationStatus(`Found ${adLinks.length} adverts. Checking filters...`);
        scanAdLinks(adLinks, filters, matched);
        return;
      }

      const pageUrl = pageUrls[pageIndex];
      pageIndex += 1;

      updatePaginationStatus(`Scanning page ${pageIndex} of ${pageUrls.length}...`);

      paginationFetchHtml(pageUrl, function (html) {
        const links = extractListingLinksFromHtml(html);
        links.forEach((href) => allAdLinks.add(href));

        setTimeout(fetchNextPage, 250);
      });
    }

    fetchNextPage();
  });
}

function scanAdLinks(adLinks, filters, matched) {
  let index = 0;
  let active = 0;
  const maxConcurrent = 3;

  function pump() {
    while (active < maxConcurrent && index < adLinks.length) {
      const url = adLinks[index];
      index += 1;
      active += 1;

      updatePaginationStatus(
        `Checking adverts ${Math.min(index, adLinks.length)} / ${adLinks.length}. Matches: ${matched.length}`
      );

      paginationFetchHtml(url, function (html) {
        active -= 1;

        if (html) {
          const data = extractAdvertDataForPagination(url, html);

          if (
passesFilters(
  {
    fmin: data.fmin,
    tmin: data.tmin,
    hr: data.hr,
    nationality: data.nationality
  },
  filters
)
          ) {
            matched.push(data);
            addPaginationResultCard(data);
          }
        }

        if (index >= adLinks.length && active === 0) {
          updatePaginationStatus(
            `Done. ${matched.length} matching advert${matched.length === 1 ? "" : "s"} found.`
          );
          return;
        }

        setTimeout(pump, 120);
      });
    }
  }

  pump();
}

function rerunEnhancements() {
  console.log("VS Tamer: rerunEnhancements", location.pathname);

  if (isAdvertPage()) {
    injectReverseImageTopRight();
    return;
  }

  if (isFavouritesPage()) {
    initFavouritesMode();
    processListingsPage();
    return;
  }

  processListingsPage();
}

let vsTamerTimer = null;

function scheduleVsTamerRun() {
  clearTimeout(vsTamerTimer);

  vsTamerTimer = setTimeout(function () {
    try {
      rerunEnhancements();
    } catch (e) {
      console.error("VS Tamer ERROR:", e);
    }
  }, 400);
}

function startVsTamer() {
  console.log("VS Tamer starting with page observer");

  scheduleVsTamerRun();

  setTimeout(scheduleVsTamerRun, 1000);
  setTimeout(scheduleVsTamerRun, 2500);
  setTimeout(scheduleVsTamerRun, 5000);

  const observer = new MutationObserver(function () {
    if (document.querySelector(".newData")) return;
    scheduleVsTamerRun();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startVsTamer);
} else {
  startVsTamer();
}
})();