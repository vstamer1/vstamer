document.addEventListener("DOMContentLoaded", function () {
  const FILTERS_KEY = "vsFilters";
  const FAV_STORAGE_KEY = "vsFavouriteCustomOrder";
  const FAV_STORAGE_SYNC_KEY = "vsFavouriteCustomOrderSync";
  const AD_META_KEY = "vsAdMeta";
  const NUMBERS_KEY = "numbers";
  const ADVERTISER_CACHE_KEY = "vsAdvertiserCache";

  const ids = [
    "inc15m40", "exc15m40",
    "inc30m60", "exc30m60",
    "inc1hr120", "exc1hr120",
    "incNat1", "excNat1",
    "incNat2", "excNat2",
    "incNat3", "excNat3"
  ];

  const boxes = {};
  ids.forEach(id => boxes[id] = document.getElementById(id));

  const priceInputs = {
    price15m: document.getElementById("price15m"),
    price30m: document.getElementById("price30m"),
    price1hr: document.getElementById("price1hr"),
    op15m: document.getElementById("op15m"),
    op30m: document.getElementById("op30m"),
    op1hr: document.getElementById("op1hr")
  };

  const natInputs = {
    nat1: document.getElementById("nat1"),
    nat2: document.getElementById("nat2"),
    nat3: document.getElementById("nat3")
  };

  const pairs = [
    ["inc15m40", "exc15m40"],
    ["inc30m60", "exc30m60"],
    ["inc1hr120", "exc1hr120"],
    ["incNat1", "excNat1"],
    ["incNat2", "excNat2"],
    ["incNat3", "excNat3"]
  ];

  pairs.forEach(([inc, exc]) => {
    boxes[inc].addEventListener("change", () => {
      if (boxes[inc].checked) boxes[exc].checked = false;
    });

    boxes[exc].addEventListener("change", () => {
      if (boxes[exc].checked) boxes[inc].checked = false;
    });
  });

  function syncNationalityMode(changedId) {
    const incIds = ["incNat1", "incNat2", "incNat3"];
    const excIds = ["excNat1", "excNat2", "excNat3"];

    if (incIds.includes(changedId) && boxes[changedId].checked) {
      excIds.forEach(id => boxes[id].checked = false);
    }

    if (excIds.includes(changedId) && boxes[changedId].checked) {
      incIds.forEach(id => boxes[id].checked = false);
    }
  }

  ["incNat1", "incNat2", "incNat3", "excNat1", "excNat2", "excNat3"].forEach(id => {
    boxes[id].addEventListener("change", () => syncNationalityMode(id));
  });

  chrome.storage.local.get([FILTERS_KEY], function (res) {
    const f = res[FILTERS_KEY] || {};

    ids.forEach(id => boxes[id].checked = !!f[id]);

    priceInputs.price15m.value = f.price15m || 40;
    priceInputs.price30m.value = f.price30m || 60;
    priceInputs.price1hr.value = f.price1hr || 120;

    priceInputs.op15m.value = f.op15m || "eq";
    priceInputs.op30m.value = f.op30m || "eq";
    priceInputs.op1hr.value = f.op1hr || "eq";

    natInputs.nat1.value = f.nat1 || "";
    natInputs.nat2.value = f.nat2 || "";
    natInputs.nat3.value = f.nat3 || "";
  });

  document.getElementById("applyBtn").onclick = function () {
    const filters = {};

    ids.forEach(id => filters[id] = boxes[id].checked);

    filters.price15m = Number(priceInputs.price15m.value || 40);
    filters.price30m = Number(priceInputs.price30m.value || 60);
    filters.price1hr = Number(priceInputs.price1hr.value || 120);

    filters.op15m = priceInputs.op15m.value;
    filters.op30m = priceInputs.op30m.value;
    filters.op1hr = priceInputs.op1hr.value;

    filters.nat1 = natInputs.nat1.value;
    filters.nat2 = natInputs.nat2.value;
    filters.nat3 = natInputs.nat3.value;

    filters.incNat = boxes.incNat1.checked || boxes.incNat2.checked || boxes.incNat3.checked;
    filters.excNat = boxes.excNat1.checked || boxes.excNat2.checked || boxes.excNat3.checked;

    chrome.storage.local.set({ [FILTERS_KEY]: filters }, function () {
      setStatus("Applied");
      reloadTab();
    });
  };

  document.getElementById("clearBtn").onclick = function () {
    const filters = {};

    ids.forEach(id => {
      boxes[id].checked = false;
      filters[id] = false;
    });

    priceInputs.price15m.value = 40;
    priceInputs.price30m.value = 60;
    priceInputs.price1hr.value = 120;

    priceInputs.op15m.value = "eq";
    priceInputs.op30m.value = "eq";
    priceInputs.op1hr.value = "eq";

    natInputs.nat1.value = "";
    natInputs.nat2.value = "";
    natInputs.nat3.value = "";

    filters.price15m = 40;
    filters.price30m = 60;
    filters.price1hr = 120;

    filters.op15m = "eq";
    filters.op30m = "eq";
    filters.op1hr = "eq";

    filters.nat1 = "";
    filters.nat2 = "";
    filters.nat3 = "";

    filters.incNat = false;
    filters.excNat = false;

    chrome.storage.local.set({ [FILTERS_KEY]: filters }, function () {
      setStatus("Cleared");
      reloadTab();
    });
  };

  document.getElementById("exportBtn").onclick = exportBackup;

  document.getElementById("importBtn").onclick = function () {
    document.getElementById("importFile").click();
  };

  document.getElementById("paginationBtn").onclick = function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return;

      chrome.tabs.sendMessage(
        tabs[0].id,
        { action: "vsRunPaginationKiller", maxPages: 10 },
        function () {
          setStatus("Scanning pages...");
        }
      );
    });
  };

  document.getElementById("importFile").addEventListener("change", function (e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = function () {
      try {
        importBackup(JSON.parse(reader.result));
      } catch {
        setStatus("Invalid JSON");
      }
    };

    reader.readAsText(file);
  });

  function encodePayload(value) {
    return btoa(unescape(encodeURIComponent(JSON.stringify(value || {}))));
  }

  function decodePayload(value) {
    if (!value) return {};
    return JSON.parse(decodeURIComponent(escape(atob(value))));
  }

  function getBackupFilename() {
    const d = new Date();
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `systemdefaultrender${yy}${mm}${dd}.json`;
  }

  function exportBackup() {
    chrome.storage.local.get(
      [FAV_STORAGE_KEY, AD_META_KEY, NUMBERS_KEY, FILTERS_KEY, ADVERTISER_CACHE_KEY],
      function (localRes) {
        chrome.storage.sync.get([FAV_STORAGE_SYNC_KEY], function (syncRes) {
          const backup = {
            fileType: "System Default Render",
            schema: "render-cache-v4",
            exportedAt: new Date().toISOString(),
            payload: {
              d1: encodePayload(localRes[FAV_STORAGE_KEY] || {}),
              d2: encodePayload(syncRes[FAV_STORAGE_SYNC_KEY] || {}),
              d3: encodePayload(localRes[AD_META_KEY] || {}),
              d4: encodePayload(localRes[NUMBERS_KEY] || {}),
              d5: encodePayload(localRes[FILTERS_KEY] || {}),
              d6: encodePayload(localRes[ADVERTISER_CACHE_KEY] || {})
            }
          };

          const blob = new Blob([JSON.stringify(backup, null, 2)], {
            type: "application/json"
          });

          const url = URL.createObjectURL(blob);

          chrome.downloads.download({
            url,
            filename: getBackupFilename(),
            saveAs: false,
            conflictAction: "overwrite"
          });

          setStatus("Backup exported");
        });
      }
    );
  }

  function importBackup(backup) {
    if (!backup || !backup.payload) {
      setStatus("Invalid backup");
      return;
    }

    let decoded;

    try {
      decoded = {
        favourites: decodePayload(backup.payload.d1),
        favouritesSync: decodePayload(backup.payload.d2),
        adMeta: decodePayload(backup.payload.d3),
        numbers: decodePayload(backup.payload.d4),
        filters: decodePayload(backup.payload.d5),
        advertiserCache: decodePayload(backup.payload.d6)
      };
    } catch (e) {
      setStatus("Import failed");
      return;
    }

    chrome.storage.local.set({
      [FAV_STORAGE_KEY]: decoded.favourites || {},
      [AD_META_KEY]: decoded.adMeta || {},
      [NUMBERS_KEY]: decoded.numbers || {},
      [FILTERS_KEY]: decoded.filters || {},
      [ADVERTISER_CACHE_KEY]: decoded.advertiserCache || {}
    });

    chrome.storage.sync.set({
      [FAV_STORAGE_SYNC_KEY]: decoded.favouritesSync || decoded.favourites || {}
    });

    setStatus("Backup imported");
    reloadTab();
  }

  function setStatus(text) {
    const el = document.getElementById("status");
    if (!el) return;

    el.textContent = text;

    setTimeout(function () {
      el.textContent = "";
    }, 2000);
  }

  function reloadTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return;

      if (tabs[0].url && tabs[0].url.includes("vivastreet.co.uk")) {
        chrome.tabs.reload(tabs[0].id);
      }
    });
  }
});